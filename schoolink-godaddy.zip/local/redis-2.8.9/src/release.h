#define REDIS_GIT_SHA1 "ee2711c1"
#define REDIS_GIT_DIRTY "23589"
#define REDIS_BUILD_ID "onlineschoolmanager-1423662758"
