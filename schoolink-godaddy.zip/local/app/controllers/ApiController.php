<?php

class ApiController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function getUser($action,$email,$password,$gcm_id,$device_type,$user_type)
	{

	if($action == 'login'){

     if (Auth::attempt(array('email' => $email, 'password' => $password, 'user_type' => $user_type)))
      {

       $user=$this->verify_user($user_type);
       $update_user=$this->update_user($gcm_id,$device_type,Auth::user()->id);
       return $user;
     }
     else
     {
       $response["success"]=0;
       $response["message"]='Not a valid username and password';
       return $response;
     }
   }// if action fails
     else{

       $response["success"]=0;
       $response["message"]='Not a valid action';
       return $response;
     }


	}// function close


public function getChild($action,$id)
	{

	if($action == 'child_list'){

   $parents = Parents::where('user_id','=',$id)->first();

   if($parents){

     $students=Student::where('parent_id','=',$parents->id)->get();
     if(empty($students)){
           $response["success"]=0;
           $response["message"]='No child alloted';
           return $response;
         } // empty student check
     else{

           $student_details=$this->find_child($students);
           return $student_details;

          }

     }else{
            $response["success"]=0;
            $response["message"]='parent not found';
            return $response;

       } // if parents empty

   }// if action fails
     else{

       $response["success"]=0;
       $response["message"]='Not a valid action';
       return $response;
     }


}// function close

public function getLeaveRequest($action,$parent_id,$child_id)
	{
	if($action == 'leave_request'){

      $parent = Parents::where('user_id','=',$parent_id)->first();
   if($parent){
     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child alloted';
           return $response;
         } // empty student check
     else{

           $leave_requests=$this->find_requests($parent->id,$child_id);
           return $leave_requests;

          }

     }else{
            $response["success"]=0;
            $response["message"]='parent not found';
            return $response;

       } // if parents empty

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getSectionSubject($action,$child_id)
  {
  if($action == 'subject_list'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $subjects=$this->find_subject($child_id);
           return $subjects;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close



public function getSchoolUpdate($action)
  {
  if($action == 'school_update'){

    

           $school_bulletin=$this->find_school_bulletin();
           return $school_bulletin;

        

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close



public function getChildUpdate($action,$child_id)
  {
  if($action == 'child_update'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $child_update=$this->find_child_update($child_id);
           return $child_update;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getGallery($action,$child_id)
  {
  if($action == 'gallery_list'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $gallery=$this->find_gallery($student);
           return $gallery;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getClassBulletin($action,$child_id)
  {
  if($action == 'class_bulletin'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $class_bulletin=$this->find_class_bulletin($student->id);
           return $class_bulletin;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close

public function getStudentBulletin($action,$child_id)
  {
  if($action == 'student_bulletin'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $student_bulletins=$this->find_student_bulletin($student->id);
           return $student_bulletins;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close

public function getAssignment($action,$child_id)
  {

  if($action == 'assignment'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $assignments=$this->find_assignment($student->id,1);
           return $assignments;

          }

   }// if action fails
   elseif($action == 'test'){
     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $assignments=$this->find_assignment($student->id,2);
           return $assignments;

          }

     }else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close

public function getTimetable($action,$child_id)
  {
  if($action == 'timetable'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $student_timetable=$this->find_student_timetable($student->id);
           return $student_timetable;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getAttendance($action,$month,$year,$child_id)
  {
  if($action == 'attendance'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $student_attendance=$this->find_student_attendance($student->id,$month,$year);
           return $student_attendance;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close

public function getExam($action,$child_id)
  {
  if($action == 'exam'){

  $student=Student::find($child_id);

     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No student found';
           return $response;
         } // empty student check
     else{

           $exams=$this->find_exam($child_id);
           return $exams;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getClasswork($action,$subject_id)
  {
  if($action == 'classwork'){

     $subject=SectionSubject::find($subject_id);
     if(empty($subject)){
           $response["success"]=0;
           $response["message"]='No subject found';
           return $response;
         } // empty student check
     else{

           $student_subject_classwork=$this->find_classwork($subject->id);
           return $student_subject_classwork;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close

public function getHomework($action,$subject_id)
  {
  if($action == 'homework'){

     $subject=SectionSubject::find($subject_id);
     if($subject->count() == 0){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $student_homework=$this->find_homework($subject->id);
           return $student_homework;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getEvent($action)
  {
  if($action == 'event_list'){

     
           $event=$this->find_event();
           return $event;

          

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close

public function getInfo($action,$child_id)
  {
  if($action == 'info'){

     $student=Student::find($child_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{

           $school_info=$this->find_school_info();
           return $school_info;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getTeacherStudent($action,$section_id)
  {
  if($action == 'teacher_studentlist'){

     $section_id=Section::find($section_id);
     if($section_id){

           $response=$this->find_student($section_id);
           return $response;

         } // empty student check
     else{
              $response["success"]=0;
              $response["message"]='No section found';
              return $response;
           
          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


public function getTeacherInfo($action,$id)
  {
  if($action == 'teachers'){

     $parent=Parents::where('user_id','=',$id)->first();

     if(empty($parent)){
           $response["success"]=0;
           $response["message"]='No parent found';
           return $response;
         } // empty student check
     else{

           $class_teachers=$this->find_class_teachers($parent->id);
           return $class_teachers;

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

}// function close


// end here

public function verify_user($user_type){

     if($user_type == 2)
           $user =Auth::user()->Teacher;
     else
           $user =Auth::user()->Parents;
   
     
        
      if(empty($user)){
      	    $user_data["success"]=0;
      	    $user_data["message"]='Not a valid username and password';
         	  return $response;

       }else{

       	     $user_data["success"]=1;
             $user_data["msg"]='Valid User';
           
           if($user_type == 2){
      	     $response["id"]        =  $user->User->id;
             $response["code"]      =  $user->code;
             $response["fname"]     =  $user->fname;
             $response["mname"]     =  $user->mname;
             $response["lname"]     =  $user->lname;
             $response["phone_1"]     =  $user->phone_1;
             $response["phone_2"]     =  $user->phone_2;
             $response["user_type"] =  'Teacher';
             $response["address"]   =  strip_tags($user->address);
             $response["class_name"]     =  $user->Classes->name;
             $response["section"]   =  $user->Section->name;
             $response["image"]   =  url('uploads/teacher/'.$user->imagename_new);

            }
            if($user_type == 3){

             $response["id"]        =  $user->User->id;
             $response["code"]      =  $user->code;
             $response["fname"]     =  $user->fname;
             $response["mname"]     =  $user->mname;
             $response["lname"]     =  $user->lname;
             $response["phone_1"]   =  $user->phone_1;
             $response["phone_2"]   =  $user->phone_2;
             $response["user_type"] =  'Parent';
             $response["address"]   =  strip_tags($user->address);
             $response["occupation"] = $user->occupation;
             $response["image"]   = url('uploads/parents/'.$user->imagename_new) ;
           

            }

          
           $user_data["user_data"]=$response;
           return Response::json($user_data);
         }



  } // function close

public function update_user($gcm_id,$device_type){

       if(Auth::user()->user_type == 2)
          $user =Auth::user()->Teacher;
       else
         $user =Auth::user()->Parents;


      if(empty($user)){
            $response["success"]=0;
            $response["message"]='Not a valid username and password';
          return $response;
       }else{
            $find_gcms = User::where('gcm_id','=',$gcm_id)->get();

           if($find_gcms->count() > 0)
              {
                foreach($find_gcms as $find_gcm){
                    $find_gcm_id=$find_gcm->id;
                }
                $gcm_delete=User::find($find_gcm_id);
                $gcm_delete->gcm_id ="";
                $gcm_delete->save();

                $user_update=User::find($user->user_id);
                $user_update->gcm_id = $gcm_id;
                $user_update->device_type = $device_type;
                $user_update->save();

              }else{

                $user_update=User::find($user->user_id);
                $user_update->gcm_id = $gcm_id;
                $user_update->device_type = $device_type;
                $user_update->save();
              }

               $response["update"]= 'updated';

               return Response::json($response);
       }
  } // function close


 public function find_child($students){

       $child_list["success"]=1;
       $child_list["msg"]="child list success";

       foreach($students as $student){
            $response['child_id']=$student->id;
            $response['fname']=$student->fname;
            $response['mname']=$student->mname;
            $response['lname']=$student->lname;
            $response['class_name']=$student->Classes->name;
            $response['section']=$student->Section->name;
            $response['roll_no']=$student->roll_no;
            $response['email']=$student->email;
            $response['address']=strip_tags($student->address);
            $response['phone']=$student->phone;
 

            if(empty($student->house_id))
             {
               $response['house']='';
             }
            else
             {
               $response['house_name']=$student->House->house_name;
             }

          if(empty($student->bus_id))
             {
               $response['bus_id']='';
               $response['bus_no']='';
             }
            else
             {
                $response['bus_id']=$student->bus_id;
                $response['bus_no']=$student->Bus->bus_no;
             }
            
            $data[]=$response;

      	   }
           $child_list["child_list"]=$data;
      	   return Response::json($child_list);
  } // function close


  public function find_requests($parent_id,$child_id){

          $requests=ParentRequest::where('parents_id','=',$parent_id)->where('student_id','=',$child_id)->get();

          $child_list["success"]=1;
          $child_list["msg"]="leave request success";

      	  foreach($requests as $request){
            $response['leave_id']=$request->id;
            $response['child_id']=$request->Student->id;
            $response['fname']=$request->Student->fname;
            if(empty($student->mname))
             {
               $response['mname']='';
             }
            else
             {
               $response['mname']=$request->Student->mname;
             }
            $response['lname']=$request->Teacher->lname;

            $response['teacher_fname']=$request->Teacher->fname;
            if(empty($request->teacher_id))
             {
               $response['teacher_mname']='';
             }
            else
             {
               $response['teacher_mname']=$request->Teacher->mname;
             }
            $response['teacher_lname']=$request->Teacher->lname;

            $response['title']=$request->title;
            $response['description']=strip_tags($request->description);

            $new_string = explode('-', $request->date_range);
            $response['leave_from']=trim($new_string[0]);
            $response['leave_to']=trim($new_string[1]);

           if($request->status == 3)
                $response['status']="Pending";
           elseif($request->status == 2)
             	 $response['status']= "Approved";
           else
                $response['status']= "Rejected";

            $data[]=$response;


        }// for each close
           $child_list["leave_history"]=$data;
      	   return Response::json($child_list);
  } // function close

public function find_subject($student_id){

      $child_subject["success"]=1;
      $child_subject["msg"]="subject list success";
      $student=Student::find($student_id);
      $subjects=SectionSubject::where('section_id','=',$student->section_id)->get();
     if($subjects->isEmpty()){

              $child_subject["success"]=0;
              $child_subject["msg"]="subject not found";
              $response["subject_id"]="";
              $response["subject_name"]="";
              $data[]=$response;
              $child_subject["classwork_list"]=$data;

      }else{

        foreach($subjects as $subject){
        $response["subject_id"]=$subject->id;

        if($subject->ispractical == 1){

             $response["subject_name"]=$subject->Subject->name.' '.'Practical';

          }
       elseif($subject->ispractical == 0){

            $response["subject_name"]=$subject->Subject->name.' '.'Theory';
           }
       elseif($subject->ispractical == 2){

            $response["subject_name"]=$subject->Subject->name;
           }

       $data[]=$response;

    } // subject close loop

          $child_subject["subject_list"]= $data;

   } // check empty


          return Response::json($child_subject);

  } // function close



public function find_school_bulletin(){

     $announcements=Announcement::orderBy('id','desc')->get();

  if($announcements->isEmpty()){

              $school_bulletin["success"]=0;
              $school_bulletin["msg"]="school update list not found";
              $response["date"]="";
              $response["title"]="";
              $response["description"]="";
              $data[]=$response;
              $school_bulletin["school_update_list"]=$data;

      }else{

         $school_bulletin["success"]=1;
         $school_bulletin["msg"]="school update list success";
        foreach($announcements as $announcement){
          $response["date"]=$announcement->created_at->format('d/m/Y');
          $response["title"]=$announcement->title;
          $response["description"]=strip_tags($announcement->description);
         
          $data[]=$response;
        } // classwork close loop

         $school_bulletin["school_update_list"]= $data;

    }


          return Response::json($school_bulletin);

  } // function close



public function find_class_bulletin($student_id){

  $student=Student::find($student_id);
  $classes_bulletins=ClassBulletin::where('classes_id','=',$student->Classes->id)->get();

  if($classes_bulletins->isEmpty()){

              $class_bulletin["success"]=0;
              $class_bulletin["msg"]="class bulletin not found";
              $response["bulletin_id"]="";
              $response["class"]="";
              $response["title"]="";
              $response["description"]="";
              $response["created_by"]="";
              $data[]=$response;
              $class_bulletin["class_bulletin_list"]=$data;

      }else{

         $class_bulletin["success"]=1;
         $class_bulletin["msg"]="class bulletin list success";
        foreach($classes_bulletins as $classes_bulletin){
          $response["bulletin_id"]=$classes_bulletin->id;
          $response["class"]=$student->Classes->name;
          $response["title"]=$classes_bulletin->title;
          $response["description"]=strip_tags($classes_bulletin->description);
          $response["created_by"]=$classes_bulletin->created_by;
          $response["created_date"]=$classes_bulletin->created_at->format('Y-m-d') ;
          $data[]=$response;
        } // classwork close loop

         $class_bulletin["class_bulletin_list"]= $data;

    }


          return Response::json($class_bulletin);

  } // function close


public function find_student_bulletin($student_id){


  $student_bulletins=StudentBulletin::where('student_id','=',$student_id)->get();
   
  if($student_bulletins->isEmpty()){

              $stu_bulletin["success"]=0;
              $stu_bulletin["msg"]="student bulletin not found";
              $response["bulletin_id"]="";
              $response["class"]="";
              $response["section"]="";
              $response["title"]="";
              $response["description"]="";
              $response["created_by"]="";
              $data[]=$response;
              $stu_bulletin["student_bulletin_list"]=$data;

      }else{

         $stu_bulletin["success"]=1;
         $stu_bulletin["msg"]="student bulletin list success";
        foreach($student_bulletins as $student_bulletin){
          $response["bulletin_id"]=$student_bulletin->id;
          $response["class_name"]=$student_bulletin->Classes->name;
          $response["section"]=$student_bulletin->Section->name;
          $response["title"]=$student_bulletin->title;
          $response["description"]=strip_tags($student_bulletin->description);
          $response["created_by"]=$student_bulletin->created_by;
          $response["created_date"]=$student_bulletin->created_at->format('d-m-Y');
          $data[]=$response;
        } // classwork close loop

         $stu_bulletin["student_bulletin_list"]= $data;

    }


          return Response::json($stu_bulletin);

  } // function close

public function find_assignment($student_id,$type){

  $student=Student::find($student_id);

  $student_subjects=SectionSubject::where('section_id','=',$student->section_id)->get();

  if($student_subjects->isEmpty()){

              $stu_assignment["success"]=0;
              $stu_assignment["msg"]="student subject and assignment list not found";
              $stu_assignment["subject"]=$data;

      }else{

         $stu_assignment["success"]=1;
         $stu_assignment["msg"]="student subject and assignment list success";
         $i=0;

     foreach($student_subjects as $student_subject){

  if($type == 1){

    $assignments=Assignment::where('section_subject_id','=',$student_subject->id)->where('type','=',$type)->get();

   }
   if($type == 2){

    $assignments=Assignment::where('section_subject_id','=',$student_subject->id)->where('type','=',$type)->get();

   }


      $j=0;

       $response1[$i]["subject_id"]=$student_subject->id;

            if($student_subject->ispractical == 1){

              $response1[$i]["subject_name"]=$student_subject->Subject->name.' '.'Practical';

            }elseif($student_subject->ispractical == 0){

             $response1[$i]["subject_name"]=$student_subject->Subject->name.' '.'Theory';

            }else{

              $response1[$i]["subject_name"]=$student_subject->Subject->name;
           }




    $data2=array();
    foreach($assignments as $assignment){


       if($assignments->isEmpty()){

              $response2["success"]=0;
              if($type == 1){
               $response2["msg"]="assignment not found";
              }else{
               $response2["msg"]="test not found";
              }
              $response2["class"]="";
              $response2["section"]="";
              $response2["title"]="";
              $response2["description"]="";
              $response2["submission_date"]="";
              $response2["total_marks"]="";
              $response2["publish_status"]="";
              $response2["assignment_checked"]="";
              $response2["assigned_by_teacher"]="";
              $data[]=$response2;
              if($type == 1){
               $stu_assignment["assignment_list"]=$data;
              }else{
               $stu_assignment["test_list"]=$data;
              }

      } // if assignments empty

    else{   if($type == 1)
              $response2["assignment_id"]=$assignment->id;
            else
              $response2["test_id"]=$assignment->id;

          if($assignment->AssignmentMarks)
             $response2["marks_obtained"]=$assignment->AssignmentMarks->marks_obtained;
          else
             $response2["marks_obtained"]="";

          $response2["created_date"]=$assignment->created_at->format('Y-m-d');
          if($type == 1){
               $response2["type"]="assignment";
          }else{
               $response2["type"]="test";
            }
          $response2["class"]=$student->Classes->name;
          $response2["section"]=$student->Section->name;
          $response2["title"]=$assignment->name;
          $response2["description"]=strip_tags($assignment->description);
          $response2["submission_date"]=$assignment->date;

          $today=strtotime(date('d-m-Y'));
          $submission_date=strtotime($assignment->date);

          if($today > $submission_date) {

                $response2['submission_status']='N';

          }else{

                $response2['submission_status']='Y';
           }

          $response2["total_marks"]=$assignment->total_marks;

          if($assignment->isChecked == 1){
            $response2["checked"]='Y';
         }else{
            $response2["checked"]='N';
         }
          $response2["created_by_teacher"]=$assignment->Teacher->fname.''.$assignment->Teacher->lname;

         $data2[$j]=$response2;

          } // else close
       $j++;
       } // assignment close loop
        if($type == 1)
         $response1[$i]["assignment_list"]= $data2;
       else
          $response1[$i]["test_list"]= $data2;

         $stu_assignment["subject_list"]=$response1;


     $i++;
   } // subject close loop



}


   return Response::json($stu_assignment);

  } // function close



public function find_student_timetable($student_id){

  $student=Student::find($student_id);
  $timetables=Timetable::where('section_id','=',$student->section_id)->first();
  $week_day = substr(date("l"), 0, 3);

    if($timetables){
              $timetable_details_section["success"]=1;
              $timetable_details_section["msg"]="timetable list success";
              $timetable_details=TimetableDetails::where('tt_master_id','=',$timetables->id)->where('week_day','=',$week_day)->get();

              $j=0;
              $data2=array();

              foreach($timetable_details as $timetable_detail){

              if($timetable_detail->section_subject_id == 0){

                    $response2["subject"]='OFF';
              }
              elseif($timetable_detail->section_subject_id == -1){

                   $response2["subject"]='Break';
               }
              else{

                   $response2["subject_id"]=$timetable_detail->SectionSubject->id;
                   $response2["subject"]=$timetable_detail->SectionSubject->Subject->name;
          
            }

         if($timetable_detail->section_subject_id == 0 || $timetable_detail->section_subject_id == 0){

         }else{

           $response2["time"]=$timetable_detail->start_time.'-'.$timetable_detail->end_time;
           $response2["teacher"]=$timetable_detail->SectionSubject->Teacher->fname.' '.$timetable_detail->SectionSubject->Teacher->lname;
           $response2["facility"]=$timetable_detail->facility;
         }

         $data2[$j]= $response2;


      $j++;
   } // timetable details close loop

         $response3["period"]= $data2;
         $response1[] = $response3;

          $timetable_details_section["timetable"]=$response1;

         }else{

              $timetable_details_section["success"]=0;
              $timetable_details_section["msg"]="timetable not created yet";

            
            } // else part of timetable


   return Response::json($timetable_details_section);

  

  } // function close




public function find_student_attendance($child_id,$month,$year){

  $student=Student::find($child_id);

  $attendances=Attendance::where('student_id','=',$child_id)
              ->whereYear('created_at', '=', $year)
              ->whereMonth('created_at', '=', $month)->get();
 //dd($attendances);
  if($attendances->isEmpty()){

              $attendance_list["success"]=0;
              $attendance_list["msg"]="attendance not found";


      }else{

        $attendance_list["success"]=1;
        $attendance_list["msg"]="attendance list success";
        foreach($attendances as $attendance){
         // $date=strtotime($attendance->date);
          //$final_date=date('d/m/Y',$date);
          $response["roll_no"]=$attendance->Student->roll_no;
          $response["date"]=$attendance->created_at->format('d-m-Y') ;
          $response["roll_no"]=$attendance->Student->roll_no;
          $response["name"]=$attendance->Student->fname.' '.$attendance->Student->lname;
          if($attendance->status == 'p'){

              $response["attendance_status"]='Present';

          }elseif($attendance->status == 'a'){

            $response["attendance_status"]='Absent';

          }else{

             $response["attendance_status"]='Leave';
          }

            $data[]=$response;

        } // attendance close loop

         $attendance_list["attendance_list"]= $data;

    }


          return Response::json($attendance_list);

  } // function close

public function find_exam($student_id){

  $student=Student::find($student_id);

  $student_exams=Exam::where('classes_id','=',$student->classes_id)->get();

  if($student_exams->isEmpty()){

              $stu_exam["success"]=0;
              $stu_exam["msg"]="student exam list not found";
              $stu_exam["exam_schedule"]=$data;

      }else{

         $stu_exam["success"]=1;
         $stu_exam["msg"]="student exam list success";
         $i=0;

     foreach($student_exams as $student_exam){

      $examschedules=ExamSchedule::where('exam_id','=',$student_exam->id)->get();

      $response1[$i]["exam_id"]=$student_exam->id;
      $response1[$i]["name"]=$student_exam->name;
      $response1[$i]["created_date"]=$student_exam->date;


    $j=0;
    $data2=array();
    foreach($examschedules as $examschedule){

         $response2["date"]=$examschedule->date;

      if($examschedule->SectionSubject->ispractical == 1){

          $response2["subject"]=$examschedule->SectionSubject->Subject->name.' '.'Practical';

      }elseif($examschedule->SectionSubject->ispractical == 0){

          $response2["subject"]=$examschedule->SectionSubject->Subject->name.' '.'Theory';

      }else{

         $response2["subject"]=$examschedule->SectionSubject->Subject->name;
      }


         $response2["total_marks"]=$examschedule->total_marks;
         $response2["time_from"]=$examschedule->from;
         $response2["time_to"]=$examschedule->to;
         $response2["facility"]=$examschedule->facility;


         $data2[$j]=$response2;


       $j++;
       } // exam schedule close loop

         $response1[$i]["exam_schedule"]= $data2;
         $stu_exam["exam"]=$response1;


     $i++;
   } // exam close loop

} //else close

   return Response::json($stu_exam);


  } // function close



public function find_classwork($subject_id){

  $student_subjects=SectionSubject::find($subject_id);
 
     if($student_subjects->count() == 0){

              $stu_classwork["success"]=0;
              $stu_classwork["msg"]="student subject and classwork list not found";
              $stu_classwork["subject"]=$data;

      }else{

         $stu_classwork["success"]=1;
         $stu_classwork["msg"]="student subject and classwork list success";
        
     $classwork=Classwork::where('section_subject_id','=',$student_subjects->id)->where('type','=',1)->whereDate('created_at','=',date("Y-m-d"))->first();
    
         if($classwork){
         $response2["subject_id"]=$student_subjects->id;
         $response2["subject_name"]=$student_subjects->Subject->name;
         $response2["date"]=$classwork->created_at->format('d/m/Y');
         $response2["title"]=$classwork->title;
         $response2["description"]=strip_tags($classwork->description);
         $response2["created_by"]=$classwork->User->Teacher->fname.' '.$classwork->User->Teacher->lname;


          $stu_classwork["classwork"]= $response2;

         }else{

                 $stu_classwork["success"]=0;
                 $stu_classwork["msg"]="No classwork created yet";

              }
         
         }

          return Response::json($stu_classwork);

  } // function close


  public function find_homework($subject_id){

  $student_subjects=SectionSubject::find($subject_id);

  if($student_subjects->count() == 0){

              $stu_homework["success"]=0;
              $stu_homework["msg"]="student subject and homework list not found";
              $stu_homework["subject"]=$data;

      }else{

         $stu_homework["success"]=1;
         $stu_homework["msg"]="student subject and homework list success";
   
 

     $homework=Classwork::where('section_subject_id','=',$student_subjects->id)->where('type','=',2)->whereDate('created_at','=',date("Y-m-d"))->first();
         if($homework){
         $response2["subject_id"]=$student_subjects->id;
         $response2["subject_name"]=$student_subjects->Subject->name;
         $response2["date"]=$homework->created_at->format('d/m/Y');
         $response2["title"]=$homework->title;
         //$response2["description"]=strip_tags(str_replace("\n", '', str_replace("\r", '',$homework->description)));
         $response2["description"]=strip_tags($homework->description);
         $response2["created_by"]=$homework->User->Teacher->fname.' '.$homework->User->Teacher->lname;
         $stu_homework["homework"]=$response2;

        }else{
               $stu_homework["success"]=0;
               $stu_homework["msg"]="No homework created yet";

             }

         }

        return Response::json($stu_homework);

  } // function close



public function find_school_info(){

  $school_info=Info::find(1);
  //dd($school_info);
  if($school_info->count() == 0){

              $info["success"]=0;
              $info["msg"]="school info not found";


      }else{

          $info["success"]=1;
          $info["msg"]="school info success";
          $info["school_name"]=$school_info->school_name;
          $info["email"]=$school_info->email;
          $info["logo"]=asset('uploads/img/'.$school_info->logo);
          $info["address"]=$school_info->address;
          $info["phone"]=$school_info->phone;
       }


          return Response::json($info);

  } // function close


  public function find_class_teachers($parent_id){

     $students=Student::where('parent_id','=',$parent_id)->get();

  if($students->isEmpty()){

              $class_teacher["success"]=0;
              $class_teacher["msg"]="teacher list not found";
              $response["teacher_id"]="";
              $response["name"]="";
              $response["address"]="";
              $response["email"]="";
              $response["phone"]="";
              $response["class_teacher"]="";
              $data[]=$response;
              $class_teacher["teacher_list"]=$data;

      }else{

         $class_teacher["success"]=1;
         $class_teacher["msg"]="teacher list success";
        foreach($students as $student){

            $section_subjects=SectionSubject::where('classes_id','=',$student->classes_id)->get();
            foreach ($section_subjects as $section_subject)
             {
                 $teachers[] = $section_subject->teacher_id;

             }


        } // student close loop
           $values = array_unique($teachers);

            foreach($values as $val){

              //dd($val);
              $teacher =Teacher::find($val);
              //dd($teacher);
              $response["teacher_id"]=$teacher->id;
              $response["name"]=$teacher->fname." ".$teacher->lname;
              $response["address"]=strip_tags($teacher->address);
              $response["email"]=$teacher->User->email;
              $response["phone"]=$teacher->phone_1;
              $response["class_teacher"]=$teacher->Classes->name."".$teacher->Section->name;
              $data[]=$response;


            }

         $class_teacher["teacher_list"]= $data;

    }


          return Response::json($class_teacher);

  } // function close




public function getTeacherClasses($action,$user_id){
    
  if($action == 'teacher_classlist'){
     
      $teacher=User::find($user_id);
      if($teacher){

         $response =$this->getClasses($teacher->Teacher->id);
         return $response;

      }else{
           
           $response["success"]=0;
           $response["message"]='Invalid User';
           return $response;

      }

     


   }else{


           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;

      }

 } //function close

public function getClasses($teacher_id){

   
    $teacher_subjects=SectionSubject::where('teacher_id','=',$teacher_id)->get();
    if($teacher_subjects){
   
        foreach($teacher_subjects as $teacher_subject){

           $teacher_timetables[]=TimetableDetails::where('section_subject_id','=', $teacher_subject->id)->get();
           $classes[] = $teacher_subject->Classes;
          
         
        }

     $class = array_unique($classes);
     $class_list["success"] = 1;
     $class_list["msg"]="teacher class list";
      foreach($class as $key => $value){
    
        $response["id"]=$value['id'];
        $response["class_name"]=$value['name'];
        $data[]=$response;
      } // close foreach
      
      $class_list["class_list"]= $data;

      }else{
              $class_list["success"] = 0;
              $class_list["msg"]="No subjects alloted yet";

          }

       return Response::json($class_list);

     }


public function getTeacherSection($action,$classes_id){

  if($action == 'teacher_sectionlist'){

      $data =$this->getSection($classes_id);
      return $data;


   }else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;

      }

 } //function close



 public function getSection($class_id){

   
     $classes = Classes::find($class_id);
     if($classes){
         $section_list["success"] = 1;
         $section_list["msg"]="section list";
      foreach($classes->Section as $section){
    
        $response["id"]=$section['id'];
        $response["section_name"]=$section['name'];
        $data[]=$response;
      } // close foreach
      
      $section_list["section_list"]= $data;

      }else{
              $section_list["success"] = 0;
              $section_list["msg"]="No section created yet";

          }

       return Response::json($section_list);

     }






 public function getTeacherSubject($action,$section_id,$user_id){

  if($action == 'teacher_subjectlist'){

    $data =$this->getSubject($section_id,$user_id);
    return $data;


  }else{

   $response["success"]=0;
   $response["message"]='Not a valid action';
   return $response;

 }

 } //function close

  public function getSubject($user_id,$section_id){

    $week_day = substr(date("l"), 0, 3);
    $val = '';
    $user = User::find($user_id);
    
    $teacher_subjects=SectionSubject::where('teacher_id','=',$user->Teacher->id)->where('section_id','=',$section_id)->get();
    
   if($teacher_subjects){

    foreach($teacher_subjects as $teacher_subject){
    $timetable = TimetableDetails::where('section_id','=',$section_id)->where('week_day','=',$week_day)->where('section_subject_id','=', $teacher_subject->id)->get();
    

    if($timetable->count() > 0)
        $data[] = $timetable;
    else
        $error = 0;   

    }
    
    if(isset($error)){
       
       $subject_list["success"] = 0;
       $subject_list["msg"]="Invalid Teacher Subject";
       $subject_list["subject_list"]= '';

    }else{

     $subject_list["success"] = 1;
     $subject_list["msg"]="Teacher Timetable List";



     foreach($data as $data){

      foreach($data as $dat){

        $section_subject=SectionSubject::find($dat['section_subject_id']);

        $response['period'] = $dat['lecture_num'];
        $response['subject'] = $section_subject->Subject->name ;
        $response['subject_id'] = $section_subject->id;
        $values[] = $response;
         } //1st data loop

   } // 2nd data loop 

   $subject_list["subject_list"]= $values;

     }  // else close if not error

   }else{

       $subject_list["success"] = 0;
       $subject_list["msg"]="No subject alloted to teacher";

      }
 
       return Response::json($subject_list);


  } // function close

public function find_event(){

  $events=SchoolEvent::orderBy('id','desc')->get();

  if($events->count() == 0){

              $info["success"]=0;
              $info["msg"]="No event list found";



      }else{
         $info["success"]=1;
         $info["msg"]="Event List";
       foreach($events as $event){

          $response["date"]=$event->created_at->format('d/m/Y');
          $response["title"]=$event->title;
          $response["description"]=strip_tags(str_replace("\n", '', str_replace("\r", '',$event->description)));
          $response["start_time"]=$event->start_time;
          $response["end_time"]=$event->end_time;
          $values[] = $response;
        
        }
        
           $info["event_list"]= $values;
         
       }


          return Response::json($info);

  } // function close



  public function find_gallery($student){

  $photos=Photo::where('classes_id','=',$student->classes_id)->get();
  
  if($photos->count() == 0){

              $info["success"]=0;
              $info["msg"]="Photo Gallery list not found";

      }else{

         $info["success"]=1;
         $info["msg"]="Photo Gallery list found";
   $i = 0 ;
   $j = 0 ;
  
    foreach($photos as $photo){
         
         $response1["id"]=$photo->id;
         $response1["date"]=$photo->date;
         $response1["title"]=$photo->event;

      $gallerys=Galleries::where('photo_id','=',$photo->id)->get();
     
      foreach($photo->Galleries as $gallery){

         $response2["image_name"]= asset('uploads/gallery/'.$gallery->image_name_new);
         $data2[]=$response2;


      $j++;
    } // gallery close loop
        

           $response1['gallery_image'] = $data2;
           $data1[] = $response1;
           $data2 = array();
          


      $i++;
     } // photos close loop

      
          $info["photo"]= $data1;
 

     
 
}

          return Response::json($info);

  } // function close


  public function find_student($sections_id){

     $students=Student::where('section_id','=',$sections_id->id)->get();
   
    if($students){

         $info["success"]=1;
         $info["msg"]="Student List Found";
       foreach($students as $student){
          
          $response["id"]=$student->id;
          $response["class_name"]=$student->Classes->name;
          $response["section"]=$student->Section->name;
          $response["roll_no"]=$student->roll_no;
          $response["first_name"]=$student->fname;
          $response["middle_name"]=$student->mname;
          $response["last_name"]=$student->lname;

          $studentUpdate =StudentBulletin::where('student_id', $student->id)->whereDate('created_at', '=',  date('Y-m-d'))->first();
          
           if($studentUpdate){
                
                $response['teacher_update_id'] = $studentUpdate->id;
                $response['teacher_update_title'] = $studentUpdate->title;
                $response['teacher_update_description'] = strip_tags($studentUpdate->description);

            }else{

                $response['teacher_update_id'] = '';
                $response['teacher_update_title'] = '';
                $response['teacher_update_description'] = '';

               }

          $values[] = $response;
        
        }
        
           $info["student_list"]= $values;

          
      }else{
        
              $info["success"]=0;
              $info["msg"]="No students list found";

         
       }


          return Response::json($info);

  } // function close



  public function find_child_update($student_id){


  $student_bulletins=StudentBulletin::where('student_id','=',$student_id)->get();
   
  if($student_bulletins->isEmpty()){

              $stu_bulletin["success"]=0;
              $stu_bulletin["msg"]="student update list not found";
              $response["class"]="";
              $response["section"]="";
              $response["title"]="";
              $response["description"]="";
              $data[]=$response;
              $stu_bulletin["child_update_list"]=$data;

      }else{

         $stu_bulletin["success"]=1;
         $stu_bulletin["msg"]="student update list found";
        foreach($student_bulletins as $student_bulletin){
          $response["class_name"]=$student_bulletin->Classes->name;
          $response["section"]=$student_bulletin->Section->name;
          $response["title"]=$student_bulletin->title;
          $response["description"]=strip_tags($student_bulletin->description);
          $response["created_by"]=$student_bulletin->User->Teacher->fname.' '.$student_bulletin->User->Teacher->lname;
          $response["created_date"]=$student_bulletin->created_at->format('d/m/Y');
          $data[]=$response;
        } // student update close loop

         $stu_bulletin["child_update_list"]= $data;

    }


          return Response::json($stu_bulletin);

  } // function close



public function postStudentUpdate($action,$teacher_id,$student_id,$title,$description){



  if($action == 'teacher_post_update'){

     $student = Student::find($student_id);
     if(empty($student)){
           $response["success"]=0;
           $response["message"]='No child found';
           return $response;
         } // empty student check
     else{
           $teacher= User::find($teacher_id);
           if(empty($teacher)){
               $response["success"]=0;
               $response["message"]='No teacher found';
               return $response;

            }else{
              $post_update=$this->post_update_teacher($teacher_id,$student,$title,$description);
              return $post_update; 
            }

          }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

  } // function close


 public function post_update_teacher($teachers_id,$student_data,$title,$description){


 
     if($title == " " || $description == " " ){

              $stu_update["success"]=0;
              $stu_update["msg"]="Please enter a valid title and description";
              
      }else{

         $update =StudentBulletin::where('student_id', $student_data->id)->whereDate('created_at', '=',  date('Y-m-d'))->first();
         if($update){
             $update->title = $title;
             $update->description = $description;
         if($update->save()){
                 $stu_update["success"]=1;
                 $stu_update["msg"]="successfully updated student update";
             }  

         }else{
             $update = new StudentBulletin;
             $update->classes_id = $student_data->Classes->id;
             $update->section_id = $student_data->Section->id;
             $update->student_id = $student_data->id;
             $update->title = $title;
             $update->description = $description;
             $update->created_by = $teachers_id;
             $update->status = 1;
            if($update->save()){
                 $stu_update["success"]=1;
                 $stu_update["msg"]="successfully updated student update";
             }  
        }
       

    }


          return Response::json($stu_update);

  } // function close



  public function postClassworkHomework($action,$teacher_id,$subject_id,$classworkTitle,$classworkDescription,$homeworkTitle,$homeworkDescription){



  if($action == 'teacher_post_classwork'){

     $sectionSubject = SectionSubject::find($subject_id);
     if(empty($sectionSubject)){
           $response["success"]=0;
           $response["message"]='Subject not found';
           return $response;
         } // empty student check
     else{
              $teacher = User::find($teacher_id);
              if(empty($teacher)){
                 $response["success"]=0;
                 $response["message"]='Teacher not found';
                 return $response;
                } // teacher empty check
            else{
           $post_update=$this->post_update_work($teacher->id,$sectionSubject,$classworkTitle,$classworkDescription,$homeworkTitle,$homeworkDescription);
           return $post_update;
               }

         }

   }// if action fails
     else{

           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }

  } // function close



public function post_update_work($teachers_id,$sectionSubject,$classworkTitle,$classworkDescription,$homeworkTitle,$homeworkDescription){


 
     if($classworkTitle == " " || $classworkDescription == " " ){

              $stu_update["success"]=0;
              $stu_update["msg"]="Please enter a valid classwork title and description";
              
      }elseif($homeworkTitle == " " || $homeworkDescription == " "){

              $stu_update["success"]=0;
              $stu_update["msg"]="Please enter a valid homework title and description";

      }else{
        
        $classwork_homework=Classwork::where('section_subject_id','=',$sectionSubject->id)->where('type','=',1)->whereDate('created_at', '=',  date('Y-m-d'))->get();
        
        
            $classwork = new Classwork;
            $classwork->section_id = $sectionSubject->section_id;
            $classwork->section_subject_id = $sectionSubject->id;
            $classwork->title = $classworkTitle;
            $classwork->description = $classworkDescription;
            $classwork->created_by = $teachers_id;
            $classwork->type = 1;
         
            $homework = new Classwork;
            $homework->section_id = $sectionSubject->section_id;
            $homework->section_subject_id = $sectionSubject->id;
            $homework->title = $homeworkTitle;
            $homework->description = $homeworkDescription;
            $homework->created_by = $teachers_id;
            $homework->type = 2;
          if($classwork_homework->isEmpty()){
            $classwork->save();
            $homework->save();
            $stu_update["success"]=1;
            $stu_update["msg"]="successfully updated classwork and homework";
               
          }else{

               $stu_update["success"]=0;
               $stu_update["msg"]="Classwork/Homework already assigned by you for today";
           
         }  

    }


          return Response::json($stu_update);

  } // function close




public function getClassworkHomework($action,$subject_id){


if($action == 'teacher_get_classwork_homework'){
   
     $subject=SectionSubject::find($subject_id);

     if($subject){

       $response = $this->find_classwork_homework($subject->id);
       return $response;

         } // empty student check
         else{
          $response["success"]=0;
          $response["message"]='Subject not found';
          return $response;

        }

   }else{
          
           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }


}



 public function find_classwork_homework($subject_id){


    $classwork_homework=Classwork::where('section_subject_id','=',$subject_id)->whereDate('created_at', '=',  date('Y-m-d'))->get();
  
  
    if($classwork_homework->isEmpty()){

              $finalData["success"]=0;
              $finalData["msg"]="Classwork/Homework not found";


      }else{
             
          $finalData["success"]=1;
         $finalData["msg"]="Classwork/Homework list found";
         foreach($classwork_homework as $classwork){
          
          if($classwork->type == 1){
              $response["title"]=$classwork->title;
              $response["description"]=strip_tags($classwork->description);
              $response["type"] = 'classwork';
           }


        } // student update close loop

         $finalData["classwork"]= $response;

          foreach($classwork_homework as $homework){
          
          if($homework->type == 2){
              $response["title"]=$homework->title;
              $response["description"]=strip_tags($homework->description);
              $response["type"] = 'homework';
           }


        } // student update close loop

           $finalData["homework"]= $response;
             
           }


          return Response::json($finalData);

  } // function close


public function postStudentLocation($action,$bus_id,$latitude,$longitude){


if($action == 'insert_location'){
   
     $bus=Bus::find($bus_id);

     if($bus){

       $response = $this->addLocation($bus->id,$latitude,$longitude);
       return $response;

         } // empty student check
         else{
          $response["success"]=0;
          $response["message"]='Bus not found';
          return $response;

        }

   }else{
          
           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }


}



public function addLocation($bus_id,$lat,$long){

     if($lat == " " || $long == " " ){

              $stu_update["success"]=0;
              $stu_update["msg"]="Please enter a valid latitude and longitude";
              
      
      }else{
        

         $location = new BusLocation;
         $location->bus_id = $bus_id;
         $location->latitude = $lat;
         $location->longitude = $long;

        if($location->save()){
            $stu_update["success"]=1;
            $stu_update["msg"]="successfully updated latitute and longitude";
         }  

    }


          return Response::json($stu_update);
  } // function close


public function getStudentLocation($action,$bus_id,$offset){


if($action == 'find_location'){
   
     $bus = Bus::find($bus_id);

     if($bus){

       $response = $this->getLocation($bus->id,$offset);
       return $response;

         } // empty bus check
         else{
          $response["success"]=0;
          $response["message"]='Bus not found';
          return $response;

        }

   }else{
          
           $response["success"]=0;
           $response["message"]='Not a valid action';
           return $response;
         }


}

public function getLocation($bus_id,$offset){
  
  //$limit = (int)$offset;
 
  if($offset > 0)
    $locations = BusLocation::where('bus_id', $bus_id)->take(10)->skip($offset)->get();
  else
    $locations = BusLocation::where('bus_id', $bus_id)->take(10)->get();

   
  if($locations->count() == 0){

              $info["success"]=0;
              $info["msg"]="No location details found";



      }else{
         $info["success"]=1;
         $info["msg"]="Location details found";
       foreach($locations as $location){
          $response["location_id"]=$location->id;
          $response["bus_no"]=$location->Bus->bus_no;
          $response["latitude"]=$location->latitude;
          $response["longitude"]=$location->longitude;
          $response["created_at"]=$location->created_at->format('Y/m/d h:i:s');
          $values[] = $response;
        
        }
        
           $info["location_details"]= $values;
         
       }


          return Response::json($info);

  } // function close



} // main function
