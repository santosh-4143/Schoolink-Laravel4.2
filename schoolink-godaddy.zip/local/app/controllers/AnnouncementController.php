<?php
use Carbon\Carbon;
class AnnouncementController extends \BaseController {

	
	public function index()
	{
		$announcements = Announcement::orderBy('id','desc')->get();
		return View::make('bulletin.index')
		->with('announcements', $announcements)
		->with('title','All School Update')
		->with('page','Manage School Update');
	}

	public function create()
	{
	   
		return View::make('bulletin.create')
		->with('title','Create School Update')
		->with('page','Manage School Update');
	}


	public function store()
	{
		//$carbon = Carbon::now(new DateTimeZone('Asia/kolkata'));
		//dd($carbon);
		$rules = array(
			'title'      => 'required',
			'description'=> 'required'			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) 
		{
			return Redirect::back()
			->withErrors($validator)
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		} 
		else 
		{
			// store
			$announcement = new Announcement;
			$announcement->title    = ucwords(strtolower(Input::get('title')));
			$announcement->description   = Input::get('description');	
			$announcement->status = 1;
			$created_by = "";
			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = "Teacher";
				}
			}	
			$announcement->created_by = $created_by;
			$announcement->save();
			
			if(isset($announcement->id) && $announcement->id!='' )
			 {

			 // 	$users =  User::where('user_type',3)->get();
			 // 	//echo "<pre>";
			 // 	//dd($users);
			 // 	foreach($users as $user){

			 // 	$Notification = new Notification;
			 // 	$Notification->user_id = $user->id;
			 // 	$Notification->subject = $announcement->title;
			 // 	$Notification->body = $announcement->description;
			 // 	//dd($user->Parents->id);
			 // 	$Notification->object_id = $user->Parents->id;
			 // 	$Notification->object_type = "Parent";
			 // 	$Notification->is_read = 0;
			 // 	$Notification->sent_at = Carbon::now(new DateTimeZone('Asia/kolkata'));
			 // 	$Notification->save();
			 // 	}

    //            // $data=array();
			 // 	$parents = Parents::all();
			 // 	//dd($parents);
			 //    foreach($parents as $parents){
			 //    	//dd($parents->email);
			 // 	$data=Announcement::find($announcement->id)->toArray();
			 		

			 //   Mail::send('emails.announcements', $data,function($message) use ($parents)
				// {
			 //     //dd($parents->email);
			 //     $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Announcement');
			   
				// });

			 // 	}
			 	return Redirect::to('announcements')
				->with('success','Succesfuly Announcement Created');
				
				}
			 else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('announcements/create');
			 }	
		}
	}
	public function StudentBulletin()
	{
		$data = StudentBulletin::all();
		return View::make('bulletin.view_student_bulletin')
		->with('title','All Student Bulletin')
		->with('page','Manage Announcements')
		->with('studentbulletins',$data);
	}
	public function ClassBulletin()
	{
		$data = ClassBulletin::all();
		return View::make('bulletin.view_class_bulletin')
		->with('title','All Class Bulletin')
		->with('page','Manage Announcements')
		->with('classbulletins',$data);
	}
	public function getClassBulletin()
	{
		$data = Classes::all();

		return View::make('bulletin.class_bulletin_create')
		->with('classes', Classes::all())
		->with('title','Class Bulletin')
		->with('page','Manage Announcements');
	}

	public function postClassBulletin()
	{
		
		
		$rules = array(
			'classes_id'    => 'required',
			'title' 		=> 'required',
			'description'   => 'required'			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) 
		{
			return Redirect::to('get-class-bulletin')
			->withErrors($validator)
			->with('title','Class Bulletin')
			->with('page','Manage Announcements')
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		} 
		else 
		{
			$ClassBulletin = new ClassBulletin;
			
			$ClassBulletin->classes_id    = Input::get('classes_id');
			$ClassBulletin->title    = ucwords(strtolower(Input::get('title')));
			$ClassBulletin->description   = Input::get('description');	
			$created_by = "";
			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = "Teacher";
				}
			}	
			$ClassBulletin->created_by = $created_by;
			$ClassBulletin->status = 1;
			$ClassBulletin->save();
			if(isset($ClassBulletin->id) && $ClassBulletin->id!='' )
			 {
				$students =  Student::where('classes_id', Input::get('classes_id'))->get();
				$data_final=array();
				foreach($students as $student)
				{
					$parent_id = $student->parent_id;
					//dd($parent_id);
					$users = Parents::find($parent_id)->user;
					//dd($users);
					$Notification = new Notification;
				 	$Notification->user_id = $users->id;
				 	$Notification->student_id = $student->id;
				 	$Notification->subject = $ClassBulletin->title;
				 	$Notification->body = $ClassBulletin->description;
				 	$Notification->object_id = $users->Parents->id;
				 	$Notification->object_type = "Parent";
				 	$Notification->is_read = 0;
				 	$Notification->sent_at = Carbon::now(new DateTimeZone('Asia/kolkata'));
				 	$Notification->save();


		       $data = ClassBulletin::find($ClassBulletin->id)->toArray();

			   $parents = Parents::find($parent_id);	

			   Mail::send('emails.classbulletin', $data,function($message) use ($parents)
				{
			     //dd($parents->email);
			     $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Class Bulletin');
			   
				});

				}
            
				Session::flash('success', 'Class Bulletin successfully created');
				return Redirect::to('get-class-bulletin')
				->with('title','Class Bulletin')
				->with('page','Manage Announcements');
			 }			
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('get-class-bulletin')
				->with('title','Class Bulletin')
				->with('page','Manage Announcements');
			 }
						
		}
	}
	
	public function getStudentBulletin()
	{
		
		return View::make('bulletin.student_bulletin_create')
		->with('classes', Classes::all())
		->with('title','Student Bulletin')
		->with('page','Manage Announcements');
	}
	public function postStudentBulletin()
	{
		//$users = Parents::find(Input::get('student_id'))->user;
		//$Parents = Parents::find(Input::get('student_id'))->students;
		//$Students =  Student::where('classes_id', '=',Input::get('classes_id'))->parents;
	 	//$users = User::find($Students->parents_id)->get();
		// //$parents = Parents::with($students)->get();
		//$parents = $Students->Parents;
		 //dd($users);

		$rules = array(
			'classes_id'    => 'required',
			'section_id'    => 'required',
			'student_id'    => 'required',
			'title' 		=> 'required',
			'description'   => 'required'			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) 
		{
			return Redirect::to('get-student-bulletin')
			->withErrors($validator)
			->with('title','Student Bulletin')
			->with('page','Manage Announcements')
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		} 
		else 
		{
			$StudentBulletin = new StudentBulletin;
			
			$StudentBulletin->classes_id    = Input::get('classes_id');
			$StudentBulletin->section_id    = Input::get('section_id');
			$StudentBulletin->student_id    = Input::get('student_id');
			$StudentBulletin->title    = ucwords(strtolower(Input::get('title')));
			$StudentBulletin->description   = Input::get('description');	
			$created_by = "";
			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = "Teacher";
				}
			}	
			$StudentBulletin->created_by = $created_by;
			$StudentBulletin->status = 1;
			$StudentBulletin->save();
			if(isset($StudentBulletin->id) && $StudentBulletin->id!='' )
			 {
			 	$stu = Student::find(Input::get('student_id'));
                $users = Parents::find($stu->parent_id)->User;   
			 	//$users =  User::where('user_type',3)->get();
			 	
			 	//dd($users);
			 	$Notification = new Notification;
			 	$Notification->user_id = $users->id;
			 	$Notification->student_id = Input::get('student_id');
			 	$Notification->subject = $StudentBulletin->title;
			 	$Notification->body = $StudentBulletin->description;
			 	$Notification->object_id = $users->Parents->id;
			 	$Notification->object_type = "Parent";
			 	$Notification->is_read = 0;
			 	$Notification->sent_at = Carbon::now(new DateTimeZone('Asia/kolkata'));
			 	$Notification->save();
                
               $data = StudentBulletin::find($StudentBulletin->id)->toArray();

			   $parents = Parents::find($stu->parent_id);	

			   Mail::send('emails.studentbulletin', $data,function($message) use ($parents)
				{
			     //dd($parents->email);
			     $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Student Bulletin');
			   
				});



			 	

				Session::flash('success', 'Student Bulletin successfully created');
				return Redirect::to('get-student-bulletin')
				->with('title','Student Bulletin')
				->with('page','Manage Announcements');
			 }			
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('get-student-bulletin')
				->with('title','Student Bulletin')
				->with('page','Manage Announcements');
			 }
						
		}
		
	}

	public function show($id)
	{
		$announcements = Announcement::find($id);
		return View::make('bulletin.view')
		->with('announcements', $announcements)
		->with('title','View School Update')
		->with('page','Manage School Update');
	}

	public function edit($id)
	{
		$announcements = Announcement::find($id);
		return View::make('bulletin.edit')
		->with('announcements', $announcements)
		->with('title','Edit School Update')
		->with('page','Manage School Update');
	}

	public function update($id)
	{
		
		$rules = array(
			'title'      => 'required',
			'description'=> 'required'			
		);
		$validator = Validator::make(Input::all(), $rules);

		
		if ($validator->fails()) 
		{
			return Redirect::back()
			->withErrors($validator)
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		} 
		else 
		{
			// store
			$announcement = Announcement::find($id);
			$announcement->title    =       Input::get('title');
			$announcement->description   = Input::get('description');	
			$announcement->status = 1;
			$created_by = "";
			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = "Teacher";
				}
			}	
			$announcement->created_by = $created_by;
			$announcement->save();
			
			if(isset($announcement->id) && $announcement->id!='' )
			   
			 	return Redirect::to('announcements')->with('success','Succesfully Updated Announcement');
			   
			 else
				return Redirect::back()->with('error','Oops ! something went wrong pls try again');
			 
		}
	}

	public function postDeleteAnnouncement()
	{
		$id = Input::get('announcement_id');
		$announcement = Announcement::find($id);
		$announcement->delete();
		return Redirect::to('announcements')->with('success','Succesfully Deleted Announcement');

	}


}
