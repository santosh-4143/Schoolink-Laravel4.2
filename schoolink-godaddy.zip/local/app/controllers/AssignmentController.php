<?php

class AssignmentController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create($sectionsub_id)
	{  
	     $sec_sub_id = SectionSubject::find($sectionsub_id);
	     $assignments = Assignment::where('section_subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->orderBy('id','DESC')->get();
       
		return View::make('assignment.create')
		->with('title','Create Assignment')
		->with('page','Manage Assignments')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('assignments',$assignments);

	}

public function create_test($sectionsub_id)
	{  
	     $sec_sub_id = SectionSubject::find($sectionsub_id);
	  
	     $test = Assignment::where('section_subject_id','=',$sec_sub_id->id)->where('type', '=', 2)->orderBy('id','DESC')->get();

		return View::make('assignment.create_test')
		->with('title','Create Test')
		->with('page','Manage Tests')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('assignments',$test);

	}

   	public function listClasses()
	{	$classes = Classes::all();
		//$sections = Section::all();
		//dd($classes);
		 return View::make('assignment.listclass')
		->with('title', 'Create Assignment')
		->with('page','Manage Assignments')
		->with('classes', $classes);
	}  

    
	public function get_section_subjects(){
     $section_id = Input::get('section_id');
     $section=Section::find($section_id);
     $data['class']=$section->Classes->name;
     $data['section']=$section->name;
	 $section_subjects = SectionSubject::where('section_id','=',$section_id)->get();
	 $name=array();
    
	foreach($section_subjects as $section_subject){
      
       
        //$data=array();
        //$query=DB::table('section_subjects')->where('subject_id','=', $section_subject->subject_id)->where('section_id','=',$section_id)->get();
        $data['name'] =$section_subject->Subject->name;
        $data['subject_id'] =$section_subject->Subject->id;
        $data['id'] = $section_subject->id;
        $data['ispractical'] = $section_subject->ispractical;

      
        $name[]= $data;
       // $id[]=("hello");
	}

	//dd(Response::Json($name));
	  return Response::Json($name); 
	  //return $query;
	}

public function get_section_subjects_id(){

     $section_id = Input::get('section_id');
	 $subject_id = Input::get('subject_id');
	 $section_subjects = SectionSubject::where('section_id','=',$section_id)->where('subject_id','=',$subject_id)->get();
	foreach($section_subjects as $section_subject){
      
         $name[]=$section_subject;
	}
	  return $name;  
	}

public function postAssignmentpublish($assignment_id){

	    $assignments = Assignment::find($assignment_id);
	    $assignments->publish_status=1;
        $assignments->save();

        $assignment= Assignment::find($assignment_id)->get();
        //dd($assignment);
        $students=Student::where('section_id','=', $assignments->section_id)->get();
        
        foreach($students as $student){

       
        $parents=Parents::find($student->parent_id);
           //dd($parents);
        $student_id=$student->id;
        //dd($student_id);
        $data= array('assignments' => $assignments, 'student_id' => $student_id);

        Mail::send('emails.assignment',$data,function($message) use ($parents)
		 {
			     
	      $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Assignment');
			   
	     });



        }

        
        
		 return Redirect::to('assignment-create/'.$assignments->section_subject_id)
		->with('title','Create Assignment')
		->with('page','Manage Assignments');


}

public function postAssignmentMarkspublish($assignment_id){

	    $assignments = Assignment::find($assignment_id);
	    $assignments->publish_marks=1;
        $assignments->save();

       
        //dd($assignment_marks);
        
        $students=Student::where('section_id','=', $assignments->section_id)->get();
        
      foreach($students as $student){

      	$assignment_marks= AssignmentMarks::where('assignment_id','=',$assignment_id)->where('student_id','=',$student->id)->get()->toArray();

        $parents=Parents::find($student->parent_id);  
        $student_id=$student->id;
        
        $data= array('assignments' => $assignments,'assignment_marks' => $assignment_marks,'student_id' => $student_id);
        //dd($data);
        Mail::send('emails.assignmentmarks',$data,function($message) use ($parents)
		 {
			     
	      $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Assignment');
			   
	     });



        }

        
        
		 return Redirect::to('assignment-create/'.$assignments->section_subject_id)
		->with('title','Create Assignment')
		->with('page','Manage Assignments');


}



	
	public function getStudentlist($assignment_id)
	{
		 $assignment_details = Assignment::find($assignment_id);
		 $section_id=$assignment_details->Section->id;
         $students = Student::where('section_id','=',$section_id)->get();
         $assignment_marks_id = AssignmentMarks::where('assignment_id','=',$assignment_id)->get();
        
	    
         if($assignment_details->type == 1){
	        return View::make('assignment.assignmentmarks')
	     ->with('title', 'Create Assignment')
		 ->with('page','Manage Assignments')
		 ->with('students',$students )
		  ->with('assignments',$assignment_details)
		  ->with('assignment_marks',$assignment_marks_id);
        }
      if($assignment_details->type == 2){
          return View::make('assignment.testmarks')
	     ->with('title', 'Create Test')
		 ->with('page','Manage Test')
		 ->with('students',$students )
		  ->with('assignments',$assignment_details)
		  ->with('assignment_marks',$assignment_marks_id);


      }

	} 

	public function postAssignmentmarks()
	{
		
			$rules = array(
			'marks'       => 'required'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('assignment-create')
			->withErrors($validator)
			->with('title','Create Assignment')
			->with('page','Manage Assignments');
			

				
		} else {
			// store
			//$student_id=array();
			$student_id=Input::get('student_id');
			$marks=Input::get('marks');
			$comments=Input::get('comments');


			//dd($student_id);
			$student_size=sizeof($student_id);
           

		for($i=0;$i<$student_size;$i++){

            $assignment_marks = new AssignmentMarks;
			$assignment_marks->assignment_id = Input::get('assignment_id');
		    $assignment_marks->student_id = $student_id[$i];
		    $assignment_marks->marks_obtained = $marks[$i];
			$assignment_marks->comments  = $comments[$i];
			$assignment_marks->admin_id = Auth::user()->id;
					
			//dd("<pre>".$assignment_marks->admin_id."</pre>");		
			$assignment_marks->save();
            }
           $update_assignment_status=Assignment::find(Input::get('assignment_id'));
           $update_assignment_status->isChecked = 1;
		   $update_assignment_status->save();
			// redirect
			
			 Session::flash('success', 'Successfully marked Assignment!');
			 return Redirect::to('assignment-marks/'.$assignment_marks->assignment_id)
			 ->with('title','Create Assignment')
			 ->with('page','Manage Assignments');

		}


	}  





  	
	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		///dd(Input::all());
			$rules = array(
			'code'       => 'required|unique:subjects',
			'name'  	 => 'required',
			'description'=> 'required',
			'total_marks'=> 'required',
			'date'  	 => 'required',
			'type' =>'required',
			'section_sub_id'=>'required',
            'section_id' =>'required',
            'user_id' =>'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('assignment-create')
			->withErrors($validator)
			->with('title','Create Assignment')
			->with('page','Manage Assignments');
			

				
		} else {
			// store
			$assignments = new Assignment;
			$assignments->code  = Input::get('code');
			$assignments->title  = Input::get('name');			
			$assignments->description = Input::get('description');	
			$assignments->total_marks = Input::get('total_marks');	
			$assignments->date  = Input::get('date');
			$assignments->type = Input::get('type');	
			$assignments->subject_id = Input::get('section_sub_id');
			$assignments->section_id = Input::get('section_id');
			$assignments->admin_id = Input::get('user_id');	
					
			$assignments->save();

			// redirect
			
			Session::flash('success', 'Successfully created Assignment!');
			return Redirect::to('assignment-create/'.$assignments->subject_id)
			->with('title','Create Assignment')
			->with('page','Manage Assignments');

		}
	}

	public function store_test()
	{
		///dd(Input::all());
			$rules = array(
			'code'       => 'required|unique:subjects',
			'name'  	 => 'required',
			'description'=> 'required',
			'total_marks'=> 'required',
			'date'  	 => 'required',
			'type' =>'required',
			'section_sub_id'=>'required',
            'section_id' =>'required',
            'user_id' =>'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('test-create')
			->withErrors($validator)
			->with('title','Create Assignment')
			->with('page','Manage Assignments');
			

				
		} else {
			// store
			$tests = new Assignment;
			$tests->code  = Input::get('code');
			$tests->title  = Input::get('name');			
			$tests->description = Input::get('description');	
			$tests->total_marks = Input::get('total_marks');	
			$tests->date  = Input::get('date');
			$tests->type = Input::get('type');	
			$tests->subject_id = Input::get('section_sub_id');
			$tests->section_id = Input::get('section_id');
			$tests->admin_id = Input::get('user_id');	
					
			$tests->save();

			// redirect
			
			Session::flash('success', 'Successfully created Test!');
			return Redirect::to('test-create/'.$tests->subject_id)
			->with('title','Create Test')
			->with('page','Manage Tests');

		}
	}

	public function postTestpublish($assignment_id){

	    $assignments = Assignment::find($assignment_id);
	    $assignments->publish_status=1;
        $assignments->save();
        
        $assignment= Assignment::find($assignment_id);
        //dd($assignment);
        $students=Student::where('section_id','=', $assignments->section_id)->get();
        
        foreach($students as $student){

       
        $parents=Parents::find($student->parent_id);
           //dd($parents);
        $student_id=$student->id;
        //dd($student_id);
        $data= array('assignments' => $assignments, 'student_id' => $student_id);
        
        //dd($data);
        Mail::send('emails.test',$data,function($message) use ($parents)
		 {
			     
	      $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Test');
			   
	     });
       }
		 return Redirect::to('test-create/'.$assignment->section_subject_id)
		->with('title','Create Test')
		->with('page','Manage Tests');


}


public function postTestmarks()
	{
		
			$rules = array(
			'marks'       => 'required'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('assignment-create')
			->withErrors($validator)
			->with('title','Create Assignment')
			->with('page','Manage Assignments');
			

				
		} else {
			// store
			//$student_id=array();
			$student_id=Input::get('student_id');
			$marks=Input::get('marks');
			$comments=Input::get('comments');


			//dd($student_id);
			$student_size=sizeof($student_id);
           

		for($i=0;$i<$student_size;$i++){

            $assignment_marks = new AssignmentMarks;
			$assignment_marks->assignment_id = Input::get('assignment_id');
		    $assignment_marks->student_id = $student_id[$i];
		    $assignment_marks->marks_obtained = $marks[$i];
			$assignment_marks->comments  = $comments[$i];
			$assignment_marks->admin_id = Auth::user()->id;
					
			//dd("<pre>".$assignment_marks->admin_id."</pre>");		
			$assignment_marks->save();
            }
           $update_test_status=Assignment::find(Input::get('assignment_id'));
           $update_test_status->isChecked = 1;
		   $update_test_status->save();
			// redirect
			
			 Session::flash('success', 'Successfully marked Test!');
			 return Redirect::to('assignment-marks/'.$assignment_marks->assignment_id)
			 ->with('title','Create Assignment')
			 ->with('page','Manage Assignments');

		}


	}


	public function postTestMarkspublish($assignment_id){

	    $assignments = Assignment::find($assignment_id);
	    $assignments->publish_marks=1;
        $assignments->save();

       
        //dd($assignment_marks);
        
        $students=Student::where('section_id','=', $assignments->section_id)->get();
        
      foreach($students as $student){

      	$assignment_marks= AssignmentMarks::where('assignment_id','=',$assignment_id)->where('student_id','=',$student->id)->get()->toArray();

        $parents=Parents::find($student->parent_id);  
        $student_id=$student->id;
        
        $data= array('assignments' => $assignments,'assignment_marks' => $assignment_marks,'student_id' => $student_id);
        //dd($data);
        Mail::send('emails.testmarks',$data,function($message) use ($parents)
		 {
			     
	      $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Test');
			   
	     });
        }

         return Redirect::to('test-create/'.$assignments->section_subject_id)
		->with('title','Create Assignment')
		->with('page','Manage Assignments');
   }


public function getAssignmentGraph($sectionsub_id)
	{  
	     $sec_sub_id = SectionSubject::find($sectionsub_id);
	    // $assignment_id=Assignment::find($sectionsub_id);
		//dd('<pre>'.$sec_sub_id->section_id.'</pre>');
		//dd('<pre>'.$assignment_id.'</pre>');
	     //$assignments = Assignment::where('subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->orderBy('id','desc')->take(2)->get();
         $students=Student::where('section_id','=',$sec_sub_id->section_id)->get();
          //dd('<pre>'.$students.'</pre>');
		return View::make('assignment.assignmentgraph')
		->with('title','Create Assignment')
		->with('page','Manage Assignments')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('students',$students);

	}


public function viewAssignmentGraph()
	{  
         $section_id = Input::get('section_id');
	     $student_id  = Input::get('student');
	     $secsub_id = Input::get('sec_sub_id');
         $rules = array(
			'student'       => 'required'
			
		   );
        
        $sec_sub_id=SectionSubject::find($secsub_id);
	    $students=Student::where('section_id','=',$section_id)->get();
		
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('assignment-graph/'.$secsub_id)
			->withErrors($validator)
			->with('title','Create Assignment')
			->with('page','Manage Assignments')
			->with('sec_sub_id',$sec_sub_id)
            ->with('students',$students);

		} else {
	    

	     
	     $selected_students=Student::where('id','=',$student_id)->get();
          //dd("<pre>".$selected_students."</pre>");
         $assignment_lasts = Assignment::where('subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->orderBy('id','desc')->take(1)->get();
           //dd("<pre>".$assignment_last->id."</pre>");
         foreach($assignment_lasts as $assignment_last){

           $marks_lasts=AssignmentMarks::where('assignment_id','=',$assignment_last->id)->where('student_id','=',$student_id)->get();
           $total_marks_last=$assignment_last->total_marks;

         }
         if($assignment_lasts->isempty()){

             Session::flash('error', 'No Assignment created for this Subject!');
           return Redirect::to('assignment-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);

         }else{

         if($marks_lasts->isempty()){
            Session::flash('error', 'Current Assignment Not marked for Comparision !');
           return Redirect::to('assignment-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);
             
         }else{
         foreach($marks_lasts as $marks_last){
           
           $last_percentage=$marks_last->marks_obtained/$total_marks_last*100;    
           //dd("<pre>".$last_percentage."</pre>");
         }

         $assignment_secondlasts = Assignment::where('subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->orderBy('id','desc')->skip(1)->take(1)->get();
        

        foreach($assignment_secondlasts as $assignment_secondlast){

         $marks_secondlasts=AssignmentMarks::where('assignment_id','=',$assignment_secondlast->id)->where('student_id','=',$student_id)->get(); 
         $total_marks_secondlast=$assignment_secondlast->total_marks; 
         }
         if($assignment_secondlasts->isempty()){
            Session::flash('error', 'Last Assignment Not Created for comparisions!');
           return Redirect::to('assignment-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);



         }else{
          if($marks_secondlasts->isempty()){
            Session::flash('error', 'Last Test not marked for comparisions!');
            return Redirect::to('assignment-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);
             
         }

       foreach($marks_secondlasts as $marks_secondlast){
           
           $secondlast_percentage=$marks_secondlast->marks_obtained/$total_marks_secondlast*100;    
           //dd("<pre>".$secondlast_percentage."</pre>");
         }
          
		  return View::make('assignment.assignmentgraph')
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students)
           ->with('last_percentage',$last_percentage)
           ->with('secondlast_percentage',$secondlast_percentage)
           ->with('selected_students',$selected_students);
	            }
           }
        }
       
      }
	}

	public function getTestGraph($sectionsub_id)
	{  
	     $sec_sub_id = SectionSubject::find($sectionsub_id);
	    // $assignment_id=Assignment::find($sectionsub_id);
		//dd('<pre>'.$sec_sub_id->section_id.'</pre>');
		//dd('<pre>'.$assignment_id.'</pre>');
	     //$assignments = Assignment::where('subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->orderBy('id','desc')->take(2)->get();
         $students=Student::where('section_id','=',$sec_sub_id->section_id)->get();
          //dd('<pre>'.$students.'</pre>');
		return View::make('assignment.testgraph')
		->with('title','Create Assignment')
		->with('page','Manage Assignments')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('students',$students);

	}

public function viewTestGraph()
	{  

         $section_id = Input::get('section_id');
	     $student_id  = Input::get('student');
	     $secsub_id = Input::get('sec_sub_id');
         $rules = array(
         	
		      	'student' => 'required'
		 );
        
        $sec_sub_id=SectionSubject::find($secsub_id);
	    $students=Student::where('section_id','=',$section_id)->get();
		
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('test-graph/'.$secsub_id)
			->withErrors($validator)
			->with('title','Create Assignment')
			->with('page','Manage Assignments')
			->with('sec_sub_id',$sec_sub_id)
            ->with('students',$students);

		} else {
	    

	     
	     $selected_students=Student::where('id','=',$student_id)->get();
          //dd("<pre>".$selected_students."</pre>");
         $assignment_lasts = Assignment::where('subject_id','=',$sec_sub_id->id)->where('type', '=', 2)->orderBy('id','desc')->take(1)->get();
           //dd("<pre>".$assignment_last->id."</pre>");
         foreach($assignment_lasts as $assignment_last){

           $marks_lasts=AssignmentMarks::where('assignment_id','=',$assignment_last->id)->where('student_id','=',$student_id)->get();
           $total_marks_last=$assignment_last->total_marks;

         }
          if($assignment_lasts->isempty()){

          Session::flash('error', 'No Test created for this Subject!');
            return Redirect::to('test-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);

         }else{
         if($marks_lasts->isempty()){
            Session::flash('error', 'Current Test Not marked for Comparision !');
            return Redirect::to('test-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);
             
         }else{
         foreach($marks_lasts as $marks_last){
           
           $last_percentage=$marks_last->marks_obtained/$total_marks_last*100;    
           //dd("<pre>".$last_percentage."</pre>");
         }

         $assignment_secondlasts = Assignment::where('subject_id','=',$sec_sub_id->id)->where('type', '=', 2)->orderBy('id','desc')->skip(1)->take(1)->get();
        

        foreach($assignment_secondlasts as $assignment_secondlast){

         $marks_secondlasts=AssignmentMarks::where('assignment_id','=',$assignment_secondlast->id)->where('student_id','=',$student_id)->get(); 
         $total_marks_secondlast=$assignment_secondlast->total_marks; 
         }
        // dd($assignment_secondlasts);
       if($assignment_secondlasts->isempty()){
            Session::flash('error', 'Last Test Not Created for comparisions!');
            return Redirect::to('test-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);



         }else{



          if($marks_secondlasts->isempty()){
            Session::flash('error', 'Last Test not marked for comparisions!');
           return Redirect::to('test-graph/'.$secsub_id)
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students);
             
         }

       foreach($marks_secondlasts as $marks_secondlast){
           
           $secondlast_percentage=$marks_secondlast->marks_obtained/$total_marks_secondlast*100;    
           //dd("<pre>".$secondlast_percentage."</pre>");
         }


        //dd("<pre>". $marks_lasts ."</pre>");  

            
           //dd("<pre>".$marks."</pre>");
         
          
		  return View::make('assignment.testgraph')
		   ->with('title','Create Assignment')
		   ->with('page','Manage Assignments')
           ->with('sec_sub_id',$sec_sub_id)
           ->with('students',$students)
           ->with('last_percentage',$last_percentage)
           ->with('secondlast_percentage',$secondlast_percentage)
           ->with('selected_students',$selected_students);
              
              }
           }
         }
      }   
    }






	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
