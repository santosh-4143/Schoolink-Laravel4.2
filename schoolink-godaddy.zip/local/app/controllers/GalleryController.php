<?php

class GalleryController extends BaseController {

	
	public function getCreateGallery()
	{
		$Classes = Classes::all();
		
		return View::make('gallery.create')
		->with('classes',$Classes)
		->with('title','Create Gallery')
		->with('page','Manage Gallery');
	}
	
	public function postCreateGallery()
	{

		$rules = array(
			'code' => 'required|unique:photos',
			'event'     => 'required',
			'date'     => 'required'
		
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('gallery-create')
			->withErrors($validator)
			->withInput();
		} 
		else 
		{
			// store
			$photo = new Photo;
			$photo->code          = ucwords(strtolower(Input::get('code')));
			$photo->event         = ucwords(strtolower(Input::get('event')));	
			$photo->date          = Input::get('date');
			$photo->classes_id    = Input::get('classes_id');
			$photo->section_id    = Input::get('section_id');
			$photo->save();
			$photo_id = $photo->id;
			if(Input::hasFile('image'))
			{
			  		$files = Input::file('image');
			  		$i = 0;
					foreach($files as $file) 
					{
					    $rules = array(
					       'file' => 'required|mimes:png,gif,jpeg|max:20000'
					    );
					    $validator = \Validator::make(array('file'=> $file), $rules);
					    if($validator->passes())
					    {

					  	    //$file = Input::file('image');
							$destinationPath = 'uploads/gallery';
							$filename = $file->getClientOriginalName();
							$extension = $file->getClientOriginalExtension();
							$newfile_name = uniqid().'.'.$file->getClientOriginalExtension();
							$file->move($destinationPath, $newfile_name);
                           
							$Galleries = new Galleries;
							$Galleries->photo_id                 = $photo_id;
							$Galleries->code                     = 'P'.$photo_id.''.$i;
							$Galleries->image_name_original      = $filename;
							$Galleries->image_name_new           = $newfile_name;
							$Galleries->image_type               = $extension;
							$Galleries->alt_tag                  = $photo->event;
							$Galleries->save();	
							$i++;
							
						}
						else 
						{
        					return Redirect::back()->with('error', 'Upload images only')->withInput();
    					}
					}	

					return Redirect::back()->with('success', 'Uploaded images Successfully');	

		    }			
			
			// redirect
			Session::flash('success', 'Successfully Created Gallery!');
			return Redirect::to('gallery-create');
			
		}
	}
	public function getViewGallery()
	{
		$photos = Photo::all();
		
		return View::make('gallery.view')
		->with('photos',$photos)
		->with('title','View Gallery')
		->with('page','Manage Gallery');
	}
	public function getEditGallery($id)
	{
		$classes = Classes::all();
		$photo = Photo::find($id);
        $sections = Section::where('classes_id','=',$photo->classes_id)->get();		
        return View::make('gallery.edit')
		->with('photo',$photo)
		->with('sections',$sections)
		->with('classes',$classes)
		->with('title','Edit Gallery')
		->with('page','Manage Gallery');
	}

	public function postEditGallery()
	{
		$id=Input::get('id');

		$rules = array(
			'event'     => 'required',
			'date'     => 'required'
		
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();
		} 
		else 
		{
			// store
			$photo = Photo::find($id);
			$photo->event   = ucwords(strtolower(Input::get('event')));	
			$photo->date   = Input::get('date');
			$photo->save();
			
			if(Input::hasFile('image'))
			{
			  		$files = Input::file('image');
			  		$gallery_id = Input::get('gallery_id');
			  	    $i = 0;
					foreach($files as $file) 
					{
					    $rules = array(
					       'file' => 'required|mimes:png,gif,jpeg|max:20000'
					    );
					    $validator = \Validator::make(array('file'=> $file), $rules);
					    if($validator->passes())
					    {

					  	    $Galleries = Galleries::find($gallery_id[$i]);
					  	    File::delete('uploads/gallery/'.$Galleries->image_name_new);
							$destinationPath = 'uploads/gallery';
							$filename = $file->getClientOriginalName();
							$extension = $file->getClientOriginalExtension();
						    $newfile_name = uniqid().'.'.$file->getClientOriginalExtension();
							$file->move($destinationPath, $newfile_name);
                           
							
							$Galleries->image_name_original      = $filename;
							$Galleries->image_name_new           = $newfile_name;
							$Galleries->image_type               = $extension;
							$Galleries->alt_tag                  = $photo->event;
							$Galleries->save();	
							$i++;
						}
						
					}		

		    }			
			
			// redirect
			Session::flash('success', 'Successfully Updated Gallery!');
			return Redirect::to('gallery-view');
			
		}
	}
	public function getViewImages($id)
	{
		//dd("<pre>".Galleries::where('photo_id',$id)->get()->count()."</pre>");
		$galleries = Galleries::where('photo_id',$id)->get();
		return View::make('gallery.viewimages')
		->with('photos',$galleries)
		->with('title','View Gallery')
		->with('page','Manage Gallery');
	}
	
	public function postDeleteGallery()
	{
		$id = Input::get('photo_id');
		$photo = Photo::find($id);
		
		if($photo)
		{
			foreach($photo->Galleries as $gallery) {
                File::delete('uploads/gallery/'.$gallery->image_name_new);
				$gallery->delete();
			}
			$photo->delete();
			return Redirect::back()
			->with('success', 'Successfully Deleted Gallery!');
			
		}
		else
		{
			return Redirect::back()
			->with('error', 'Oops ! No Such Images Availabe !');
		}

	}
	public function postDeleteImage()
	{
		$id = Input::get('gallery_id');
		$Galleries = Galleries::find($id);
		if($Galleries)
		{   
			File::delete('uploads/gallery/'.$Galleries->image_name_new);
			$Galleries->delete();
			return Redirect::back()->with('success', 'Successfully Deleted Photo!');
			
		}
		else
		{
			return Redirect::back()->with('error', 'Oops ! No Such Images Available !');
		}
	}	


	public function getFullGallery($id)
	{
		$photo = Photo::find($id);
		
		
		return View::make('gallery.full-gallery')
		->with('photo',$photo)
		->with('title','View Gallery')
		->with('page','Manage Gallery');
	}

	

	public function getAddGallery($id)
	{
		$photo = Photo::find($id);
		
		
		return View::make('gallery.add-more')
		->with('photo',$photo)
		->with('title','Add Gallery Images')
		->with('page','Manage Gallery');
	}

	public function postAddGallery()
	{
		$id=Input::get('id');

		$rules = array();
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();
		} 
		else 
		{
			// store
			$photo = Photo::find($id);
			
			if(Input::hasFile('image'))
			{
			  		$files = Input::file('image');
			  	    $i = 0;
					foreach($files as $file) 
					{
					    $rules = array(
					       'file' => 'required|mimes:png,gif,jpeg|max:20000'
					    );
					    $validator = \Validator::make(array('file'=> $file), $rules);
					    if($validator->passes())
					    {
							$destinationPath = 'uploads/gallery';
							$filename = $file->getClientOriginalName();
							$extension = $file->getClientOriginalExtension();
						    $newfile_name = uniqid().'.'.$file->getClientOriginalExtension();
							$file->move($destinationPath, $newfile_name);
                           
							$Galleries = new Galleries;
							$Galleries->photo_id      = $photo->id;
							$Galleries->image_name_original      = $filename;
							$Galleries->image_name_new           = $newfile_name;
							$Galleries->image_type               = $extension;
							$Galleries->alt_tag                  = $photo->event;
							$Galleries->save();	
							$i++;
						}
						
					}		

		    }			
			
			// redirect
			Session::flash('success', 'Successfully Updated Gallery!');
			return Redirect::to('gallery-view');
			
		}
	}
	
}