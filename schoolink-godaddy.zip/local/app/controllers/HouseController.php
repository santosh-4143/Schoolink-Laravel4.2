<?php

class HouseController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	 {   
		$houses=House::all();
           
		return View::make('house.index')
		->with('title','List House')
		->with('page','Manage Houses')
		->with('houses',$houses);
	 }

	 public function create()
	 {   
		
		return View::make('house.create')
		->with('title','Create House')
		->with('page','Manage Houses');
	 }


     public function store()
     {
          $rules = array(
			'code'       => 'required|unique:houses',
			'name'  	 => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('house')
			->withErrors($validator)
			->with('title','Create House')
			->with('page','Manage Houses')
			->withInput();

		}
		else
		{
			// store
			$house = new House;
			$house->code         = Input::get('code');
			$house->house_name   = Input::get('name');
			$house->color        = Input::get('color');
		    $house->save();

			// redirect
			Session::flash('success', 'Successfully Created House!');
			return Redirect::to('house')
			->with('title','Create House')
			->with('page','Manage Houses');
		}
	 }


public function edit($id)
	{
		$house=House::find($id);

		return View::make('house.edit')
		->with('title','Create House')
		->with('page','Manage Houses')
		->with('house',$house);
	}


    public function	update($id){

       $rules = array(
			'name'  	 => 'required',
			'color'      => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);
       
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$house = House::find($id);
			$house->house_name   = Input::get('name');
			$house->color        = Input::get('color');
		    $house->save();

			// redirect
			Session::flash('success', 'Successfully Updated House!');
			return Redirect::to('house');
		}
      }
	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function postDeletehouse()
	{
		$house_id=Input::get('house_id');
		$house = House::find($house_id);
		$house ->delete();
	    Session::flash('success', 'Successfully deleted House!');
	    return Redirect::to('house');
	}




	






}
