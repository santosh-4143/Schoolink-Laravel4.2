 <?php

class StudentController extends \BaseController {


	public function index()
	{
		return View::make('student.index')
		->with('students',Student::all())
		->with('classes', Classes::all())
		->with('sections', Section::all())
		->with('title','All Students')
		->with('page','Manage Students');
	}


	public function create()
	{
		return View::make('student.create')
		->with('classes',Classes::all())
		->with('sections',Section::all())
		->with('houses', House::all())
		->with('buses', Bus::all())
		->with('title','Create Student')
		->with('page','Manage Students');
	}

	public function store()
	{

		$rules = array(
			'code'       => 'required|unique:students',
			'fname'  	 => 'required|alpha|min:3',
			'classes_id' => 'required',
			'section_id' => 'required',
			'roll_no'  	 => 'required|integer',
			'email'      => 'required|email|unique:students|unique:users',
			'address'  	 => 'required|min:5',
			'phone'  	 => 'required|min:10',
 			'religion'   => 'required|alpha|min:3'
		);
		$validator = Validator::make(Input::all(), $rules);
         if(Input::hasFile('med'))
		   {
            $extension = Input::file('med')->getClientOriginalExtension();
            
         if($extension != 'pdf'){
             $error ="Please upload pdf file";
             return Redirect::to('students/create')
             ->with('error',$error);
           }

           }

		if ($validator->fails()) {

			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$student = new Student;
			$student->code    = Input::get('code');
			$student->fname   = ucwords(strtolower(Input::get('fname')));
			$student->mname   = ucwords(strtolower(Input::get('mname')));
			$student->lname   = ucwords(strtolower(Input::get('lname')));
			$student->classes_id = Input::get('classes_id');
			$student->section_id = Input::get('section_id');
			$student->roll_no = Input::get('roll_no');
			$student->email   = Input::get('email');
			$student->address = Input::get('address');
			$student->phone   = Input::get('phone');
			if(Input::has('house')){
			$student->house_id= Input::get('house');
		    }
		    if(Input::has('bus_id')){
			$student->bus_id= Input::get('bus_id');
		    }
			$student->religion= Input::get('religion');

			if(Input::hasFile('med'))
			  	{
				    $file = Input::file('med');

					$destinationPath = 'uploads/med_info';
					$filename = $file->getClientOriginalName();
					Input::file('med')->move($destinationPath, $filename);
					$student->med_info = $filename;
				

		        }

		        if(Input::hasFile('image'))
			  	{
				    $file = Input::file('image');
					$destinationPath = 'uploads/student';
					$oldFilename = $file->getClientOriginalName();
					$extension = Input::file('image')->getClientOriginalExtension();
					$newFilename =$student->Classes->name.'_'.$student->Section->name.'_'.rand(11111,99999).'.'.$extension;
					$file->move($destinationPath, $newFilename);
					$student->imagename_old      = $oldfilename;
					$student->imagename_new      = $newFilename;

		        }	

			if($student->save()){
			   Session::flash('success', 'Successfully created Student!');
			   return Redirect::to('students');
			}
			   Session::flash('error', 'Something went wrong!Please try again');
			   return Redirect::to('students/create');
		
	}
}
	public function getImport()
	{
		return View::make('student.import')
		->with('title', 'Import Students')
		->with('page', 'Manage Students');

	}
	public function importStudent()
	{
		$validator = Validator::make(Input::all(),array(
		  'file'   => 'required'
		  ));
		if($validator->fails())
		{
			return Redirect::to('get-import')
			->with('title', 'Import Students')
			->with('page', 'Manage Students')
			->withErrors($validator);
		}
		else
		{
			$file = Input::file('file');
			$ext= File::extension($file->getClientOriginalName());
			$file_name= Str::random(5).'.'.$ext;
			$file_name=Str::lower($file_name);
			$destinationPath = 'uploads/csv/';
			$upload_success = Input::file('file')->move($destinationPath, $file_name);
	        $file_path = $destinationPath.$file_name;

		 	Excel::load($file_path,function($reader) use(&$import_fields,&$import_row_count){

            $row_count = $reader->getTotalRowsOfFile() - 1;
            $import_row_count = $row_count;
            $existing_emails =array();
            $existing_codes =array();
            $readers = $reader->all()->toArray();
            foreach($readers as $data)
           	  {
           		$existint_user_check  = Student::where('email',$data['email'])
         									->where('code',$data['code'] )->get()->toArray();
                  $parent_id = 0;
                  if(isset($data['parent_code']))
                  {
                	$parent = Parents::where('code',$data['parent_code'])->first();
                  	if($parent)
                  	{
                  		$parent_id = $parent->id;
                  	}
                  }
                  if(empty($existint_user_check))
                	{
                			$student = new Student;
                			$student->parents_id = $parent_id;
                			$student->parent_code =$data['parent_code'];
                			$student->code =$data['code'];
                			$student->fname =$data['fname'];
                			$student->mname =$data['mname'];
                			$student->lname =$data['lname'];
                			$student->classes_id =$data['classes_id'];
                			$student->section_id =$data['section_id'];
                			$student->roll_no =$data['roll_no'];
                			$student->email =$data['email'];
                			$student->address =$data['address'];
                			$student->phone =$data['phone'];
                			$student->religion =$data['religion'];
                			$student->save();
                	}
                	else
                	{
                		return Redirect::to('get-import')
						->with('title', 'Import Students')
						->with('page', 'Manage Students')
						->with('error', 'Oops ! Duplicate Record Found pls try again');
                	}
            	}
           });
 		return Redirect::Route('get-import')
		->with('success','CSV file uploaded successfilly !')
		->with('title', 'Import Students')
		->with('page', 'Manage Students');
        }
	}


	public function show($id){

        $student=Student::find($id);
        return View::make('student.view')
		->with('student',$student)
		->with('title','View Student')
		->with('page','Manage Students');
	}


	public function export()
	{
		$students = Parents::all();
		//dd($students);
		///$excel = App::make('excel');
		 Excel::create('parent_data', function($excel) use($students) {

        $excel->sheet('test sheet', function($sheet) use($students) {

		            ///$sheet->fromArray($students->toArray());
		            $sheet->fromArray($students->toArray(), null, 'A1', false, false);

		        });

		    })->export('csv');

	}

	public function clientExport($type){

   $data = Client::all();

    Excel::create('exportedfile', function($excel) use($data) {

        $excel->sheet('test sheet', function($sheet) use($data) {

            $sheet->fromModel($data);

        });

    })->export($type);
        }

	public function edit($id)
	{
		
		$Student = Student::find($id);
		
		return View::make('student.edit')
		->with('classes',Classes::all())
		->with('sections',Section::all())
		->with('houses',House::all())
		->with('buses',Bus::all())
		->with('Student',$Student)
		->with('title','Edit Student')
		->with('page','Manage Students');
	}


	public function update($id)
	  {
         $rules = array(
			'fname'  	 => 'required|alpha|min:3',
			'classes_id' => 'required',
			'section_id' => 'required',
			'roll_no'  	 => 'required|integer'
		);
		$validator = Validator::make(Input::all(), $rules);	
		if ($validator->fails()) {	
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$student = Student::find($id);
			$student->fname      = ucwords(strtolower(Input::get('fname')));
			$student->mname      = ucwords(strtolower(Input::get('mname')));
			$student->lname      = ucwords(strtolower(Input::get('lname')));
			$student->classes_id = Input::get('classes_id');
			$student->section_id = Input::get('section_id');
			$student->roll_no    = Input::get('roll_no');
			$student->address    = Input::get('address');
			$student->phone      = Input::get('phone');

			if(Input::has('house'))
				{
					$student->house_id= Input::get('house');
				}
			if(Input::has('bus_id'))
				{
					$student->bus_id = Input::get('bus_id');
				}

			$student->religion   = Input::get('religion');

			 if(Input::hasFile('image'))
			  	{
			  		File::delete('uploads/student/'.$student->imagename_new);

				    $file = Input::file('image');
				   
					$destinationPath = 'uploads/student';
					
					$extension = Input::file('image')->getClientOriginalExtension();
					$oldFilename = $file->getClientOriginalName();
					$newFilename =$student->Classes->name.'_'.$student->Section->name.'_'.rand(11111,99999).'.'.$extension;
					$file->move($destinationPath, $newFilename);
					$student->imagename_old      = $oldFilename;
					$student->imagename_new      = $newFilename;

		        }	

			if($student->save()){
			   Session::flash('success', 'Successfully updated Student!');
			   return Redirect::to('students');
			}
			   Session::flash('error', 'Something went wrong!Please try again');
			   return Redirect::to('students');
		
		}

	  }

	public function get_ajax_section(){
     $classes_id = Input::get('classes_id');
	 $sections = Section::where('classes_id','=',$classes_id)->get()->toJson();
	  return $sections;
	}

	public function get_section_students(){
     $section_id = Input::get('section_id');
	 $students =Student::where('section_id','=',$section_id)->get();
	 $name=array();
	 foreach($students as $student){
	  $data['id']=$student->id;
      $data['classes_name']=$student->Classes->name;
      $data['section_name']=$student->Section->name;
      $data['name']=$student->fname.' '.$student->mname.' '.$student->lname;
      $data['address']=$student->address;
      $data['phone']=$student->phone;
      $data['email']=$student->email;
      if(is_null($student->House)){
      	$data['house_name']='House not alloted';
      }
      else{
        $data['house_name']=$student->House->house_name;
      }
      $name[]=$data;
	 }

	  return $name;
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function getDeleteStudent()
	{
		$student_id=Input::get('student_id');
		$pattern=Input::get('pattern');
		$student = Student::find($student_id);
		$student ->delete();
		if(!empty($pattern)){

		  $data="success";

           return $data;

		}else{
	    Session::flash('success', 'Successfully deleted Student!');
	    return Redirect::to('students');
	  }
	}



	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */


}
