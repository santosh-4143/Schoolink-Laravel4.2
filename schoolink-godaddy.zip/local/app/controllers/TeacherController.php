<?php

class TeacherController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('teacher.profile.index')
		->with('teachers',Teacher::all())
		->with('page','Manage Teachers')
		->with('title','All Teachers');
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('teacher.profile.create')
		->with('title','Create Teacher')
		->with('page','Manage Teachers')
		->with('classes',Classes::all())
		->with('sections',Section::all());
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$rules = array(
			'code'       => 'required|unique:teachers',
			'fname'  	 => 'required|alpha',
			'email'  	 => 'required|email|unique:users',
			'address'  	 => 'required|min:5',
			'password'   => 'required',
			'phone_1'  	 => 'required|min:10',
			'phone_2'  	 => 'min:10',

						//'slug'      => '',
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		 if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
            $user =new User;
			$user->user_type = 2;
			$user->fname = ucwords(strtolower(Input::get('fname'))).' '.ucwords(strtolower(Input::get('lname')));
			$user->email   = Input::get('email');
			$user->password= Hash::make(Input::get('password'));
			$user->save();



			$teacher = new Teacher;
			$teacher->code    = Input::get('code');
			$teacher->user_id = $user->id;
			$teacher->fname   = ucwords(strtolower(Input::get('fname')));
			$teacher->mname   = ucwords(strtolower(Input::get('mname')));
			$teacher->lname   = ucwords(strtolower(Input::get('lname')));
			$teacher->address = Input::get('address');
			$teacher->phone_1   = Input::get('phone_1');
			$teacher->phone_2   = Input::get('phone_2');
			$teacher->classes_id= Input::get('classes_id');
			$teacher->section_id= Input::get('section_id');
			$teacher->user_type = 2;
			if(Input::hasFile('image'))
			  	{
				    $file = Input::file('image');
					$destinationPath = 'uploads/teacher';
					$oldFilename = $file->getClientOriginalName();
					$extension = Input::file('image')->getClientOriginalExtension();
					$newFilename =$teacher->code.'_'.rand(11111,99999).'.'.$extension;
					$file->move($destinationPath, $newFilename);
					$teacher->imagename_old      = $oldfilename;
					$teacher->imagename_new      = $newFilename;

		        }	
			if($teacher->save()){
			    Session::flash('success', 'Successfully Created Teacher!');
			    return Redirect::to('teachers');
		  }else{
                Session::flash('error', 'Something went wrong!Please try again');
			    return Redirect::to('teachers/create');
		  }
		}
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
     public function show($id){

        $teacher = Teacher::find($id);

		return View::make('teacher.profile.view')
		->with('teacher',$teacher)
		->with('title','View Teacher')
		->with('page','Manage Teachers');

    }

	public function viewTeacher()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);
		
		return View::make('teacher.profile')
		->with('teachers',$teachers)
		->with('page','Teacher')
		->with('title','Teacher Profile');

	}

    public function edit($id){

        $teacher = Teacher::find($id);

		return View::make('teacher.profile.edit')
		->with('classes',Classes::all())
		->with('sections',Section::all())
		->with('teacher',$teacher)
		->with('title','Edit Teacher')
		->with('page','Manage Teachers');

    }
     public function update($id){

       $rules = array(

			'fname'  	 => 'required|alpha|min:3',
			'mname'  	 => 'required|alpha|min:3',
			'lname'  	 => 'required|alpha|min:3',
			'address'  	 => 'required|min:5',
			'email'  	 => 'required',
			'phone_1'  	 => 'required|min:10'
		);
		$validator = Validator::make(Input::all(), $rules);
        $teacher_id=Input::get('teacher_id');


		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
	 else{

       $teacher=Teacher::find($teacher_id);
       $teacher->fname      = ucwords(strtolower(Input::get('fname')));
	   $teacher->mname      = ucwords(strtolower(Input::get('mname')));
	   $teacher->lname      = ucwords(strtolower(Input::get('lname')));
	   $teacher->address    = Input::get('address');
	   $teacher->phone_1    = Input::get('phone_1');
	   $teacher->phone_2    = Input::get('phone_2');
	   $teacher->classes_id = Input::get('classes_id');
	   $teacher->section_id = Input::get('section_id');
	    if(Input::hasFile('image'))
			  	{
			  		File::delete('uploads/teacher/'.$teacher->imagename_new);

				    $file = Input::file('image');
				   
					$destinationPath = 'uploads/teacher';
					
					$extension = Input::file('image')->getClientOriginalExtension();
					$oldFilename = $file->getClientOriginalName();
					$newFilename =$teacher->code.'_'.rand(11111,99999).'.'.$extension;
					$file->move($destinationPath, $newFilename);
					$teacher->imagename_old      = $oldFilename;
					$teacher->imagename_new      = $newFilename;

		        }	
	  
	   $user =User::find($teacher->user_id);
	   $user->email =Input::get('email');
       $user->save();

        if($teacher->save()){
             Session::flash('success', 'Successfully Updated Teacher Details!');
             return Redirect::to('teachers');
        }
           Session::flash('error', 'Something went wrong!Please try again');
             return Redirect::to('teachers');
       }

     }

    public function getImportTeacher()
	{
		return View::make('teacher.import')
		->with('title', 'Import Teacher')
		->with('page', 'Manage Teachers');

	}
	public function postImportTeacher()
	{
		$validator = Validator::make(Input::all(),array(
		  'file'   => 'required'
		  ));
		if($validator->fails())
		{
			return Redirect::to('import-teacher')
			->withErrors($validator);
		}
		else
		{
			$file = Input::file('file');
			$ext= File::extension($file->getClientOriginalName());
			$file_name= Str::random(5).'.'.$ext;
			$file_name=Str::lower($file_name);
			$destinationPath = 'uploads/csv/';
			$upload_success = Input::file('file')->move($destinationPath, $file_name);
	        $file_path = $destinationPath.$file_name;

			Excel::load($file_path,function($reader) use(&$import_fields,&$import_row_count){
			$row_count = $reader->getTotalRowsOfFile() - 1;
	        $import_row_count = $row_count;

	        $existing_emails =array();
	        $existing_codes =array();
	        $readers = $reader->all()->toArray();
	       // dd($readers);
	        foreach($readers as $data)
	         {
	        	$existint_teacher_check  = Teacher::where('code',$data['code'] )->get()->toArray();
        		$existint_user_check  = User::where('email',$data['email'])->get()->toArray();
        		$classes  = Classes::where('code',$data['class_code'])->get()->toArray();
        		$section  = Section::where('code',$data['section_code'])->get()->toArray();
        		//dd($section[0]["name"]);
            	if(empty($existint_user_check) && empty($existint_teacher_check) && !empty($classes) && !empty($section) && !empty($data['fname']) && !empty($data['address']) && !empty($data['phone_1']) && !empty($data['phone_2']))
            	{

            	// store in Users Table
				$User =new User;
				$User->fname   = ucwords(strtolower($data['fname']))." ".ucwords(strtolower($data['mname']))." ".ucwords(strtolower($data['lname']));
				$User->user_type = 2;
				$User->email   = $data['email'];
				$User->password = Hash::make($data['password']);
				$User->save();

				// store in Users Table
        		$teacher = new Teacher;
        		$teacher->user_id = $User->id;
        		$teacher->code =$data['code'];
                $teacher->fname =$data['fname'];
                $teacher->mname =$data['mname'];
                $teacher->lname =$data['lname'];
                $teacher->address =$data['address'];
                $teacher->phone_1 =$data['phone_1'];
                $teacher->phone_2 =$data['phone_2'];
                $teacher->classes_id =$classes[0]["id"];
                $teacher->section_id =$section[0]["id"];
                $teacher->user_type =2;
                $teacher->save();

                }
                else
                {
               		return Redirect::Route('import-teacher')
					->with('error','Oops ! Something Went Wrong PLease Try Again')
					->with('title', 'Import Teacher')
					->with('page', 'Manage Teachers');
			 	}
              }

           });
        return Redirect::Route('import-teacher')
		->with('success','CSV file uploaded successfully !')
		->with('title', 'Import Teacher')
		->with('page', 'Manage Teachers');
        }
	}

	public function postDeleteTeacher()
	{
		$teacher_id=Input::get('teacher_id');
		$teacher = Teacher::find($teacher_id);
		
		if(is_null($teacher->SectionSubject)){

			$user=User::find($teacher->user_id);
		    $teacher ->delete();
		    $user->delete();

           Session::flash('success', 'Successfully deleted Teacher!');
	       return Redirect::to('teachers');

		} 
		
	    Session::flash('error', 'This teacher has subjects assigned!');
	    return Redirect::to('teachers');

	}


	public function viewTeacherSubjects()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);
		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();

		return View::make('teacher.subject')
		->with('teacher_subjects',$teacher_subjects)
		->with('page','Teacher Classes')
		->with('title','Subjects');

	}

	public function viewTeacherTimetable()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);

		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();


        foreach($teacher_subjects as $teacher_subject){


		       $teacher_timetables[]=TimetableDetails::where('section_subject_id','=', $teacher_subject->id)->get();


        }



		return View::make('teacher.timetable')
		->with('teacher_timetables',$teacher_timetables)
		->with('page','Teacher Classes')
		->with('title','Timetable');

	}

	public function getTeacherAttendance()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);
		//dd($teachers->id);
		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();
       // dd("<pre>".$teacher_subjects."</pre>");
		$i=0;
        foreach($teacher_subjects as $teacher_subject){

          //dd("<pre>".$teacher_subject->id."</pre>");
		  $teacher_timetables[]=TimetableDetails::where('section_subject_id','=', $teacher_subject->id)->get();

          $i++;
        }
      // echo "<pre>";
	  // print_r($teacher_timetables);
	  // die();
		$i=0;
	//foreach($teacher_timetables as $time=>$value){
		//foreach($value as $val=>$key){
          // echo "<pre>";
		  // $values= $key->toArray();
          // print_r ($values);

          // $subject_name=SectionSubject::find($values['section_subject_id'])->Subject->name->toArray();
           //echo $subject_name;
        // }
    // }

        //die();
		return View::make('teacher.attendance')
		->with('teacher_timetables',$teacher_timetables)
		->with('page','Attendance')
		->with('title','Teacher Attendance');

	}


   public function getListStudent($timetable_detail_id)
	{

        $timetable_details = TimetableDetails::find($timetable_detail_id);

        $attendances = Attendance::where('section_id','=',$timetable_details->section_id)->where('date', '=', date('Y-m-d'))->where('lecture_num', '=',$timetable_details->lecture_num )->get();

        $students=Student::where('section_id','=',$timetable_details->section_id)->get();



	    //dd("<pre>".$timetable_details."</pre>");
	     return View::make('teacher.studentlist')
	     ->with('title', 'Check Attendance')
		 ->with('page','Teacher Attendance')
		 ->with('students',$students )
		 ->with('timetable_details',$timetable_details)
		 ->with('attendances',$attendances);

	}

	public function postAttendanceTeacher()
	{

       $rules = array(


		);
		$validator = Validator::make(Input::all(), $rules);

        $timetable_details_id=Input::get('timetable_details_id');
		// process the login
		if ($validator->fails()) {
			return Redirect::to('check-attendance/'.$timetable_details_id)
			->withErrors($validator)
			->with('title','Teacher Attendance')
			->with('page','Attendance');



		} else {

			// store

			$timetable_details_id=Input::get('timetable_details_id');
			$student_id=Input::get('student_id');
			$section_subject_id=Input::get('section_subject_id');
			$section_id=Input::get('section_id');
			$date=date('Y-m-d');
			$lecture_num=Input::get('lecture_num');
            $students = Student::where('section_id','=',$section_id)->get();
            $timetable_details = TimetableDetails::find($timetable_details_id);



			//dd($user_id);
			$student_size=sizeof($student_id);
            //dd($student_size);



$update_attendances= Attendance::where('section_id','=',$section_id)->where('date', '=', date('Y-m-d'))->where('lecture_num', '=',$lecture_num)->get();
//dd($update_attendances);


        if($update_attendances->count() > 0)
            {
             $i=0;
            foreach($update_attendances as $update_attendance)

             {
             $update=Attendance::find($update_attendance->id);
             //dd("<pre>".$update."</pre>");
             $update->status=Input::get('att'.$i)[0];
             //dd(Input::get('att'.$i)[0]);
             $i++;
             $update->save();
             }
          }
        else
           {

           for($i=0;$i<$student_size;$i++){
            $check_attendance = new Attendance;
			$check_attendance->section_subject_id = $section_subject_id;
		    $check_attendance->student_id = $student_id[$i];
            //dd($check_attendance->student_id);
            $check_attendance->section_id = $section_id;
		    $check_attendance->status = Input::get('att'.$i)[0];
		      //dd($i);
		    //dd($check_attendance->status);
			$check_attendance->user_id = Auth::user()->Teacher->id;
			//dd($check_attendance->user_id);
			$check_attendance->date = $date;
			$check_attendance->lecture_num = $lecture_num;

			//dd("<pre>".$assignment_marks->admin_id."</pre>");
				$check_attendance->save();
               }
        }

			// redirect

	     Session::flash('success', 'Successfully marked Attendance!');
		 return Redirect::to('check-attendance-teacher/'.$timetable_details_id)
	      ->with('title', 'Teacher Attendance')
		  ->with('page','Attendance')
		  ->with('students',$students)
		  ->with('timetable_details',$timetable_details);

	}

}


	public function getSubjectList()
	{

        $teachers=Teacher::find(Auth::user()->Teacher->id);
		//dd($teachers->id);
		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();

		//dd("<pre>".$teacher_subjects."</pre>");
		return View::make('teacher.assignmenttest')
		->with('teacher_subjects',$teacher_subjects)
		->with('page','Assignment')
		->with('title','Teacher Assignment');


	}

	public function createAssignment($section_sub_id)
	{
	    $sec_sub_id = SectionSubject::find($section_sub_id);
	    $assignment = Assignment::where('section_subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->orderBy('id','DESC')->get();
	    $teacher_id=Teacher::find(Auth::user()->Teacher->id)->id;

         //dd('<pre>'.$teacher_id.'</pre>');
		return View::make('teacher.createassignment')
		->with('title','Teacher Assignment')
		->with('page','Assignment')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('assignments',$assignment)
        ->with('teacher_id',$teacher_id);

	}


public function postAssignment()
	{
		///dd(Input::all());
			$rules = array(
			'code'       => 'required|unique:subjects',
			'name'  	 => 'required',
			'description'=> 'required',
			'total_marks'=> 'required',
			'date'  	 => 'required',
			'type' =>'required',
			'section_sub_id'=>'required',
            'section_id' =>'required',
            'classes_id' =>'required',
            'user_id' =>'required'
		);
		$validator = Validator::make(Input::all(), $rules);
        $section_subject_id=Input::get('section_sub_id');
		// process the login
		if ($validator->fails()) {
			return Redirect::to('teacher-create-assignment/'.$section_subject_id)
			->withErrors($validator)
			->with('title','Teacher Assignment')
			->with('page','Assignment');



		} else {
			// store
			$assignments = new Assignment;
			$assignments->code  = Input::get('code');
			$assignments->name  = Input::get('name');
			$assignments->description = Input::get('description');
			$assignments->total_marks = Input::get('total_marks');
			$assignments->date  = Input::get('date');
			$assignments->type = Input::get('type');
			$assignments->section_subject_id =$section_subject_id ;
			$assignments->section_id = Input::get('section_id');
			$assignments->classes_id = Input::get('classes_id');
			$assignments->teacher_id = Input::get('user_id');

			$assignments->save();

			// redirect

			Session::flash('success', 'Successfully created Assignment!');
			return Redirect::to('teacher-create-assignment/'.$section_subject_id)
			->with('title','Teacher Assignment')
			->with('page','Assignment');

		}
	}

public function editAssignment($assignment_id)
	{
	    $assignment = Assignment::find($assignment_id);
	       return View::make('teacher.editassignment')
			->with('title','Teacher Assignment')
			->with('page','Assignment')
			->with('assignment',$assignment);

	}


    public function posteditAssignment()
	{
	        $rules = array(

			'name'  	 => 'required',
			'description'=> 'required',
			'total_marks'=> 'required',
			'date'  	 => 'required',

		);
		$validator = Validator::make(Input::all(), $rules);
        $assignment_id=Input::get('assignment_id');
		// process the login
		if ($validator->fails()) {
			return Redirect::to('teacher-assignment-edit/'.$assignment_id)
			->withErrors($validator)
			->with('title','Teacher Assignment')
			->with('page','Assignment');



		} else {
			// store
			$assignments =Assignment::find($assignment_id);

			$assignments->name  = Input::get('name');
			$assignments->description = Input::get('description');
			$assignments->total_marks = Input::get('total_marks');
			$assignments->date  = Input::get('date');


			$assignments->save();

			// redirect

			Session::flash('success', 'Successfully Updated Assignment!');
			return Redirect::to('teacher-assignment-edit/'.$assignment_id)
			->with('title','Teacher Assignment')
			->with('page','Assignment');

         }
	}

	 public function postdeleteAssignment(){

      $assignment_id=Input::get('assignment_id');
      $assignment=Assignment::find($assignment_id);
      if($assignment->type == 1){
      $sec_sub_id=$assignment->section_subject_id;
      $assignment->delete();
      Session::flash('success', 'Assignment Deleted Succesfully!');
	  return Redirect::to('teacher-create-assignment/'.$sec_sub_id)
	  ->with('title','Teacher Assignment')
	  ->with('page','Assignment');
       }
       else{
           $sec_sub_id=$assignment->section_subject_id;
           $assignment->delete();
           Session::flash('success', 'Test Deleted Succesfully!');
	       return Redirect::to('teacher-create-test/'.$sec_sub_id)
	        ->with('title','Teacher Test')
	        ->with('page','Test');
       }


	 }

	public function getStudentlist($assignment_id)
	{
		 $assignment_details = Assignment::find($assignment_id);
		 $section_id=$assignment_details->Section->id;
         $students = Student::where('section_id','=',$section_id)->get();
         $assignment_marks = AssignmentMarks::where('assignment_id','=',$assignment_id)->get();
         //dd("<pre>".$assignment_marks_id."</pre>");

         if($assignment_details->type == 1){
	        return View::make('teacher.assignmentmarks')
	     ->with('title', 'Teacher Assignment')
		 ->with('page','Assignment')
		 ->with('students',$students )
		  ->with('assignments',$assignment_details)
		  ->with('assignment_marks',$assignment_marks);
        }
      if($assignment_details->type == 2){
          return View::make('teacher.testmarks')
	     ->with('title', 'Teacher Assignment')
		 ->with('page','Assignment')
		 ->with('students',$students )
		 ->with('assignments',$assignment_details)
		 ->with('assignment_marks',$assignment_marks);


      }

	}

	public function postAssignmentmarks()
	{
		$teacher_id=Auth::user()->Teacher->id;
		//dd($teacher_id);
			$rules = array(
			'marks' => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('assignment-create')
			->withErrors($validator)
			->with('title','Teacher Assignment')
			->with('page','Assignment');



		} else {

			//store
			$assignment_marks_id=Input::get('assignment_marks_id');
			$marks_size=sizeof($assignment_marks_id);
		    //dd($assignment_marks_id);
			$student_id=Input::get('student_id');
			$marks=Input::get('marks');
			$comments=Input::get('comments');
			$student_size=sizeof($student_id);
			$assignment_id=Input::get('assignment_id');


	  if(empty($assignment_marks_id)){


		for($i=0;$i<$student_size;$i++){

            $assignment_marks = new AssignmentMarks;
			$assignment_marks->assignment_id = $assignment_id;
		    $assignment_marks->student_id = $student_id[$i];

		    $assignment_marks->marks_obtained = $marks[$i];
			$assignment_marks->comments  = $comments[$i];
			$assignment_marks->teacher_id = $teacher_id;

			//dd("<pre>".$assignment_marks->admin_id."</pre>");
			$assignment_marks->save();
            }
           $update_assignment_status=Assignment::find(Input::get('assignment_id'));
           $update_assignment_status->isChecked = 1;
		   $update_assignment_status->save();
			// redirect

			 Session::flash('success', 'Successfully marked Assignment!');
			 return Redirect::to('teacher-assignment-marks/'.$assignment_marks->assignment_id)
			 ->with('title','Teacher Assignment')
			 ->with('page','Assignment');

		   }// insert block
		   else{

                 for($i=0;$i<$marks_size;$i++){
                    //dd($assignment_marks_id[0]);
                 	$update_assignment_marks=AssignmentMarks::find($assignment_marks_id[$i]);
                 	//dd($update_assignment_marks);
                 	$update_assignment_marks->marks_obtained = $marks[$i];
                    $update_assignment_marks->comments  = $comments[$i];
                    $update_assignment_marks->save();

                 }//for loop

             Session::flash('success', 'Successfully updated Assignment Marks!');
			 return Redirect::to('teacher-assignment-marks/'.$assignment_id)
			 ->with('title','Teacher Assignment')
			 ->with('page','Assignment');
		   }//update block

       }

	}


	public function createTest($sectionsub_id)
	{
	     $sec_sub_id = SectionSubject::find($sectionsub_id);

	     $test = Assignment::where('section_subject_id','=',$sec_sub_id->id)->where('type', '=', 2)->orderBy('id','DESC')->get();

         $teacher_id=Teacher::find(Auth::user()->Teacher->id)->id;

		return View::make('teacher.createtest')
		->with('title','Teacher Test')
		->with('page','Test')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('assignments',$test)
        ->with('teacher_id',$teacher_id);

	}

	public function store_test()
	{
		///dd(Input::all());
			$rules = array(
			'code'       => 'required|unique:subjects',
			'name'  	 => 'required',
			'description'=> 'required',
			'total_marks'=> 'required',
			'date'  	 => 'required',
			'type' =>'required',
			'section_sub_id'=>'required',
            'section_id' =>'required',
            'classes_id' =>'required',
            'user_id' =>'required'
		);
		$validator = Validator::make(Input::all(), $rules);
        $section_subject_id=Input::get('section_sub_id');
		// process the login
		if ($validator->fails()) {
			return Redirect::to('teacher-create-test/'.$section_subject_id)
			->withErrors($validator)
			->with('title','Teacher Test')
			->with('page','Test');



		} else {
			// store
			$tests = new Assignment;
			$tests->code  = Input::get('code');
			$tests->name  = Input::get('name');
			$tests->description = Input::get('description');
			$tests->total_marks = Input::get('total_marks');
			$tests->date  = Input::get('date');
			$tests->type = Input::get('type');
			$tests->section_subject_id = Input::get('section_sub_id');
			$tests->section_id = Input::get('section_id');
			$tests->classes_id = Input::get('classes_id');
			$tests->teacher_id = Input::get('user_id');

			$tests->save();

			// redirect

			Session::flash('success', 'Successfully created Test!');
			return Redirect::to('teacher-create-test/'.$section_subject_id)
			->with('title','Teacher Test')
			->with('page','Test');

		}
	}

	public function editTest($assignment_id)
	{
	       $assignment = Assignment::find($assignment_id);
	       return View::make('teacher.edittest')
			->with('title','Teacher Test')
			->with('page','Test')
			->with('assignment',$assignment);

	}

	public function posteditTest()
	{
	     $rules = array(

			'name'  	 => 'required',
			'description'=> 'required',
			'total_marks'=> 'required',
			'date'  	 => 'required',

		);
		$validator = Validator::make(Input::all(), $rules);
        $assignment_id=Input::get('assignment_id');
		// process the login
		if ($validator->fails()) {
			return Redirect::to('teacher-test-edit/'.$assignment_id)
			->withErrors($validator)
			->with('title','Teacher Test')
			->with('page','Test');



		} else {
			// store
			$assignments =Assignment::find($assignment_id);

			$assignments->name  = Input::get('name');
			$assignments->description = Input::get('description');
			$assignments->total_marks = Input::get('total_marks');
			$assignments->date  = Input::get('date');


			$assignments->save();

			// redirect

			Session::flash('success', 'Successfully Updated Test!');
			return Redirect::to('teacher-test-edit/'.$assignment_id)
			->with('title','Teacher Test')
			->with('page','Test');

         }

	}


   public function postTestmarks()
	{

			$rules = array(
			'marks'       => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);
        $assignment_id=Input::get('assignment_id');

		// process the login
		if ($validator->fails()) {
			return Redirect::to('teacher-assignment-marks/'.$assignment_id)
			->withErrors($validator)
			->with('title','Create Test')
			->with('page','Test');



		} else {

			$assignment_marks_id=Input::get('assignment_marks_id');
			$marks_size=sizeof($assignment_marks_id);
			$student_id=Input::get('student_id');
			$marks=Input::get('marks');
			$comments=Input::get('comments');


			//dd($student_id);
			$student_size=sizeof($student_id);

   if(empty($assignment_marks_id)){

		for($i=0;$i<$student_size;$i++){

            $assignment_marks = new AssignmentMarks;
			$assignment_marks->assignment_id = $assignment_id;
		    $assignment_marks->student_id = $student_id[$i];
		    $assignment_marks->marks_obtained = $marks[$i];
			$assignment_marks->comments  = $comments[$i];
			$assignment_marks->admin_id = Auth::user()->id;
			$assignment_marks->save();
            }
           $update_test_status=Assignment::find($assignment_id);
           $update_test_status->isChecked = 1;
		   $update_test_status->save();
			// redirect

			 Session::flash('success', 'Successfully marked Test!');
			 return Redirect::to('assignment-marks/'.$assignment_marks->assignment_id)
			 ->with('title','Teacher Test')
			 ->with('page','Test');

		}//insert block
      else{

                 for($i=0;$i<$marks_size;$i++){
                    //dd($assignment_marks_id[0]);
                 	$update_assignment_marks=AssignmentMarks::find($assignment_marks_id[$i]);
                 	//dd($update_assignment_marks);
                 	$update_assignment_marks->marks_obtained = $marks[$i];
                    $update_assignment_marks->comments  = $comments[$i];
                    $update_assignment_marks->save();

                 }//for loop

             Session::flash('success', 'Successfully updated Assignment Marks!');
			 return Redirect::to('teacher-assignment-marks/'.$assignment_id)
			 ->with('title','Teacher Test')
			 ->with('page','Test');
		   }//update block

		}


	}

public function viewExamSchedule()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);
		//dd($teachers->id);
		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();
		foreach($teacher_subjects as $teacher_subject){

			$classes_name[]=$teacher_subject->Classes;
		}

		$classes_names=array_unique($classes_name);

		return View::make('teacher.examschedule')
		->with('classes_names',$classes_names)
		->with('page','Schedule')
		->with('title','Exam Schedule');

	}


      public function getExamList(){

         $teachers = Teacher::find(Auth::user()->Teacher->id);
         $teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();
		 foreach($teacher_subjects as $teacher_subject){

			$classes_name[]=$teacher_subject->Classes;
		}

		$classes_names=array_unique($classes_name);

         $classes_id = Input::get('classes_id');
         $classname =Classes::find($classes_id);
         $exam_list=Exam::where('classes_id','=',$classes_id)->get();

		return View::make('teacher.examschedule')
		->with('classes_names',$classes_names)
		->with('exams_names', $exam_list)
		->with('classname',$classname)
		->with('page','Schedule')
		->with('title','Exam Schedule');

    }

    public function getScheduledetails($exam_id)
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);
		$examschedule_details=ExamSchedule::where('exam_id','=',$exam_id)->get();
		$exam_name=Exam::find($exam_id);

		return View::make('teacher.viewschedule')
		->with('exams_schedule', $examschedule_details)
		->with('exam_name',$exam_name)
		->with('teacher_id',$teachers->id)
		->with('page','Schedule')
		->with('title', 'Exam Schedule');

	}

     public function getExamStudent($exam_schedule_id,$exam_id,$subject_id)
	{
		$examschedule=Exam::find($exam_id)->ExamSchedule;
		$classes=Exam::find($exam_id)->Classes;
        $sections=Section::where('classes_id','=',$classes->id)->get();
		$total_marks=ExamSchedule::find($exam_schedule_id);
		//dd($total_marks);
        $exam_marks=ExamMarks::where('exam_schedule_id','=',$exam_schedule_id)->get();
	   //dd("<pre>".$exam_marks."</pre>");

		return View::make('teacher.studentexam_marks')
		->with('title', 'Exam Schedule')
		->with('page','Schedule')
		->with('sections',$sections)
		->with('exam_schedule_id',$exam_schedule_id)
		->with('exam_id',$exam_id)
		->with('subject_id',$subject_id)
		->with('total_marks',$total_marks)
		->with('exam_marks',$exam_marks);
	}


public function postExamMarks()
	{
		$marks = Input::get('marks');
		$subject_id = Input::get('subject_id');
		$exam_id= Input::get('exam_id');
		$student_id = Input::get('student_id');
		$section_id = Input::get('section_id');
        $exam_schedule_id=Input::get('exam_schedule_id');
		$size=sizeOf($student_id);
		$classes=Exam::find($exam_id)->Classes;
        $sections=Section::where('classes_id','=',$classes->id)->get();
        $exam_marks=ExamMarks::where('exam_schedule_id','=',$exam_schedule_id)->get();
        $status_update=ExamSchedule::find($exam_schedule_id);



        if(sizeOf($exam_marks) > 0){

         $exam_marks_id= Input::get('exam_marks_id');
        for($i=0;$i<sizeOf($exam_marks);$i++){

           $exam_marks_update=ExamMarks::find($exam_marks_id[$i]);
           $exam_marks_update->marks=$marks[$i];
           //$exam_marks_update->section_subject_id=$status_update->SectionSubject->id;
           $exam_marks_update->save();

         }//for loop for update


        } // if part
        else{


		for($i=0;$i<$size;$i++){

           $exam_marks= new ExamMarks;
           $exam_marks->exam_id= $exam_id ;
           $exam_marks->exam_schedule_id=$exam_schedule_id;
           $exam_marks->subject_id=$subject_id;
           $exam_marks->section_id=$section_id[$i];
           $exam_marks->student_id=$student_id[$i];
           $exam_marks->section_subject_id=$status_update->SectionSubject->id;
           $exam_marks->marks=$marks[$i];
           $exam_marks->save();
           $status_update->status = 1;
           $status_update->save();

		  }
		}//else part
		// redirect
		Session::flash('success', 'Successfully marked Exam!');
		return Redirect::to('teacher-exam-marks/'.$exam_schedule_id.$exam_id.$subject_id)
		->with('title', 'Exam Schedule')
		->with('page','Schedule');
	}


	public function getExamResult()
	 {
	  $teachers=Teacher::find(Auth::user()->Teacher->id);
	  $teacher_classes=SectionSubject::where('teacher_id','=',$teachers->id)->get();


        //$classes=array_unique($teacher_classes);
         //echo "<pre>";
          //dd("<pre".$teacher_classes."</pre>");
         foreach($teacher_classes as $classes){

              $classes_teacher[]=$classes->Classes;
        }

        // echo "<pre>";
         $final_classes=array_unique($classes_teacher);

  return View::make('teacher.listresult')
  ->with('classes',$final_classes)
  ->with('title', 'Result')
  ->with('page','Schedule');
 }

 public function getResultMarks(){

       $exam_id = Input::get('exam_id');
       $classes_id = Input::get('classes_id');
       $student_id = Input::get('student_id');
       $exam_all=ExamMarks::where('student_id','=',$student_id)->orderBy('exam_schedule_id')->get();

       $final_result = array();
       if($exam_all){
         foreach($exam_all as $result){

           //dd($result->Exam->name);
          if(!isset($final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id])){
           $final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id] = 0;
          }
          $final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id]+= $result->marks;

         }

foreach($final_result as $key=>$value){

foreach($value  as $key1=>$value1)
$final_result[$key][$key1]['total']=array_sum($value1);

}


       }


       //echo "<pre>";
       //print_r($final_result);



           //die();

        //echo "<pre>";
       // print_r($final_result);


 //die();

  foreach($final_result as $exam_id => $val1)
        {
              //echo $exam_id.' <br />';


                foreach($val1 as $index2 => $val2)
                {
                       //echo $index2.' - Total: ' . $val2['total'] . ' <br />';

                        foreach($val2 as $index3 => $val3)
                        {
                                if ( is_numeric($index3) )
                                {
                                    // echo $index3.' - ' . $val3 . ' <br />';
                                }
                        }
                }

                //echo ' <br />';
        }

       //die();
       $exam_marks=ExamMarks::where('exam_id','=',$exam_id)->where('student_id','=',$student_id)->get();

             //foreach($rows as $row){
               //dd($row->SectionSubject->Subject->name);

             //}
         // echo "<pre>";
          //print_r($rows);
          //die();
      // $i=0;
     //  foreach($exam_marks as $exam_mark){

      // $name['subject_id'.$i]=$exam_mark->ExamSchedule->SectionSubject->Subject->id;
      // $i++;
       //}
       //dd($name);
       $rows=array();
       $rows=DB::table('exam_marks')
            ->join('result_format', 'exam_marks.section_subject_id', '=', 'result_format.section_subject_id')
            ->join('section_subjects', 'exam_marks.section_subject_id', '=', 'section_subjects.id')
            ->join('exam_schedules','exam_marks.exam_schedule_id','=','exam_schedules.id')
            ->join('subjects','exam_marks.subject_id','=','subjects.id')
            ->where('exam_marks.exam_id','=',$exam_id)
            ->where('exam_marks.student_id','=',$student_id)
            ->orderBy('result_format.result_format_status','asc')
            ->select('subjects.name','result_format.result_format_status','section_subjects.ispractical','exam_marks.marks','exam_schedules.total_marks')
            ->get();
            // echo "<pre>";
            //dd($rows);


            //print_r($rows);
          // die();

$uniques = array();
foreach ($rows as $row) {
    $uniques[] = $row['name'];
}
 //echo "<pre>";
//dd($uniques);
       $student=Student::find($student_id);
       $classes = Classes::all();
       //foreach($rows as $row){$array[]=$row;}
       if(sizeOf($rows) == 0)
       {

        return View::make('exams.listresult')
    ->with('classes', $classes)
    ->with('student', $student)
       ->with('exam_marks',$exam_marks)
     ->with('title', 'Result')
  ->with('page','Schedule');



       }
       else{



     $final=array();
       $exam_name=Exam::find($exam_id)->name;
//echo "<pre>";
//dd($array);
$subject_name=array_unique($uniques);
//echo "<pre>";
//dd($subject_name);
    return View::make('exams.listresult')
    ->with('classes', $classes)
    ->with('student', $student)
       ->with('exam_all',$exam_all)
       ->with('exam_marks',$exam_marks)
       ->with('rows',$rows)
       ->with('final_result',$final_result)
       ->with('exam_name', $exam_name)
       ->with('subject_names',$subject_name)
    ->with('title', 'Result')
    ->with('page','Schedule');
       }
   }

   	public function postAdminAproveRequest($id)
	{
		$ParentRequest = ParentRequest::find($id);
		if($ParentRequest)
		{
			$ParentRequest->status = 2;
			$ParentRequest->save();
			return Redirect::back()
			->with('success', 'Request Approved Succesfully !');
		}
		else
		{
			return Redirect::back()
			->with('error', 'Oops No Such Request Found !');
		}

   	}

   	public function postRejectRequest()
	{
		$reason = Input::get('reason');
		$id = Input::get('p_r_id');

            $ParentRequest = ParentRequest::find($id);
			if($ParentRequest)
			{
				$ParentRequest->status = 3;
				$ParentRequest->comment = $reason;
				$ParentRequest->save();
				return Redirect::to('view-request')
				->with('success', 'Request Successfully Rejected !');
			}
			else
			{
				return Redirect::to('view-request')
				->with('error', 'Oops No Such Request Found !');
			}


	}








}
