<?php

class ClassesController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('class.index')
		->with('title', 'All Classes')
		->with('page','Manage Classes')
		->with('classes', Classes::all());
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('class.create')
		->with('title','Create Classes')
		->with('page','Manage Classes');
	}


	



	public function edit($classes_id)
	{
		$classes=Classes::find($classes_id);
		return View::make('class.edit')
		->with('classes',$classes)
		->with('title','Edit Classes')
		->with('page','Manage Classes');
	}






       public function update()
	{
		$rules = array('name'  	 => 'required');
		$validator = Validator::make(Input::all(), $rules);
                $classes_id=Input::get('classes_id');
		
		    if ($validator->fails()) {
			 return Redirect::back()
			->withErrors($validator)
			->withInput();

		    }
		else
		{
			
			$classes =Classes::find($classes_id);
			$classes->name   = Input::get('name');
			$classes->save();

			
			Session::flash('success', 'Successfully Updated Class!');
			return Redirect::to('classes');
		}
	}
	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$rules = array(
			'code'       => 'required|unique:classes',
			'name'  	 => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('classes/create')
			->withErrors($validator)
			->with('title','Create Classes')
			->with('page','Manage Classes')
			->withInput();

		}
		else
		{
			// store
			$classe = new Classes;
			$classe->code       = Input::get('code');
			$classe->name   = Input::get('name');

			$classe->save();

			// redirect
			Session::flash('success', 'Successfully created Class!');
			return Redirect::to('classes/create')
			->with('title','Create Classes')
			->with('page','Manage Classes');
		}
	}

   


public function post_delete_class()
         {
            $classes_id = Input::get('classes_id');
            $classes = Classes::find($classes_id);
              if(is_null($classes->Section)){
               

                  Session::flash('success', 'Successfully deleted Classes!');
                  $classes->delete();

               
 
             }else{
                  
                    Session::flash('error', 'This class have sections!');
                 }
	    return Redirect::back();

         }

public function getSectionList()
	{
		$id = Input::get('classes_id');
		$classes=Classes::find($id);
		if($classes->Section->isEmpty()){

			 echo "<tr><td>No section added</td></tr>";
	
	}else
	    
	     	foreach($classes->Section as $section){
             echo "<tr><td>".$section->code."</td><td>".$section->name."</td></tr>";
		}
		
	}	

}
