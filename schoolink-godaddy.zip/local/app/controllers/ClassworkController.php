<?php
use Carbon\Carbon;
class ClassworkController extends Controller {

	
	public function getCreateClasswork()
	{	
		$classes = Classes::all();

		//dd($classes);
		 return View::make('classwork.classwork')
		->with('title', 'Create Classwork')
		->with('page','Manage Classwork')
		->with('classes', $classes);
	}  
	
	public function getViewClasswork($sec_sub_id)
	{	
		
		$classwork = Classwork::where('section_subject_id', '=', $sec_sub_id)->where('type','=',1)->get();
		$section_subject=SectionSubject::find($sec_sub_id);
        //dd($section_subject);
		 return View::make('classwork.view_classwork')
		->with('title', 'Create Classwork')
		->with('page','Manage Classwork')
		->with('classworks', $classwork)
		->with('section_subject',$section_subject)
		->with('sec_sub_id', $sec_sub_id);
	} 

	public function postViewClasswork()
	{	

		$sec_sub_id = Input::get('sec_sub_id');
		$section_subject = SectionSubject::find($sec_sub_id);
		$rules = array(
			'title'       => 'required',
			'description'       => 'required',
			'date'				=> 'required'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('view-classwork/'.$sec_sub_id)
			->withErrors($validator)
			->with('title','Create Classwork')
			->with('page','Manage Classwork');
			
		} else {
			
			$Classwork = new Classwork;
			$Classwork->section_id = $section_subject->section_id;
			$Classwork->section_subject_id = $sec_sub_id;
			$Classwork->title 	   = Input::get('title');
			$Classwork->description= Input::get('description');
			$Classwork->date       = Input::get('date');
			$Classwork->type       = 1;
			$created_by = "";
			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = "Teacher";
				}
			}	
			$Classwork->created_by = $created_by;
			$Classwork->save();
            
            $classwork_info =Classwork::find($Classwork->id); 
			if(isset($Classwork->id) && $Classwork->id != '' )
			 {  
			 	$students =  Student::where('section_id','=',$section_subject->section_id)->get();
				foreach($students as $student)
				{
					$parent_id = $student->parent_id;
					//dd($parent_id);
					$users = Parents::find($parent_id)->user;
					//dd($users);
					$Notification = new Notification;
				 	$Notification->user_id = $users->id;
				 	$Notification->student_id = $student->id;
				 	$Notification->subject = $Classwork->title ;
				 	$Notification->body = $Classwork->description;
				 	$Notification->object_id = $users->Parents->id;
				 	$Notification->object_type = "Parent";
				 	$Notification->is_read = 0;
				 	$Notification->sent_at = Carbon::now(new DateTimeZone('Asia/kolkata'));
				 	$Notification->save();

		$parents=Parents::find($student->parent_id);
           
        $student_id=$student->id;
       

		   $data= array('classwork' => $classwork_info, 'student_id' => $student_id);

           Mail::send('emails.classwork',$data,function($message) use ($parents)
		    {
			     
	         $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Classwork');
			   
	        });

		}

				Session::flash('success', 'Classwork successfully Created');
				return Redirect::to('view-classwork/'.$sec_sub_id);
			 }			
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('view-classwork/'.$sec_sub_id);
			 	
			 }

           }
	} 

	public function getViewAnnouncement($sec_sub_id)
	{	
		$classwork = Classwork::where('section_subject_id', '=', $sec_sub_id)->where('type','=',2)->get();
        $section_subject = SectionSubject::find($sec_sub_id);
		 return View::make('classwork.view_announcement')
		->with('title', 'Create Classwork')
		->with('page','Manage Classwork')
		->with('section_subject', $section_subject)
		->with('classworks', $classwork)
		->with('sec_sub_id', $sec_sub_id);
	}  
	public function postViewAnnouncement()
	{	

		$sec_sub_id = Input::get('sec_sub_id');
		$section_subject = SectionSubject::find($sec_sub_id);
		$rules = array(
			'title'       => 'required',
			'description' => 'required',
			'date'		  => 'required'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('view-announcement/'.$sec_sub_id)
			->withErrors($validator)
			->with('title','Create Classwork')
			->with('page','Manage Classwork');
			
		} else {
			
			$Classwork = new Classwork;
			$Classwork->section_id = $section_subject->section_id;
			$Classwork->section_subject_id = $sec_sub_id;
			$Classwork->title 	   = Input::get('title');
			$Classwork->description= Input::get('description');
			$Classwork->date       = Input::get('date');
			$Classwork->type       = 2;
			$created_by = "";
			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = "Teacher";
				}
			}	
			$Classwork->created_by = $created_by;

			//$Classwork->created_by       = $created_by;

			$Classwork->save();

			if(isset($Classwork->id) && $Classwork->id != '' )
			 {
                $students =  Student::where('section_id','=',$section_subject->section_id)->get();
				$homework_info =Classwork::find($Classwork->id);
				foreach($students as $student)
				{
					$parent_id = $student->parent_id;
					$users = Parents::find($parent_id)->user;
					
					$Notification = new Notification;
				 	$Notification->user_id = $users->id;
				 	$Notification->student_id = $student->id;
				 	$Notification->subject = $Classwork->title ;
				 	$Notification->body = $Classwork->description;
				 	$Notification->object_id = $users->Parents->id;
				 	$Notification->object_type = "Parent";
				 	$Notification->is_read = 0;
				 	$Notification->sent_at = Carbon::now(new DateTimeZone('Asia/kolkata'));
				 	$Notification->save();

				 	$parents=Parents::find($student->parent_id);
           
                    $student_id=$student->id;
       

		   $data= array('classwork' => $homework_info, 'student_id' => $student_id);

           Mail::send('emails.classwork',$data,function($message) use ($parents)
		    {
			     
	         $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Homework');
			   
	        });
				}

				Session::flash('success', 'Homework successfully Created');
				return Redirect::to('view-announcement/'.$sec_sub_id);
			 }			
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('view-announcement/'.$sec_sub_id);
			 	
			 }

           }
	} 

	
}
