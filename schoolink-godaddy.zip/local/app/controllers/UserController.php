<?php

class UserController extends \BaseController {

	public function index()
	{

	 return View::make('user.index')
	  ->with('users',User::all())
	  ->with('title','All Users')
	  ->with('page','Manage Users');
	}
	public function create()
	{
		return View::make('user.create')
		->with('title','Create User')
		->with('page','Manage Users');
	}
	public function store()
	{
		///dd(Input::all());
			$rules = array(
			
			'user_type'  => 'required',
			'email'      => 'required|email|unique:users',
			'password'  => 'required|confirmed',
			//'slug'      => '',
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('users/create')
			->withErrors($validator)
			->withInput();

				
		} else {
			// store
			$User = new User;
			$User->user_type  = Input::get('user_type');		
			$User->email      = Input::get('email');
			$User->password   = Hash::make(Input::get('password'));		
			$User->save();

			// redirect
			Session::flash('success', 'Successfully created user!');
			return Redirect::to('users/create');
		}
	}
			
	public function show($id)
	 {
		$user=User::find($id);
		return View::make('user.view')
        ->with('user', $user)
        ->with('title','View User')
	    ->with('page','Manage Users');
    }
	public function edit($id)
	{
		 $user=User::find($id);
		return View::make('user.edit')
        ->with('user', $user)
        ->with('title','Edit User')
	    ->with('page','Manage Users');

	}

	public function update($id)
	{
		
		$rules = array(
			'user_type'  => 'required',
			'email'      => 'required|email'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

				
		} else {
			// store
			$User=User::find($id);
			$User->user_type  = Input::get('user_type');		
			$User->email      = Input::get('email');
			 
			if(Input::hasFile('image'))
			  	{
				    $file = Input::file('image');
					$destinationPath = 'uploads/img';
					$filename = $file->getClientOriginalName();
					Input::file('image')->move($destinationPath, $filename);
					$User->image      = $filename;

		        }				
			$User->save();

			// redirect
			Session::flash('success', 'Successfully updated user!');
			return Redirect::to('users');
		}
	}

	
	
    public function postUserStatus(){

       $status = Input::get('status');
       $id = Input::get('id');
       $user=User::find($id);
       if($status == 'active'){
         $user->active = 1;
         $user->save(); 
         Session::flash('success', 'This user is active now');
         return 'success';
       }
       if($status == 'inactive'){
         $user->active = 0; 
         $user->save(); 
         Session::flash('error', 'This user is inactive now');
         return 'failed';
       }



    }
		
}
