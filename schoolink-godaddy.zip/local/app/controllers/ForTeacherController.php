<?php

class ForTeacherController extends BaseController {

	public function getClassWork()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);

		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();

		$i=0;
        foreach($teacher_subjects as $teacher_subject){


		       $teacher_timetables[]=TimetableDetails::where('section_subject_id','=', $teacher_subject->id)->get();
               $classes[] = $teacher_subject->Classes;
          $i++;
        }

		$i=0;

		return View::make('teacher.classwork.subject_classwork')
		->with('teacher_timetables',$teacher_timetables)
		->with('classes',array_unique($classes))
		->with('page','Assign Classwork')
		->with('title','Create Classwork');


	}

	public function getCreateClassWork($sec_sub_id)
	{

		$classwork = Classwork::where('section_subject_id', '=', $sec_sub_id)->where('type','=',1)->get();
        if($classwork->isEmpty())
        	$date =' ';
        else{
		foreach($classwork as $classwork){

			$date = $classwork->created_at->format('d/m/Y') ;
		}
	    }
		$section_subject =SectionSubject::find($sec_sub_id);

		 return View::make('teacher.classwork.create_classwork')
		->with('title', 'Create Classwork')
		->with('page','Assign Classwork')
		->with('date', $date)
		->with('section_subject', $section_subject);
	}

	public function getListClassWork()
	{

		$classwork = Classwork::where('type','=',1)->orderby('id', 'desc')->get();
                 
		 return View::make('teacher.classwork.list_classwork')
		->with('title', 'List Classwork')
		->with('page','Assign Classwork')
		->with('classworks', $classwork);
	}



	public function getTeacherPeriods()
	{

		$section_id = Input::get('section_id');
		$type = Input::get('type');
		$week_day = substr(date("l"), 0, 3);
		$val = '';

		$teacher_subjects=SectionSubject::where('teacher_id','=',Auth::user()->Teacher->id)->where('section_id','=',$section_id)->get();
		
		foreach($teacher_subjects as $teacher_subject){
		$timetable = TimetableDetails::where('section_id','=',$section_id)->where('week_day','=',$week_day)->where('section_subject_id','=', $teacher_subject->id)->get();

		if(!empty($timetable))

		   $data[] = $timetable;

		}



	 echo '<tr><th>Period</th><th>Subject</th><th>Classwork</th></tr>';
     foreach($data as $data){

     	foreach($data as $dat){

     		           $section_subject=SectionSubject::find($dat['section_subject_id']);
                        if($type == 1)
                        echo '<tr><td>'.$dat['lecture_num'].'</td><td>'.$section_subject->Subject->name.'</td><td><a href="teacher-create-classwork/'.$section_subject->id.'" class="btn btn-primary">Create Classwork</a></td></tr>';
                       else
                       echo '<tr><td>'.$dat['lecture_num'].'</td><td>'.$section_subject->Subject->name.'</td><td><a href="teacher-create-homework/'.$section_subject->id.'" class="btn btn-primary">Create Homework</a></td></tr>';
     	     }




		 }


		 //return $val;


	}

	public function postCreateClassWork()
	{

		$sec_sub_id = Input::get('sec_sub_id');
		$section_subject = SectionSubject::find($sec_sub_id);
		$rules = array(
			'title'       => 'required',
			'description'       => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		} else {

			$Classwork = new Classwork;
			$Classwork->section_id = $section_subject->section_id;
			$Classwork->section_subject_id = $sec_sub_id;
			$Classwork->title 	   = Input::get('title');
			$Classwork->description= Input::get('description');
			$Classwork->type       = 1;

			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = Auth::user()->id;
				}
			}
			$Classwork->created_by = $created_by;

			$Classwork->save();

			if(isset($Classwork->id) && $Classwork->id != '' )
			 {
				Session::flash('success', 'Classwork successfully Created for '.$section_subject->Subject->name);
				return Redirect::to('teacher-list-classwork');
			 }
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::back();

			 }

           }
	}

	public function getViewClassWork($classwork_id)
	{

		$classwork = Classwork::find($classwork_id);


		 return View::make('teacher.classwork.view_classwork')
		->with('title', 'View Classwork')
		->with('page','Assign Classwork')
		->with('classwork', $classwork);
	}

	public function getEditClassWork($classwork_id)
	{

		$classwork = Classwork::find($classwork_id);


		 return View::make('teacher.classwork.edit_classwork')
		->with('title', 'Edit Classwork')
		->with('page','Assign Classwork')
		->with('classwork', $classwork);
	}


	public function postEditClassWork()
	{

		$rules = array(
			'title'             => 'required',
			'description'       => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		} else {

			$Classwork = Classwork::find(Input::get('id'));
			$Classwork->title 	   = Input::get('title');
			$Classwork->description= Input::get('description');

			  if($Classwork->save()){

				Session::flash('success', 'Classwork successfully updated for '.$Classwork->SectionSubject->Subject->name);
				return Redirect::to('teacher-edit-classwork/'.$Classwork->id);
			 }
			  else{

			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::back();

			  }

           }
	}

	public function postDeleteClassWork()
	{
		$classwork_id=Input::get('classwork_id');
		$pattern=Input::get('pattern');
		$classwork = Classwork::find($classwork_id);
		$classwork ->delete();
		if(!empty($pattern)){
			$data="success";
			return $data;
		}else{
			Session::flash('success', 'Successfully deleted Classwork!');
			return Redirect::back();
		}
	}


public function getHomework()
	{
		$teachers=Teacher::find(Auth::user()->Teacher->id);

		$teacher_subjects=SectionSubject::where('teacher_id','=',$teachers->id)->get();

		$i=0;
        foreach($teacher_subjects as $teacher_subject){


		       $teacher_timetables[]=TimetableDetails::where('section_subject_id','=', $teacher_subject->id)->get();
               $classes[] = $teacher_subject->Classes;
          $i++;
        }

		$i=0;

		return View::make('teacher.homework.subject_homework')
		->with('teacher_timetables',$teacher_timetables)
		->with('classes',array_unique($classes))
		->with('page','Assign Homework')
		->with('title','Create Homework');


	}

	public function getCreateHomework($sec_sub_id)
	{

		$classwork = Classwork::where('section_subject_id', '=', $sec_sub_id)->where('type','=',2)->get();
        if($classwork->isEmpty())
        	$date =' ';
        else{
		foreach($classwork as $classwork){

			$date = $classwork->created_at->format('d/m/Y') ;
		}
	    }
		$section_subject =SectionSubject::find($sec_sub_id);

		 return View::make('teacher.homework.create_homework')
		->with('title', 'Create Homework')
		->with('page','Assign Homework')
		->with('date', $date)
		->with('section_subject', $section_subject);
	}

	public function getListHomework()
	{

		$classwork = Classwork::where('type','=',2)->orderby('id', 'desc')->get();

		 return View::make('teacher.homework.list_homework')
		->with('title', 'List Homework')
		->with('page','Assign Homework')
		->with('classworks', $classwork);
	}





	public function postCreateHomework()
	{

		$sec_sub_id = Input::get('sec_sub_id');
		$section_subject = SectionSubject::find($sec_sub_id);
		$rules = array(
			'title'       => 'required',
			'description'       => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		} else {

			$Classwork = new Classwork;
			$Classwork->section_id = $section_subject->section_id;
			$Classwork->section_subject_id = $sec_sub_id;
			$Classwork->title 	   = Input::get('title');
			$Classwork->description= Input::get('description');
			$Classwork->type       = 2;

			if(Auth::check())
			{
				if(Auth::user()->user_type=='1')
				{
					$created_by = "Admin";
				}
				if(Auth::user()->user_type=='2')
				{
					$created_by = Auth::user()->id;
				}
			}
			$Classwork->created_by = $created_by;

			$Classwork->save();

			if(isset($Classwork->id) && $Classwork->id != '' )
			 {
				Session::flash('success', 'Homework successfully Created for '.$section_subject->Subject->name);
				return Redirect::to('teacher-list-homework');
			 }
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::back();

			 }

           }
	}

	public function getViewHomework($classwork_id)
	{

		$classwork = Classwork::find($classwork_id);


		 return View::make('teacher.homework.view_homework')
		->with('title', 'View Homework')
		->with('page','Assign Homework')
		->with('classwork', $classwork);
	}

	public function getEditHomework($classwork_id)
	{

		$classwork = Classwork::find($classwork_id);


		 return View::make('teacher.homework.edit_homework')
		->with('title', 'Edit Homework')
		->with('page','Assign Homework')
		->with('classwork', $classwork);
	}


	public function postEditHomework()
	{

		$rules = array(
			'title'             => 'required',
			'description'       => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		} else {

			$homework = Classwork::find(Input::get('id'));
			$homework->title 	   = Input::get('title');
			$homework->description= Input::get('description');

			  if($homework->save()){

				Session::flash('success', 'Homework successfully updated for '.$homework->SectionSubject->Subject->name);
				return Redirect::to('teacher-edit-homework/'.$homework->id);
			 }
			  else{

			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::back();

			  }

           }
	}

	public function postDeleteHomework()
	{
		$homework_id=Input::get('homework_id');
		$pattern=Input::get('pattern');
		$homework = Classwork::find($homework_id);
		$homework ->delete();
		if(!empty($pattern)){
			$data="success";
			return $data;
		}else{
			Session::flash('success', 'Successfully deleted Homework!');
			return Redirect::back();
		}
	}


    public function getStudentUpdate()
	{

		return View::make('teacher.updates.create_update')
		->with('classes', Classes::all())
		->with('title','Create Update')
		->with('page','Manage Student Updates');
	}


	public function postStudentUpdate()
	{

		$rules = array(
			'classes_id'    => 'required',
			'section_id'    => 'required',
			'student_id'    => 'required',
			'title' 		=> 'required',
			'description'   => 'required'
		);


    $messages = array(
        'classes_id.required' => 'Please select class',
        'section_id.required'  => 'Please select section',
        'student_id.required'  => 'please select student',
        'title.required'  => 'please enter a title',
        'description.required'  => 'please enter a description'
    );

		$validator = Validator::make(Input::all(), $rules,$messages);


		if ($validator->fails())
		{
			return Redirect::back()
			->withErrors($validator)
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		}
		else
		{
			$StudentBulletin =StudentBulletin::where('student_id', Input::get('student_id'))->whereDate('created_at', '=',  date('Y-m-d'))->get();
			
			if($StudentBulletin->count() > 0){
              
              	Session::flash('error', 'Student update already created for this student!');
				return Redirect::to('list-student-update');

			}else{
				$StudentBulletin = new StudentBulletin;
				$StudentBulletin->classes_id    = Input::get('classes_id');
				$StudentBulletin->section_id    = Input::get('section_id');
				$StudentBulletin->student_id    = Input::get('student_id');
				$StudentBulletin->title         = Input::get('title');
				$StudentBulletin->description   = Input::get('description');
				$StudentBulletin->created_by = Auth::user()->id;
				$StudentBulletin->status = 1;
				$StudentBulletin->save();
				Session::flash('success', 'Student update created successfully!');
				return Redirect::back();

            } // else close 

		} // else close

	}



public function getListStudentUpdate()
	{

		$student_updates = StudentBulletin::where('status','=',1)->whereDate('created_at', '=',  date('Y-m-d'))->orderby('id', 'desc')->get();

		 return View::make('teacher.updates.list_update')
		->with('title', 'List Update')
		->with('page','Manage Student Updates')
		->with('student_updates', $student_updates);
	}


   public function getViewStudentUpdate($id)
	{

		$student_update = StudentBulletin::find($id);


		 return View::make('teacher.updates.view_update')
		->with('title', 'View Student Update')
		->with('page','Manage Student Updates')
		->with('student_update', $student_update);
	}

	public function getEditStudentUpdate($id)
	{

		$student_update = StudentBulletin::find($id);


		 return View::make('teacher.updates.edit_update')
		->with('title', 'Edit Student Update')
		->with('page','Manage Student Updates')
		->with('sections', Section::all())
		->with('students', Student::all())
		->with('classes', Classes::all())
		->with('student_update', $student_update);
	}

	public function postEditStudentUpdate()
	{

		$rules = array(
			'title' 		=> 'required',
			'description'   => 'required',
			'classes_id'   => 'required',
			'section_id'   => 'required',
			'student_id'   => 'required'
		);


    $messages = array(
        'title.required'  => 'please enter a title',
        'description.required'  => 'please enter a description',
        'classes_id.required'  => 'please select class',
        'section_id.required'  => 'please select section',
        'student_id.required'  => 'please select student'
    );

		$validator = Validator::make(Input::all(), $rules,$messages);


		if ($validator->fails())
		{
			return Redirect::back()
			->withErrors($validator)
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		}
		else
		{
			$StudentBulletin = StudentBulletin::find(Input::get('id'));
			
			$StudentBulletin->classes_id    = Input::get('classes_id');
			$StudentBulletin->section_id    = Input::get('section_id');
			$StudentBulletin->student_id    = Input::get('student_id');
			$StudentBulletin->title         = Input::get('title');
			$StudentBulletin->description   = Input::get('description');
			$StudentBulletin->save();


			Session::flash('success', 'Student update updated successfully!');
		    return Redirect::to('list-student-update');


		}

	}

	public function postDeleteStudentUpdate()
	{
		$updates_id=Input::get('updates_id');
		$pattern=Input::get('pattern');
		$update = StudentBulletin::find($updates_id);
		$update ->delete();
		if(!empty($pattern)){
			$data="success";
			return $data;
		}else{
			Session::flash('success', 'Successfully deleted Student Update!');
			return Redirect::back();
		}
	}


    public function getViewInfo()
	{
		$info = Info::first();
		return View::make('teacher.schoolinfo.info')
		->with('title', 'View School Info')
		->with('page','School Info')
		->with('info', $info);
	}





}
