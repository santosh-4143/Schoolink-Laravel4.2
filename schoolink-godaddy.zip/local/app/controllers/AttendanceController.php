<?php

class AttendanceController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}


   public function listClasses()
	{	$classes = Classes::all();
		//dd($classes);
		 return View::make('attendance.listclass')
		->with('title', 'Check Attendance')
		->with('page','Manage Attendance')
		->with('classes', $classes);
	}  

	public function listSections($classes_id)
	{
		 $sections = Section::where('classes_id','=',$classes_id)->get();
		
		$ids = DB::table('sections')
            ->whereExists(function($query)
            {
                $query->select(DB::raw('timetable_masters.section_id'))
                      ->from('timetable_masters')
                      ->whereRaw('timetable_masters.section_id = sections.id');
            }) ->where('classes_id','=',$classes_id)->get();
            
         //dd($ids);

         //die();
		  return View::make('attendance.listsection')
		->with('title', 'Check Attendance')
		->with('page','Manage Attendance')
		->with('sections',$ids);
	} 

	public function viewAttendance($section_id)
	{
		$section = Section::find($section_id);
        //dd("<pre>".$section."</pre>");
	     return View::make('attendance.totalattendance')
		->with('title', 'Check Attendance')
		->with('page','Manage Attendance')
		->with('section',$section);	
		
	}  


 public function postViewAttendance()
	{
		
       $rules = array(
			
			'date'  	 => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

        $section_id=Input::get('section_id');
        $section = Section::find($section_id);
		// process the login
		if ($validator->fails()) {
			return Redirect::to('attendance-view/'.$section_id)
		->withErrors($validator)
		->with('title', 'Check Attendance')
		->with('page','Manage Attendance')
		->with('section',$section);	
		}

      else{

          $date=Input::get('date'); 
          $attendances=Attendance::where('section_id','=',$section_id)->where('date','=',$date)->get();
         // dd("<pre>".$section."</pre>");
        //return Redirect::to('attendance-view/'.$section_id)
         return View::make('attendance.totalattendance')
        ->with('title', 'Check Attendance')
		->with('page','Manage Attendance')
		->with('attendances',$attendances)
		->with('section',$section);	

      }

	} 



	public function listTimetable($section_id)
	{
        $timetable_details = Section::find($section_id)->TimetableDetails;
        $timetables = Timetable::where('section_id','=',$section_id)->get();
        
	     return View::make('attendance.timetableview')
		->with('title', 'Check Attendance')
		->with('page','Manage Attendance')
		->with('timetable_details',$timetable_details)
		->with('timetables',$timetables);	
	}

	public function listStudent($timetable_detail_id)
	{
		
        $timetable_details = TimetableDetails::find($timetable_detail_id);
      
        $attendances = Attendance::where('section_id','=',$timetable_details->section_id)->where('date', '=', date('Y-m-d'))->where('lecture_num', '=',$timetable_details->lecture_num )->get();

        $students=Student::where('section_id','=',$timetable_details->section_id)->get();

	    //dd("<pre>".$students->Student."</pre>");
	     return View::make('attendance.studentlist')
	     ->with('title', 'Check Attendance')
		 ->with('page','Manage Attendance')
		 ->with('students',$students )
		 ->with('timetable_details',$timetable_details)
		 ->with('attendances',$attendances);
         
	}


	public function postAttendance()
	{
		
       $rules = array(
			
			
		);
		$validator = Validator::make(Input::all(), $rules);

        $timetable_details_id=Input::get('timetable_details_id');
		// process the login
		if ($validator->fails()) {
			return Redirect::to('check-attendance/'.$timetable_details_id)
			->withErrors($validator)
			->with('title','Check Attendance')
			->with('page','Manage Attendance');
			

				
		} else {

			// store

			$timetable_details_id=Input::get('timetable_details_id');
			$student_id=Input::get('student_id');
			$section_subject_id=Input::get('section_subject_id');
			$section_id=Input::get('section_id');
			$date=date('Y-m-d');
			$lecture_num=Input::get('lecture_num');
            $students = Student::where('section_id','=',$section_id)->get();
            $timetable_details = TimetableDetails::find($timetable_details_id);
			


			//dd($user_id);
			$student_size=sizeof($student_id);
            //dd($student_size);



$update_attendances= Attendance::where('section_id','=',$section_id)->where('date', '=', date('Y-m-d'))->where('lecture_num', '=',$lecture_num)->get();
//dd($update_attendances);
		

        if($update_attendances->count() > 0)   
            {
             $i=0;  
            foreach($update_attendances as $update_attendance)	
             
             {
             $update=Attendance::find($update_attendance->id);
             //dd("<pre>".$update."</pre>");
             $update->status=Input::get('att'.$i)[0];
             //dd(Input::get('att'.$i)[0]);
             $i++;
             $update->save();
             }
          }
        else
           {

           for($i=0;$i<$student_size;$i++){
            $check_attendance = new Attendance;
			$check_attendance->section_subject_id = $section_subject_id;
		    $check_attendance->student_id = $student_id[$i];
            //dd($check_attendance->student_id);
            $check_attendance->section_id = $section_id;
		    $check_attendance->status = Input::get('att'.$i)[0];
		      //dd($i); 
		    //dd($check_attendance->status);
			$check_attendance->user_id = Auth::user()->id;
			$check_attendance->date = $date;
			$check_attendance->lecture_num = $lecture_num;
					
			//dd("<pre>".$assignment_marks->admin_id."</pre>");		
				$check_attendance->save();
               }
        }
           
			// redirect
			
	     Session::flash('success', 'Successfully marked Attendance!');
		 return Redirect::to('check-attendance/'.$timetable_details_id)
	      ->with('title', 'Check Attendance')
		  ->with('page','Manage Attendance')
		  ->with('students',$students)
		  ->with('timetable_details',$timetable_details);
         
	}

}



	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}




	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
