<?php

class SubjectController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
	  return View::make('subject.index')
	  ->with('subjects',Subject::all())
	  ->with('title','List Subjects')
	  ->with('page','Manage Subjects');
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('subject.create')
		->with('title','Create Subject')
		->with('page','Manage Subjects');

	}


	public function edit($subject_id)
	{
		$subject = Subject::find($subject_id);

		return View::make('subject.edit')
		->with('subject',$subject)
		->with('title','Edit Subject')
		->with('page','Manage Subjects');

	}

	public function update($id)
	{
		
		$rules = array(
			'name'  	 => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);	
		   if($validator->fails()){
			return Redirect::back()
			->withErrors($validator)
			->withInput();
		}
		else
		{	
			$subject =Subject::find($id);
			$subject->name   = Input::get('name');
			$subject->save();
			Session::flash('success', 'Successfully Updated Subject!');
			return Redirect::to('subjects');
		}

	}


	public function postDeleteSubject(){

		$subject_id=Input::get('subject_id');
		$subject=Subject::find($subject_id);

		if(is_null($subject->SectionSubject)){

			Session::flash('success', 'Successfully deleted Subject!');
			$subject->delete();

		}else{

			Session::flash('error', 'This subject is assigned! Please delete assigned subject first');
		}

		Session::flash('success', 'Successfully deleted Subject!');
		return Redirect::back();
	}

public function getAssign()
 {

  return View::make('subject.assign')
  ->with('title','Assign Subjects')
  ->with('page','Manage Subjects')
  ->with('subjects', Subject::all())
  ->with('classes', Classes::all())
  ->with('sections', Section::all())
  ->with('teachers', Teacher::all());
  }

 public function getAssigned()
 {

  return View::make('subject.assigned')
  ->with('title','Assign Subject')
  ->with('page','Manage Subjects')
  ->with('subjects', Subject::all())
  ->with('classes', Classes::all())
  ->with('sections', Section::all())
  ->with('teachers', Teacher::all());
 }


 public function getAssignedsubject()
 {

	 $section_subjects = SectionSubject::all();
	 return View::make('subject.assigned')
	 ->with('title', 'Assigned Subjects')
	 ->with('page','Manage Subjects')
	 ->with('section_subjects',$section_subjects)
	 ->with('classes', Classes::all());

 }


public function get_section_subjects_details(){
	$section_id = Input::get('section_id');
	$sections=Section::find($section_id );
	$section_subjects = SectionSubject::where('section_id','=',$section_id)->get();
	$name=array();

	foreach($section_subjects as $section_subject){


		$data=array();
		$query=DB::table('subjects')->where('id','=', $section_subject->subject_id)->get();
		$teacher=DB::table('teachers')->where('id','=', $section_subject->teacher_id)->get();
		$data['ispractical'] = $section_subject->ispractical;
		$data['data'] =$query;
		$data['classes']=$sections->Classes->name;
		$data['section']=$sections->name;
		$data['teacher']=$teacher;


		$name[]= $data;

	}
	  return Response::Json($name);
	}

   public function getEditAssignedSubject($subject_id)
	 {
		 $section_subject=SectionSubject::find($subject_id);
		 return View::make('subject.editassigned')
		 ->with('title', 'Assigned Subjects')
		 ->with('page','Manage Subjects')
		 ->with('section_subject',$section_subject)
		 ->with('subjects', Subject::all())
		 ->with('sections', Section::all())
		 ->with('classes', Classes::all())
		 ->with('teachers', Teacher::all());
	 }


   public function postEditAssignedSubject()
   {
		 $rules = array(
			 'classes_id' => 'required',
			 'section_id' => 'required',
			 'teacher_id' => 'required'
		 );

		$messages = array(
			 'classes_id.required' => 'Please select a class!',
			 'teacher_id.required' => 'Please select a teacher!',
		 );

		$validator = Validator::make(Input::all(), $rules, $messages);
		if ($validator->fails()) {

			$messages = $validator->messages();
			return Redirect::back()->withInput()->withErrors($validator);

		} else {
			// store
			$subject_id = Input::get('id');
			$secsub = SectionSubject::find($subject_id);
			$secsub->classes_id  = Input::get('classes_id');
			$secsub->section_id  = Input::get('section_id');
			$secsub->teacher_id  = Input::get('teacher_id');
			$secsub->save();

			// redirect
			Session::flash('success', 'Successfully Updated Assigned Subject!');
			return Redirect::back();

		}



   }



	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		///dd(Input::all());
			$rules = array(
			'code'       => 'required|unique:subjects',
			'name'  	 => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('subjects/create')
			->withErrors($validator)
			->with('title','Create Subject')
			->with('page','Manage Subjects');

		} else {
			// store
			$subjects = new Subject;
			$subjects->code  = strtoupper(Input::get('code'));
			$subjects->name  = strtoupper(Input::get('name'));
			$subjects->save();

			// redirect
			Session::flash('success', 'Successfully created Subject!');
			return Redirect::to('subjects/create')
			->with('title','Create Subject')
			->with('page','Manage Subjects');
		}
	}

   public function postAssignsubject(){

$rules = array(
			'subject_id' => 'required',
			'classes_id' => 'required',
			'section_id' => 'required',
			'teacher_id' => 'required'

		);
        $subject_id=Input::get('subject_id');
        $section_id=Input::get('section_id');
		$validator = Validator::make(Input::all(), $rules);
		$query= SectionSubject::where('section_id','=',$section_id)->where('subject_id','=',$subject_id)->get();
        //dd("<pre>".$query->Count()."</pre>");
		// process the login
		if ($query->Count() > 0) {
			Session::flash('error', 'Subject already assigned for this section!');
			return Redirect::back()->withInput()->withErrors($validator);




		} else {
			// store

			 $practical=Input::get('practical');
			 $i=0;

             if($practical == 1)
              {
                $secsub_first = new SectionSubject;
			    $secsub_first ->subject_id  = $subject_id;
			    $secsub_first ->ispractical = 1;
			    $secsub_first ->classes_id    = Input::get('classes_id');
			    $secsub_first ->section_id  = $section_id;
		      	$secsub_first ->teacher_id  = Input::get('teacher_id');
		    	$secsub_first->save();

                $secsub_second = new SectionSubject;
		    	$secsub_second ->subject_id  = $subject_id;
			    $secsub_second ->ispractical = 0;
			    $secsub_second ->classes_id    = Input::get('classes_id');
			    $secsub_second ->section_id  = $section_id;
		      	$secsub_second ->teacher_id  = Input::get('teacher_id');
		    	$secsub_second->save();

			 }else{

		   	    $secsub = new SectionSubject;
			    $secsub ->subject_id  = $subject_id;
			    $secsub ->ispractical = 2;
			    $secsub ->classes_id    = Input::get('classes_id');
			    $secsub ->section_id  = $section_id;
		      	$secsub ->teacher_id  = Input::get('teacher_id');
		    	$secsub->save();



		   }


			// redirect
			Session::flash('success', 'Successfully Assigned Subject!');
			return Redirect::to('assign-subject')
			->with('title','Create Subject')
			->with('page','Manage Subjects');
		}
  }

	public function postDeleteAssignedSubject()
	{
		$section_subject_id=Input::get('section_subject_id');
		$pattern=Input::get('pattern');
		$section_subject = SectionSubject::find($section_subject_id);
		$section_subject ->delete();
		if(!empty($pattern)){
			$data="success";
			return $data;
		}else{
			Session::flash('success', 'Successfully deleted Assigned Subject!');
			return Redirect::back();
		}
	}


	



public function getSectionSubject(){

     $student_id = Input::get('student_id');
     if($student_id){
     $student = Student::find($student_id);
     $sectionSubject = SectionSubject::where('section_id',$student->section_id)->get();

     if($sectionSubject->isEmpty()){

			 echo "<tr><td>No subject found</td></tr>";
	
	}else{
	        $i = 1;
	     	foreach($sectionSubject as $sectionSubject){
              echo "<tr><td>".$i."</td><td>".$sectionSubject->Subject->name."</td><td>".$sectionSubject->Teacher->fname.' '.$sectionSubject->Teacher->lname."</td></tr>";

                $i++;
	            } // for loop close

		}  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>Invalid Student Selection</td></tr>";

	}




} //class close
