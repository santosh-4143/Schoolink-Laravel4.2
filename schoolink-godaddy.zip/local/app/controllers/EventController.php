<?php

class EventController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		  
          $events = SchoolEvent::orderBy('id','desc')->get();
          return View::make('event.index')
           ->with('title','List Event')
		   ->with('page','Manage Event')
           ->with('events', $events);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		  return View::make('event.create')
		  ->with('title','Create New Event')
		  ->with('page','Manage Event');
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$rules = array(
			 'title'       => 'required',
			'description'  	 => 'required',
			'date'  	 => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$schoolevent = new SchoolEvent;
			$schoolevent->title         = Input::get('title');
			$schoolevent->description   = Input::get('description');
			$schoolevent->date   = Input::get('date');
			$schoolevent->start_time   = Input::get('start_time');
			$schoolevent->end_time   = Input::get('end_time');
			$schoolevent->save();

			// redirect
			Session::flash('success', 'Successfully created Event!');
			return Redirect::to('event');
		}
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		  $events = SchoolEvent::find($id);
		 return View::make('event.view')
		  ->with('title','View Event')
		  ->with('page','Manage Event')
		   ->with('events', $events);

	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		  $events = SchoolEvent::find($id);
		 return View::make('event.edit')
		  ->with('title','Edit Event')
		  ->with('page','Manage Event')
		   ->with('events', $events);

	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$rules = array(
			'title'       => 'required',
			'description'  	 => 'required',
			'date'  	 => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$schoolevent = SchoolEvent::find($id);
			$schoolevent->title         = Input::get('title');
			$schoolevent->description   = Input::get('description');
			$schoolevent->date   = Input::get('date');
			$schoolevent->start_time   = Input::get('start_time');
			$schoolevent->end_time   = Input::get('end_time');
			$schoolevent->save();

			// redirect
			Session::flash('success', 'Successfully Updated Event!');
			return Redirect::to('event');
		}
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function postDeleteEvent()
	{
		$id = Input::get('event_id');
		$schoolevent = SchoolEvent::find($id);
		$schoolevent->delete();
		Session::flash('success', 'Successfully Deleted Event!');
		return Redirect::to('event');

	}


}
