<?php

class ForParentController extends BaseController {



	public function getParentProfile(){

		$Parents = Parents::find(Auth::user()->Parents->id);
		$Students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
	   
		return View::make('parent.profile.profile')
		->with('Parents',$Parents)
		->with('Students',$Students)
		->with('title','View Profile')
		->with('page','My Profile');
	}

    public function getChildList(){

     	$Parents = Parents::find(Auth::user()->Parents->id);
		$Students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
		
		return View::make('parentpage.childlist')
		->with('Parents',$Parents)
		->with('Students',$Students)
		->with('title','Class Subjects')
		->with('page','Manage Classes');

    } 


  public function getSubjectList(){

        $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();

        return View::make('parent.subject.subject')
        ->with('students',$students)
		->with('title','Class Subjects')
		->with('page','My Child');
        

    } 

   public function getTimetable(){

        $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();

        return View::make('parent.timetable.timetable')
		->with('students',$students)
		->with('title','Class Timetable')
		->with('page','My Child');
        

    } 


    public function getTimetableView(){
 
        $student_id=Input::get('student_id');
        $student=Student::find($student_id);
        if($student_id){

        $timetables = Timetable::where('section_id','=',$student->section_id)->first();
        if($timetables){
        echo "<p>Name : ".$student->fname.' '.$student->lname."</p>";
        echo "<p>Class : ".$student->Classes->name."</p>";
        echo "<p>Section : ".$student->Section->name."</p><br/>";

        echo "<table class='table table-bordered table-hover'>";
        echo "<tbody>";
        echo "<tr>";
        for ($i = 1; $i <= $timetables->max_lectures ; $i++){

            echo "<td style='text-align:center;'><span class='label label-info graded'>Period ".$i."</span></td>";
         }
        echo "</tr>";
      
        echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'mon'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Monday</span></td>";

        	}
        }
         
         echo "</tr>";
         echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'mon'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
         echo "</tr>";


      echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'tue'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Tuesday</span></td>";

        	}
        }
         
         echo "</tr>";

        
           echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'tue'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
         echo "</tr>";

       echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'wed'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Wednesday</span></td>";

        	}
        }
         
         echo "</tr>";

           
             echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'wed'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
         echo "</tr>";


 echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'thu'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Thursday</span></td>";

        	}
        }
         
         echo "</tr>";
           
             echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'thu'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
         echo "</tr>";


       echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'fri'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Friday</span></td>";

        	}
        }
         
         echo "</tr>";
            
             echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'fri'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
          echo "</tr>";

      echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'sat'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Saturday</span></td>";

        	}
        }
         
         echo "</tr>";

          echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'sat'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
         echo "</tr>";

         

          echo "<tr>"; 
        foreach($timetables->TimetableDetails as $data){

        	if($data->week_day == 'sun'){

        		echo "<td style='text-align:center;'><span class='badge badge-azure badge-square'>Sunday</span></td>";

        	}
        }
         
          echo "</tr>";
          echo "<tr>";
         foreach($timetables->TimetableDetails as $data){
           
         	if($data->week_day == 'sun'){
                 
         		   
         		   echo "<td><div class='form-group'>";

         			echo "<span class='label label-primary' style='text-align:center;'>";

         			if($data->section_subject_id == 'off' || $data->section_subject_id == '')
         				echo 'Not Alloted';
         			elseif($data->section_subject_id == 'break')
         				echo 'Break';
         			else
         				echo  $data->SectionSubject->Subject->name.'</span></div>';

         			if($data->section_subject_id == 'off' || $data->section_subject_id == 'break' || $data->section_subject_id == ''){
                        
                        echo '';

         			}

         				else{
         					echo "<div class='form-group'> <span class='label label-success'>".$data->start_time."</span>-<span class='label label-success'>".$data->end_time."</span></div><div class='form-group'>
         					<span class='label label-info'>Teacher : ".$data->SectionSubject->Teacher->fname.' '.$data->SectionSubject->Teacher->lname."</span></div><div class='form-group'><span class='label label-info'>Facility No : ".$data->facility."</span></div>";
         				}
         				echo "</td>";
        	} // if weekday is monday 
          }  // loof for  timetable
         echo "</tr>";

           

          echo "</tbody>";
          echo "</table>";

          }else

            echo "<p style='color:red;'>No timetable created for this class</p>";
             
        }else
              echo "<p style='color:red;'>Invalid student selection</p>";

    } 

    public function getSchoolUpdate()
    {
        $updates = Announcement::where('status',1)->get();
        return View::make('parent.update.schoolUpdate')
        ->with('updates',$updates)
        ->with('title','View School Update')
        ->with('page','Updates');
    }

public function getSchoolUpdateDetails(){

     $update_id = Input::get('update_id');
     if($update_id){
     $update = Announcement::find($update_id);
    

     if($update->count() == 0){

             echo "<tr><td>No School Update found</td></tr>";
    
    }else{
         
            
   echo "<tr><th>Date</th><td>".$update->created_at->format('d/m/Y')."</td></tr><tr><th>Title</th><td>".$update->title."</td></tr><tr><th>Description</th><td>".$update->description."</td></tr>";

              
               

        }  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>No data found</td></tr>";

    }


  public function getTeacherUpdate()
    {
        $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
        return View::make('parent.update.teacherUpdate')
        ->with('students',$students)
        ->with('title','View Teacher Update')
        ->with('page','Updates');
    }

    public function postTeacherUpdate()
    {
    
    $student_id = Input::get('student_id');
     if($student_id){
     $student = Student::find($student_id);
     $updates = StudentBulletin::where('student_id',$student->id)->get();

     if($updates->isEmpty()){

             echo "<tr><td>No teacher updates found</td></tr>";
    
    }else{
            $i = 1;
            foreach($updates as $update){
              echo "<tr><td>".$i."</td><td>".$update->created_at->format('d/m/Y')."</td><td>".$update->title."</td><td>".$update->User->Teacher->fname.' '.$update->User->Teacher->lname."</td><td><a href='#' name='update-btn' class='btn btn-primary update-btn' data-update_id='".$update->id."'>View</a></td></tr>";

                $i++;
                } // for loop close

        }  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>Invalid Student Selection</td></tr>";

       
    }

public function getTeacherUpdateDetails(){

     $update_id = Input::get('update_id');
     if($update_id){
     $update = StudentBulletin::find($update_id);
    

     if($update->count() == 0){

             echo "<tr><td>No School Update found</td></tr>";
    
    }else{
         
            
   echo "<tr><th>Date</th><td>".$update->created_at->format('d/m/Y')."</td></tr><tr><th>Class</th><td>".$update->Classes->name."</td></tr><tr><th>Section</th><td>".$update->Section->name."</td></tr><tr><th>Title</th><td>".$update->title."</td></tr><tr><th>Description</th><td>".$update->description."</td></tr>";

              
               

        }  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>No data found</td></tr>";

    }


public function getEvents()
    {
        $events = SchoolEvent::orderBy('id','desc')->get();
        return View::make('parent.event.event')
        ->with('events',$events)
        ->with('title','View Events')
        ->with('page','Events');
    }


public function getEventDetails(){

     $event = Input::get('event_id');
     if($event){
     $event = SchoolEvent::find($event);
    

     if($event->count() == 0){

             echo "<tr><td>No School Update found</td></tr>";
    
    }else{
         
            
   echo "<tr><th>Date</th><td>".$event->date."</td></tr><tr><th>Title</th><td>".$event->title."</td></tr><tr><th>Description</th><td>".$event->description."</td></tr><tr><th>Start</th><td>".$event->start_time."</td></tr><tr><th>End</th><td>".$event->end_time."</td></tr>";

              
               

        }  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>No data found</td></tr>";

    }




      public function getGalleryList()
    {
         $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
        return View::make('parent.gallery.list')
        ->with('students',$students)
        ->with('title','List Gallery')
        ->with('page','Gallery');
    }

    public function postGalleryList()
    {
    
    $student_id = Input::get('student_id');
     if($student_id){
     $student = Student::find($student_id);
     $galleries = Photo::where('section_id',$student->section_id)->get();

     if($galleries->isEmpty()){

             echo "<tr><td colspan='5' style='color:red;'>No galleries found</td></tr>";
    
    }else{
            $i = 1;
            foreach($galleries as $galleries){
              echo "<tr><td>".$i."</td><td>".$galleries->date."</td><td>".$galleries->code."</td><td>".$galleries->event."</td><td><a href='view-gallery/".$galleries->id."' name='gallery-btn' target='_blank' class='btn btn-primary gallery-btn' data-gallery_id='".$galleries->id."'>View</a></td></tr>";

                $i++;
                } // for loop close



        }  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>Invalid Student Selection</td></tr>";

       
    }


 public function getGalleryImages($id){
        $photo = Photo::find($id);
        $galleries = Galleries::where('photo_id',$id)->get();
        return View::make('parent.gallery.view')
        ->with('photo', $photo)
        ->with('galleries', $galleries)
        ->with('title', 'View Gallery')
        ->with('page','Gallery');   

 }

    public function getViewInfo()
    {
        $info = Info::first();
        return View::make('parent.info.info')
        ->with('title', 'View School Info')
        ->with('page','School Info')
        ->with('info', $info);
    }



     public function getAttendance(){

         $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
        
	     return View::make('parentpage.view_attendance')
		->with('title', 'Child Attendance')
		->with('page','Attendance')
		->with('students',$students);	

	 }

	 public function postAttendance(){

        $rules = array(
			
			'date'  	 => 'required',
			'student'  	 => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

       
		if ($validator->fails()) {
			return Redirect::to('view-attendance')
		    ->withErrors($validator);	
		}

      else{

          $date=Input::get('date'); 
          $student_id=Input::get('student'); 
           $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
          $attendances=Attendance::where('student_id','=',$student_id)->where('date','=',$date)->get();
        // dd($attendances);
            return View::make('parentpage.view_attendance')
		    ->with('title', 'Child Attendance')
		    ->with('page','Attendance')
		    ->with('students',$students)
		    ->with('attendances',$attendances);	

          }


	 }

	public function index(){

		$ParentRequest = Parents::find(Auth::user()->Parents->id)->ParentRequest()->get();
		//dd($ParentRequest);
		return View::make('parentpage.view_leave_list')
		->with('ParentRequests',$ParentRequest)
		->with('title','All Leave Request')
		->with('page','Manage Request');
	}
	
	public function getParBulletin(){

		$students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
		//dd($ParentRequest);
		return View::make('parentpage.view_classbulletin')
		->with('students',$students)
		->with('title','Class Bulletin')
		->with('page','Manage Bulletin');
	}
	public function getBulletinByStudent(){

     $student_id = Input::get('student_id');
     $student = Student::find($student_id);
     $ClassBulletins = ClassBulletin::where('classes_id',$student->classes_id)->get()->toJson();
	 //$stds = Student::where('section_id','=',$section_id)->get()->toJson();
	   return $ClassBulletins;

	}
	public function getParStuBulletin(){

		$students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
		//dd($ParentRequest);
		return View::make('parentpage.view_studentbulletin')
		->with('students',$students)
		->with('title','Student Bulletin')
		->with('page','Manage Bulletin');
	}
	public function getStuBulletinByStu(){

     $student_id = Input::get('student_id');
     $student = Student::find($student_id);
     $StudentBulletins = StudentBulletin::where('student_id',$student->id)->get()->toJson();
	return $StudentBulletins;

	}



	public function getRequest(){

		$students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
		return View::make('parentpage.make_request')
		->with('students', $students)
		->with('title','Create Request')
		->with('page','Manage Request');
	}
	
		
	
	public function getRequestStatus()
	{
		$SpecialRequest = Parents::find(Auth::user()->Parents->id)->SpecialRequest()->get();
		//dd($ParentRequest);
		return View::make('parentpage.special_request_list')
		->with('SpecialRequests',$SpecialRequest)
		->with('title','Request Status')
		->with('page','Manage Request');
	}

	public function postRequest()
	{
		$rules = array(
			'student_id'    => 'required',
			'title' 		=> 'required',
			'description'   => 'required',
			'date_range'	=> 'required'		
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) 
		{
			return Redirect::to('make-request')
			->withErrors($validator)
			->with('title','Create Request')
			->with('page','Manage Request')
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		} 
		else 
		{
			
			$student_id = Input::get('student_id');
			$student = Student::find($student_id);
			$teachers = Teacher::where('classes_id','=',$student->classes_id)->where('section_id','=',$student->section_id)->get();
			
			//dd("<pre>".$teacher."</pre>");
			if($teachers->count() > 0)
			{

				foreach($teachers as $teacher)
				{
					$ParentRequest = new ParentRequest;

					$ParentRequest->student_id    = $student_id;
					$ParentRequest->parents_id    = Auth::user()->Parents->id;
					$ParentRequest->teacher_id    = $teacher->id;
					$ParentRequest->title    = ucwords(strtolower(Input::get('title')));
					$ParentRequest->description   = Input::get('description');
					$ParentRequest->date_range    = Input::get('date_range');	
					$created_by = "";
					if(Auth::check())
					{
						if(Auth::user()->user_type=='3')
						{
							$created_by = "Parent";
						}
					}	
					$ParentRequest->created_by = $created_by;
					$ParentRequest->status = 3;
					$ParentRequest->save();

				}
				
				if(isset($ParentRequest->id) && $ParentRequest->id!='' )
				 {
					Session::flash('success', 'Leave Request successfully created');
					return Redirect::to('make-request')
					->with('title','Create Request')
					->with('page','Manage Request');
				 }			
				  else
				 {
				 	Session::flash('error', 'Oops ! something went wrong pls try again');
					return Redirect::to('make-request')
					->with('title','Create Request')
					->with('page','Manage Request');
				 }
			}
			else
			{
					$ParentRequest = new ParentRequest;

					$ParentRequest->student_id    = $student_id;
					$ParentRequest->parents_id    = Auth::user()->Parents->id;
					$ParentRequest->teacher_id    = 0;
					$ParentRequest->title    = ucwords(strtolower(Input::get('title')));
					$ParentRequest->description   = Input::get('description');
					$ParentRequest->date_range    = Input::get('date_range');	
					$created_by = "";
					if(Auth::check())
					{
						if(Auth::user()->user_type=='3')
						{
							$created_by = "Parent";
						}
					}	
					$ParentRequest->created_by = $created_by;
					$ParentRequest->status = 1;
					$ParentRequest->save();
					if(isset($ParentRequest->id) && $ParentRequest->id!='' )
					 {
						Session::flash('success', 'Leave Request successfully created');
						return Redirect::to('make-request')
						->with('title','Create Request')
						->with('page','Manage Request');
					 }			
					  else
					 {
					 	Session::flash('error', 'Oops ! something went wrong pls try again');
						return Redirect::to('make-request')
						->with('title','Create Request')
						->with('page','Manage Request');
					 }

			}	 
						
		}		
	}

	public function getSpecialRequest(){
		$students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
		return View::make('parentpage.special_request')
		->with('students', $students)
		->with('title','Special Request')
		->with('page','Manage Request');
	}
	//for post special request
	public function postSpecial()
	{
		$rules = array(
			'student_id'    => 'required',
			'title' 		=> 'required',
			'description'   => 'required'
					
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) 
		{
			return Redirect::to('special-request')
			->withErrors($validator)
			->with('title','Special Request')
			->with('page','Manage Request')
			->with('error','Oops ! Something went wrong pls try agian')
			->withInput();
		} 
		else 
		{
			$SpecialRequest = new SpecialRequest;
			
			$SpecialRequest->student_id    = Input::get('student_id');
			$SpecialRequest->parents_id    = Auth::user()->Parents->id;
			$SpecialRequest->title    = ucwords(strtolower(Input::get('title')));
			$SpecialRequest->description   = Input::get('description');
			
			$SpecialRequest->status = 0;
			$SpecialRequest->save();

			if(isset($SpecialRequest->id) && $SpecialRequest->id!='' )
			 {
				Session::flash('success', 'Special Request successfully created');
				return Redirect::to('special-request')
				->with('title','Special Request')
				->with('page','Manage Request');
			 }			
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('special-request')
				->with('title','Special Request')
				->with('page','Manage Request');
			 }
						
		}		
	}


	public function getParentAssignment(){

		$students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
		//dd($ParentRequest);
		return View::make('parentpage.view_assignment')
		->with('students',$students)
		->with('title','Parent Assignment')
		->with('page','Manage Parent');
	}
	public function getAssignmentBySection(){

		$student_id = Input::get('student_id');
		$type = Input::get('type');

   if($type > 0 && $student_id > 0){

     $student=Student::find($student_id);
    if($type == 1){
	 $assignments = Assignment::where('section_id','=',$student->section_id)->where('type', '=', 1)->where('publish_status', '=', 1)->orderBy('id','DESC')->get();
	}else{
     $assignments = Assignment::where('section_id','=',$student->section_id)->where('type', '=', 2)->where('publish_status', '=', 1)->orderBy('id','DESC')->get();
	} 
	 $name=array();

	

       foreach($assignments as $assignment){

         $data['assignment_name']=$assignment->name;
         $data['assignment_desc']=$assignment->description;
         $data['submission_date']=$assignment->date;
         $data['subject_name']=$assignment->SectionSubject->Subject->name;

         if($assignment->SectionSubject->ispractical == 1){

          $data['subject_type']='Practical';

         }elseif($assignment->SectionSubject->ispractical == 0){

         	 $data['subject_type']='Theory';

         }else{

             $data['subject_type']='';
         }

          $today=strtotime(date('d-m-Y'));
          $submission_date=strtotime($assignment->date);

          if($today > $submission_date) {
      
                $data['date']='<span class="label label-danger">Date expired<span>';

          }else{

                $data['date']='<span class="label label-success">Awaiting</span>';
           } 

       }

        $name[]= $data;
       
	  return Response::Json($name);

	 }else{
            $name="";
            return Response::Json($name);

	      } 
	}


public function getAssignment($sectionsub_id)
	{  
	     $sec_sub_id = SectionSubject::find($sectionsub_id);
	     $assignment = Assignment::where('section_subject_id','=',$sec_sub_id->id)->where('type', '=', 1)->where('publish_status', '=', 1)->orderBy('id','DESC')->get();
       
		return View::make('parentpage.listassignment')
		->with('title','Assignment')
		->with('page','Manage Assignment')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('assignments',$assignment);

	}

public function getTest($sectionsub_id)
	{  
	     $sec_sub_id = SectionSubject::find($sectionsub_id);
	     $assignment = Assignment::where('section_subject_id','=',$sec_sub_id->id)->where('type', '=', 2)->where('publish_status', '=', 1)->orderBy('id','DESC')->get();
       
		return View::make('parentpage.listtest')
		->with('title','Test')
		->with('page','Manage Assignment')
        ->with('sec_sub_id',$sec_sub_id)
        ->with('assignments',$assignment);

	}

	public function getStudentMarks($student,$exam){
    
     $AssignmentMarks = AssignmentMarks::where('student_id',$student)->where('assignment_id', $exam)->get();
	 return View::make('parentpage.student_assignment')
	 ->with('AssignmentMarks',$AssignmentMarks)
	 ->with('title','Parent Assignment')
	 ->with('page','Manage Parent');
    
	}


	public function getStudentClassWork(){
      $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
	 return View::make('parent.classwork.classwork')
	 ->with('students',$students)
	 ->with('title','View Classwork')
	 ->with('page','Class Updates');
    
	}

	public function getClassworkStudent(){

     $student_id = Input::get('student_id');
     if($student_id){
     $student = Student::find($student_id);
     $classwork = Classwork::where('section_id',$student->section_id)->where('type',1)->get();

     if($classwork->isEmpty()){

			 echo "<tr><td colspan='6' style='color:red;'>No classwork found</td></tr>";
	
	}else{
	        $i = 1;
	     	foreach($classwork as $classwork){
              echo "<tr><td>".$i."</td><td>".$classwork->created_at->format('d/m/Y')."</td><td>".$classwork->SectionSubject->Subject->name."</td><td>".$classwork->title."</td><td>".$classwork->User->Teacher->fname.' '.$classwork->User->Teacher->lname."</td><td><a href='#' name='classwork-btn' class='btn btn-primary classwork-btn' data-classwork_id='".$classwork->id."'>View</a></td></tr>";

                $i++;
	            } // for loop close

		}  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>Invalid Student Selection</td></tr>";

	}


	public function getClassworkDetails(){

     $classwork_id = Input::get('classwork_id');
     if($classwork_id){
     $classwork = Classwork::find($classwork_id);
    

     if($classwork->count() == 0){

			 echo "<tr><td>No classwork found</td></tr>";
	
	}else{
	     
	     	
   echo "<tr><th>Subject</th><td>".$classwork->SectionSubject->Subject->name."</td></tr><tr><th>Title</th><td>".$classwork->title."</td></tr><tr><th>Description</th><td>".$classwork->description."</td></tr>";

              
	           

		}  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>No data found</td></tr>";

	}


public function getStudentHomework(){
      $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
	 return View::make('parent.homework.homework')
	 ->with('students',$students)
	 ->with('title','View Homework')
	 ->with('page','Class Updates');
    
	}

	public function getHomeworkStudent(){

     $student_id = Input::get('student_id');
     if($student_id){
     $student = Student::find($student_id);
     $classwork = Classwork::where('section_id' , $student->section_id)->where('type', 2)->get();

     if($classwork->isEmpty()){

			 echo "<tr><td td colspan='6' style='color:red;'>No homework found</td></tr>";
	
	}else{
	        $i = 1;
	     	foreach($classwork as $classwork){
              echo "<tr><td>".$i."</td><td>".$classwork->created_at->format('d/m/Y')."</td><td>".$classwork->SectionSubject->Subject->name."</td><td>".$classwork->title."</td><td>".$classwork->User->Teacher->fname.' '.$classwork->User->Teacher->lname."</td><td><a href='#' name='classwork-btn' class='btn btn-primary classwork-btn' data-classwork_id='".$classwork->id."'>View</a></td></tr>";

                $i++;
	            } // for loop close

		}  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>Invalid Student Selection</td></tr>";

	}


	public function getHomeworkDetails(){

     $classwork_id = Input::get('classwork_id');
     if($classwork_id){
     $classwork = Classwork::find($classwork_id);
    

     if($classwork->count() == 0){

			 echo "<tr><td>No homework found</td></tr>";
	
	}else{
	     
	     	
   echo "<tr><th>Subject</th><td>".$classwork->SectionSubject->Subject->name."</td></tr><tr><th>Title</th><td>".$classwork->title."</td></tr><tr><th>Description</th><td>".$classwork->description."</td></tr>";

              
	           

		}  // else close

      }else
         echo "<tr><td colspan='5' style='color:red;'>No data found</td></tr>";

	}



	public function getParentsStudentClassWork($sec_sub_id){

     $classworks = Classwork::where('section_subject_id',$sec_sub_id)->where('type', 1)->get();
	 return View::make('parent.classwork')
	 ->with('classworks',$classworks)
	 ->with('title','Parent Classwork')
	 ->with('page','Manage Classwork');
     
	}

	public function getParentsStudentAnnouncement($sec_sub_id){

     $classworks = Classwork::where('section_subject_id',$sec_sub_id)->where('type', 2)->get();
	 //$stds = Student::where('section_id','=',$section_id)->get()->toJson();
	 return View::make('parentpage.announcement')
	 ->with('classworks',$classworks)
	 ->with('title','Parent Classwork')
	 ->with('page','Manage Classwork');
     
	}
	public function getStudentFees(){

     $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
	 return View::make('parentpage.student_fees')
	 ->with('students',$students)
	 ->with('title','Student Fees')
	 ->with('page','Manage Fees');
     
	}
	public function getFeesByStudent(){
	 $student_id = Input::get('student');	
     $fees = Fees::where('student_id', $student_id)->get();
	 //dd($fees);
	 return View::make('parentpage.students_fees')
	 ->with('fees',$fees)
	 ->with('title','Student Fees')
	 ->with('page','Manage Fees');;
    }
    public function getStudentFeesBill($student_id,$fees_id){
	
    	$student = Student::find($student_id);
    	$fees = Fees::find($fees_id);
    	$classfields = ClassField::where('classes_id',$student->classes_id)->get();
	 //dd($student);	
  	 //    $fees = Fees::where('student_id', $student_id)->get();
	 // //dd($fees);
	 return View::make('parentpage.fees_bill')
	 ->with('student',$student)
	 ->with('fees',$fees)
	 ->with('classfields',$classfields)
	 ->with('title','Student Fees Bill')
	 ->with('page','Manage Fees');;
    }
	
    public function getExamSchedule()
	{
	$students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();

	 return View::make('parentpage.exam_schedule')
	 ->with('students',$students)
	 ->with('title','Exam Schedule')
	 ->with('page','Manage Exam');
	}
	
	public function postExamSchedule(){

        $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
        $student_id = Input::get('student_id');
		$student = Student::find($student_id);
		$exam_list=Exam::where('classes_id','=',$student->classes_id)->get();
		//dd($student->id);
		      return View::make('parentpage.exam_schedule')
		     ->with('exam_list',$exam_list)
		     ->with('student_selected',$student)
		     ->with('students',$students)
		     ->with('page','Manage Exam')
		     ->with('title','Exam Schedule');

       
    }


	public function getStudentExamSchedule($exam_id)
	{

		//$teachers=Teacher::find(Auth::user()->Teacher->id);
		$examschedule_details=ExamSchedule::where('exam_id','=',$exam_id)->get();
		$exam_name=Exam::find($exam_id);
		
		return View::make('parentpage.viewschedule')
		->with('exams_schedule', $examschedule_details)
		->with('exam_name',$exam_name)
		->with('page','Manage Exam')
		->with('title', 'Exam Schedule');
		
	}
	
	public function getExamResult()
	 {
	  $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
	          
	  return View::make('parentpage.listresult')
	  ->with('students',$students)
	  ->with('title', 'Exam Result')
	  ->with('page','Manage Exam');
	 }

	 public function postExamResult(){
     
       $exam_id1 = Input::get('exam_id');
       //dd($exam_id);
       //$classes_id = Input::get('classes_id');
       $student_id = Input::get('student_id'); 
       $exam_all=ExamMarks::where('student_id','=',$student_id)->orderBy('exam_schedule_id')->get(); 
        
       $final_result = array();
       if($exam_all){
         foreach($exam_all as $result){

           //dd($result->Exam->name);
          if(!isset($final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id])){
           $final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id] = 0;
          }
          $final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id]+= $result->marks;

         }

		foreach($final_result as $key=>$value){

		foreach($value  as $key1=>$value1)
		$final_result[$key][$key1]['total']=array_sum($value1);

		}


       }


	  foreach($final_result as $exam_id => $val1)
	        {
              //echo $exam_id.' <br />';
          

                foreach($val1 as $index2 => $val2)
                {
                       //echo $index2.' - Total: ' . $val2['total'] . ' <br />';
 
                        foreach($val2 as $index3 => $val3)
                        {
                                if ( is_numeric($index3) )
                                {
                                    // echo $index3.' - ' . $val3 . ' <br />';
                                }
                        }
                }
 
                //echo ' <br />';
        }

       //die();
       $exam_marks=ExamMarks::where('exam_id','=',$exam_id1)->where('student_id','=',$student_id)->get();
      
             
       $rows=array();
       $rows=DB::table('exam_marks')
            ->join('result_format', 'exam_marks.section_subject_id', '=', 'result_format.section_subject_id')
            ->join('section_subjects', 'exam_marks.section_subject_id', '=', 'section_subjects.id')
            ->join('exam_schedules','exam_marks.exam_schedule_id','=','exam_schedules.id')
            ->join('subjects','exam_marks.subject_id','=','subjects.id')
            ->where('exam_marks.exam_id','=',$exam_id1)
            ->where('exam_marks.student_id','=',$student_id)
            ->orderBy('result_format.result_format_status','asc')
            ->select('subjects.name','result_format.result_format_status','section_subjects.ispractical','exam_marks.marks','exam_schedules.total_marks')
            ->get();
            // echo "<pre>";
            //dd($rows);

           
            //print_r($rows);
          // die();

		$uniques = array();
		foreach ($rows as $row) {
		    $uniques[] = $row['name'];
		}
		 //echo "<pre>";        
		//dd($uniques);
       $studentname=Student::find($student_id);
       $students = Student::where('parent_id','=',Auth::user()->Parents->id)->get();
       $classes = Classes::all();
       //foreach($rows as $row){$array[]=$row;}
       if(sizeOf($rows) == 0)
       {

        return View::make('parentpage.examresult')
	    ->with('classes', $classes)
	    ->with('studentname', $studentname)
	    ->with('students', $students)
	    ->with('exam_marks',$exam_marks)
	    ->with('title', 'Exam Result')
	  	->with('page','Manage Result');
       }
       else{

     $final=array();
       $exam_name=Exam::find($exam_id1)->name;
       //dd($exam_name);
	//echo "<pre>";
	//dd($array);
	$subject_name=array_unique($uniques);
	//echo "<pre>";
	//dd($subject_name);
    return View::make('parentpage.examresult')
    ->with('classes', $classes)
    ->with('studentname', $studentname)
    ->with('students', $students)
       ->with('exam_all',$exam_all)
       ->with('exam_marks',$exam_marks)
       ->with('rows',$rows)
       ->with('final_result',$final_result)
       ->with('exam_name', $exam_name)
       ->with('subject_names',$subject_name)
    ->with('title', 'Exam Result')
    ->with('page','Manage Exam');
       }
   }
   public function getParentGallery()
	{
		$photos = Photo::all();
		return View::make('parentpage.viewgallery')
		->with('photos',$photos)
		->with('title','All Gallery')
		->with('page','Manage Gallery');
	}

	public function getParentImage($photo_id)
	{
		
		$galleries = Galleries::where('photo_id',$photo_id)->get();
		return View::make('parentpage.viewimages')
		->with('photos',$galleries)
		->with('title','All Gallery')
		->with('page','Manage Gallery');
	}
	
	public function PostParentImage()
	{
		
		$images = Input::get('image');
		// echo('<pre>');
		// print_r($images);
		// echo('</pre>');
		// die();
		if($images)
		{
			foreach($images as $image)
			{
				$galleries = Galleries::find($image);
				$printing = new Printing;
				//dd($images->id);
				$printing->galleries_id = $galleries->id;
				$printing->code = $galleries->code;
				$printing->parent_id = Auth::user()->Parents->id;

				$printing->save();
			}
			return Redirect::back()
			->with('success', 'Successfully Request Sent For Printing !');
		}
		else
		{
			return Redirect::back()
			->with('error', 'Please Select Image to Send Request!');
		}

	}
	

	


}