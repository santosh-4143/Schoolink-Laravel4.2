<?php

class PasswordController extends \BaseController {
 
  public function remind()
  {
    return View::make('password.remind')
    ->with('title','Change Password')
    ->with('page','Manage User');
  }

public function request()
{
    $credentials = array('email' => Input::get('email'), 'password' => Input::get('password'));
    Password::remind($credentials);

   Session::flash('success', 'Please verify the link sent to your inbox!');
  return Redirect::to('password/reset');
}


public function reset($token)
{
  return View::make('password.reset')->with('token', $token);
}

public function update()
{
  $credentials = array('email' => Input::get('email'));
 
  return Password::reset($credentials, function($user, $password)
  {
    $user->password = Hash::make($password);
 
    $user->save();
    
    Session::flash('success', 'Your password has been reset!');
    return Redirect::to('/');
  });
}

public function getChangePassword()
  {
    return View::make('password.change')
    ->with('title','Change Password')
    ->with('page','Manage User');
  }


public function postChangePassword()
  {


      $rules = array(
      
      'old_password'  => 'required',
      'password'  => 'required',
      'password_confirm'=> 'required|same:password'
    );
    $validator = Validator::make(Input::all(), $rules);
    if ($validator->fails()) {
      return Redirect::back()
      ->withErrors($validator);

        
  }else{
      $oldPassword = Input::get('old_password');
      $newPassword = Input::get('password');
      $dbPassword = User::find(Auth::user()->id)->password;

      if(Hash::check($oldPassword,$dbPassword)){

       $user =User::find(Auth::user()->id);
       $user->password = Hash::make($newPassword);
       $user->save();

       Session::flash('success', 'Your password has been changed successfully!');
       return Redirect::back();
     }

     Session::flash('error', 'Password mismatch!Please try again');
     return Redirect::back();

   } // else part
     
  }


} // class close


?>