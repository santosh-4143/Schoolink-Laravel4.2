<?php

class ExamController extends \BaseController {

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index()
  {
    $classes = Classes::all();
    return View::make('exams.listclass')
    ->with('classes', $classes)
    ->with('title', 'Create Exams')
    ->with('page','Manage Exams');
  }

    public function getResultFormat()
  {
    $classes = Classes::all();
    return View::make('exams.resultformat')
    ->with('classes', $classes)
    ->with('title', 'Result Format')
    ->with('page','Manage Exams');
  }


  public function get_section_subjects_result(){
     $classes_id = Input::get('classes_id');
    // $exam_id=Input::get('exam_id');
     $result_format_details=ResultFormat::where('classes_id','=',$classes_id)->orderBy('result_format_status','asc')->get();
     $name=array();
     //$subjects_name[]=$exam_mark_details->SectionSubject->id;
   
         
     $sections=Section::where('classes_id','=',$classes_id)->get();
     foreach($sections as $section){

      $section_id=$section->id;
     }
     
   $section_subjects = SectionSubject::where('section_id','=',$section_id)->get();
   

  foreach($section_subjects as $section_subject){
      
       
        //$data=array();
        //$query=DB::table('section_subjects')->where('subject_id','=', $section_subject->subject_id)->where('section_id','=',$section_id)->get();
        $data['name'] =$section_subject->Subject->name;
        $data['subject_id'] =$section_subject->Subject->id;
        $data['id'] = $section_subject->id;
        $data['ispractical'] = $section_subject->ispractical;
      
        $name[]= $data;

       // $id[]=("hello");
  }

if($result_format_details->count() > 0){
foreach($result_format_details as $result_format_detail){

      $subjects[]= $result_format_detail->SectionSubject->Subject->name;
    
    }

  $unique_subjects=array_unique($subjects);
  $counter=0;
   foreach($unique_subjects as $unique_subject){
     $temp[$counter]=$unique_subject;
     $counter++;
   }
    $output[]=$temp;
  $name[]=$output;
  }else{
     $output=0;
     $name[]=$output;

  } 
   
  //dd(Response::Json($name));
  return Response::Json($name); 
  
    //return $query;
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create($classes_id)
  {
    $exam_list=Exam::where('classes_id','=',$classes_id)->get();

    //dd($exam_list);
    return View::make('exams.create')
    ->with('classes_id', $classes_id)
    ->with('exams', $exam_list)
    ->with('title', 'Create Exams')
    ->with('page','Manage Exams');
    
  }


  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store()
  {
    $rules = array(
      'name'  => 'required',
      'date'  => 'required'
      
    );
    //dd($rules);
    $validator = Validator::make(Input::all(), $rules);
     
    // process the login
    if ($validator->fails()) {
      return Redirect::to('exam-create/'.Input::get('classes_id'))
      ->withErrors($validator)
      ->with('title','Create Exams')
      ->with('page','Manage Exams')
      ->withInput();
        
    } 
    else 
    {
           // store
      $exams = new Exam;
      $exams->name       = Input::get('name');
      $exams->classes_id = Input::get('classes_id');    
      $exams->date      = Input::get('date');
      $exams->save();

      // redirect
      Session::flash('success', 'Successfully created exam!');
      return Redirect::to('exam-create/'.Input::get('classes_id'))
      ->with('title','Create Exams')
      ->with('page','Manage Exams');
      }
     }


  public function getschedule($exam_id)
  {
       $exam_details=Exam::find($exam_id);
       $sections=Section::where('classes_id','=',$exam_details->classes_id)->get();
      
       foreach($sections as $section){
             
             $section_id[]=$section->id;
             //$section_subjects=SectionSubject::where('section_id','=',$section_id)->get();
             //$num[]=$section_subjects->count();
       }
       
       //dd($section_id[0]);
          $section_subjects=SectionSubject::where('section_id','=',$section_id[0])->get();
          foreach( $section_subjects as  $section_subject){

            if($section_subject->ispractical == 1)
              { $data='Practical'; }
            elseif($section_subject->ispractical == 0)
              { $data='Theory';}  
            else
              { $data='';}
            
              $names[]=$section_subject;
            
            $subject_data=$names;
          }
          //dd($section_subjects->isEmpty());
      if($section_subjects->isEmpty()){
        //dd($section_subjects);    
      return View::make('exams.createschedule')
      ->with('title','Create Exams')
      ->with('page','Manage Exams')
      ->with('names1',$section_subjects);
      }
     else{

      return View::make('exams.createschedule')
      ->with('title','Create Exams')
      ->with('page','Manage Exams')
      ->with('names2',$names)
      ->with('exam_id',$exam_id);
    }

  }

 

 public function postschedule()
  {

      $size = Input::get('size');
      $exam_id=Input::get('exam_id');
      $date=Input::get('date');
      $subject_name=Input::get('subject');
      $from=Input::get('time_from');
      $to=Input::get('time_to');
      $facility=Input::get('facility');
      $marks=Input::get('marks');
      
      $rules= array(
          

        );
       
    
    //dd($rules);
    $validator = Validator::make(Input::all(),$rules);
     
    /// process the login
    if ($validator->fails()) {
      return Redirect::to('exam-schedule/'.$exam_id)
      ->withErrors($validator)
      ->with('title','Create Exams')
      ->with('page','Manage Exams');
        //->withInput();        
    } 
    else 
    {
           // store
      
      for($i=0;$i<=$size;$i++){

            $exams = new ExamSchedule;
            //$parts = explode(" ", $subject_name[$i]);
             
             //dd($parts[1]);
        
      $exams->exam_id            = $exam_id;
      $exams->section_subject_id = $subject_name[$i];
      $exams->total_marks        = $marks[$i];    
      $exams->date               = $date[$i];
      $exams->from               = $from[$i];
      $exams->to                 = $to[$i];
      $exams->facility           = $facility[$i];
      $exams->save();

    }
            $update_exams=Exam::find($exam_id);
            $update_exams->status = 1;
            $update_exams->save();

      $classes_id=SectionSubject::find($exams->section_subject_id)->Classes->id;
      //dd($classes_id);  
      $students=Student::where('classes_id','=',$classes_id)->get();
        //dd($exam_id);

      $exam_schedule= ExamSchedule::where('exam_id','=',$exam_id)->get()->toArray();

      foreach($students as $student){

        $parents=Parents::find($student->parent_id);  
        
        $data= array('examschedules' => $exam_schedule,'student_id' => $student->id,'classes_id' => $classes_id,'exam_id' =>$exam_id);
        //dd($data);
        Mail::send('emails.examschedule',$data,function($message) use ($parents)
        {
           
        $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Exam Schedule');
         
        });



        }
          


      // redirect
      Session::flash('success', 'Successfully created exam!');
      return Redirect::to('exam-schedule/'.$exam_id)
      ->with('title','Create Exams')
      ->with('page','Manage Exams');
      }

       
    }
      
           
  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function getScheduledetails($exam_id)
  {
    $examschedule_details=ExamSchedule::where('exam_id','=',$exam_id)->get();
    
    
    return View::make('exams.viewschedule')
    ->with('exams_schedule', $examschedule_details)
    ->with('title', 'Create Exams')
    ->with('page','Manage Exams');
  }

    public function getExamStudent($exam_schedule_id,$exam_id,$subject_id)
  {
    $examschedule=Exam::find($exam_id)->ExamSchedule;
    $classes=Exam::find($exam_id)->Classes;
        $sections=Section::where('classes_id','=',$classes->id)->get();
    $total_marks=ExamSchedule::find($exam_schedule_id);
    //dd($total_marks);
        $exam_marks=ExamMarks::where('exam_schedule_id','=',$exam_schedule_id)->get();
     //dd("<pre>".$exam_marks."</pre>");
    
    return View::make('exams.studentexam_marks')
    ->with('title', 'Create Exams')
    ->with('page','Manage Exams')
    ->with('sections',$sections)
    ->with('exam_schedule_id',$exam_schedule_id)
    ->with('exam_id',$exam_id)
    ->with('subject_id',$subject_id)
    ->with('total_marks',$total_marks)
    ->with('exam_marks',$exam_marks);
  }

  public function postExamMarks()
  {
    $marks = Input::get('marks'); 
    $subject_id = Input::get('subject_id');
    $exam_id= Input::get('exam_id'); 
    $student_id = Input::get('student_id'); 
    $section_id = Input::get('section_id'); 
        $exam_schedule_id=Input::get('exam_schedule_id'); 
    $size=sizeOf($student_id);
    $classes=Exam::find($exam_id)->Classes;
        $sections=Section::where('classes_id','=',$classes->id)->get();
        $exam_marks=ExamMarks::where('exam_schedule_id','=',$exam_schedule_id)->get();
        $status_update=ExamSchedule::find($exam_schedule_id);
       
      
        
        if(sizeOf($exam_marks) > 0){
          
         $exam_marks_id= Input::get('exam_marks_id'); 
        for($i=0;$i<sizeOf($exam_marks);$i++){
            
           $exam_marks_update=ExamMarks::find($exam_marks_id[$i]); 
           $exam_marks_update->marks=$marks[$i];
           //$exam_marks_update->section_subject_id=$status_update->SectionSubject->id;
           $exam_marks_update->save();

         }//for loop for update


        } // if part
        else{
       

    for($i=0;$i<$size;$i++){
              
           $exam_marks= new ExamMarks;
           $exam_marks->exam_id= $exam_id ; 
           $exam_marks->exam_schedule_id=$exam_schedule_id;
           $exam_marks->subject_id=$subject_id;
           $exam_marks->section_id=$section_id[$i];
           $exam_marks->student_id=$student_id[$i];
           $exam_marks->section_subject_id=$status_update->SectionSubject->id;
           $exam_marks->marks=$marks[$i]; 
           $exam_marks->save();
           $status_update->status = 1;
           $status_update->save();

      }
    }//else part
    // redirect
    Session::flash('success', 'Successfully marked Exam!');
    return Redirect::to('exam-marks/'.$exam_schedule_id.$exam_id.$subject_id)
    ->with('title', 'Create Exams')
    ->with('page','Manage Exams');
  }


  public function getPublishResult($exam_id,$classes_id){

      $exam=Exam::find($exam_id);
      $exam->result_publish=1;
      $exam->save();

      $students=Student::where('classes_id','=',$classes_id)->get();

       foreach($students as $student){

       $rows=array();
       $subject_type=array();
       $student_marks=array();
       $total_marks=array();
       $rows =DB::table('exam_marks')
            ->join('result_format', 'exam_marks.section_subject_id', '=', 'result_format.section_subject_id')
            ->join('section_subjects', 'exam_marks.section_subject_id', '=', 'section_subjects.id')
            ->join('exam_schedules','exam_marks.exam_schedule_id','=','exam_schedules.id')
            ->join('subjects','exam_marks.subject_id','=','subjects.id')
            ->where('exam_marks.exam_id','=',$exam_id)
            ->where('exam_marks.student_id','=',$student->id)
            ->orderBy('result_format.result_format_status','asc')
            ->select('subjects.id','result_format.result_format_status','section_subjects.ispractical','exam_marks.marks','exam_schedules.total_marks','section_subjects.classes_id') 
            ->get();

      foreach ($rows as $row) {
         $unique_subjects[] = $row['id'];
         $classes_id = $row['classes_id'];
         $subject_type[] = $row['ispractical'];
         $student_marks[] = $row['marks'];
         $total_marks[] = $row['total_marks'];
      }
       $final_subjects=array_unique($unique_subjects);

       $rows['subjects']=$final_subjects;
       $rows['type']=$subject_type;
       $rows['marks']=$student_marks;
       $rows['total']=$total_marks;

        $parents=Parents::find($student->parent_id);  
        
        $data= array('rows' => $rows,'student_id' => $student->id,'classes_id' => $classes_id,'exam_id' =>$exam_id);
      
        Mail::send('emails.result',$data,function($message) use ($parents)
        {
           
        $message->to($parents->email,$parents->fname.' '.$parents->lname)->subject('Exam Result');
         
        });

      

      }


      return Redirect::to('exam-create/'.$classes_id)
      ->with('title','Create Exams')
      ->with('page','Manage Exams');

  }


   public function getExamResult()
  {
    $classes = Classes::all();
    return View::make('exams.listresult')
    ->with('classes', $classes)
    ->with('title', 'Create Exams')
    ->with('page','Manage Exams');
  }

  public function get_ajax_exam()
  {
      $classes_id = Input::get('classes_id');
    $exams = Exam::where('classes_id','=',$classes_id)->get();
    //$students = Student::where('classes_id','=',$classes_id)->get();
      $name=array();
    
       
         foreach($exams as $exam){
         
         $data['exam']=$exam;

         $name[]=$data;
        
        }
      return Response::json($name);
  }


   public function get_ajax_class_students(){
     $classes_id = Input::get('classes_id');
     $students = Student::where('classes_id','=',$classes_id)->get();
     $name=array();

         foreach($students as $student){
         
         $data['student']=$student;

         $name[]=$data;
        
        }
      return Response::json($name);
  }

 // public function getResultMarks(){
     
      // $exam_id = Input::get('exam_id');
       //$classes_id = Input::get('classes_id');
      // $student_id = Input::get('student_id'); 
      // $exam_all=ExamMarks::where('student_id','=',$student_id)->orderBy('exam_schedule_id')->get(); 
        
      // $final_result = array();
       //if($exam_all){
          //foreach($exam_all as $result){

              //dd($result->Exam->name);
            //if(!isset($final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id])){
             // $final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id] = 0;
            //}
            //$final_result[$result->exam_id][$result->subject_id][$result->exam_schedule_id]+= $result->marks;

         // }

///foreach($final_result as $key=>$value){

//foreach($value  as $key1=>$value1)
//$final_result[$key][$key1]['total']=array_sum($value1);

//}


      // }

  /*foreach($final_result as $exam_id => $val1)
        {
              //echo $exam_id.' <br />';
          

                foreach($val1 as $index2 => $val2)
                {
                       //echo $index2.' - Total: ' . $val2['total'] . ' <br />';
 
                        foreach($val2 as $index3 => $val3)
                        {
                                if ( is_numeric($index3) )
                                {
                                    // echo $index3.' - ' . $val3 . ' <br />';
                                }
                        }
                }
 
               
        }

      
       $exam_marks=ExamMarks::where('exam_id','=',$exam_id)->where('student_id','=',$student_id)->get();
       $result_status=Exam::find($exam_id)->result_publish;
             
      
       $rows=array();
       $rows=DB::table('exam_marks')
            ->join('result_format', 'exam_marks.section_subject_id', '=', 'result_format.section_subject_id')
            ->join('section_subjects', 'exam_marks.section_subject_id', '=', 'section_subjects.id')
            ->join('exam_schedules','exam_marks.exam_schedule_id','=','exam_schedules.id')
            ->join('subjects','exam_marks.subject_id','=','subjects.id')
            ->where('exam_marks.exam_id','=',$exam_id)
            ->where('exam_marks.student_id','=',$student_id)
            ->orderBy('result_format.result_format_status','asc')
            ->select('subjects.name','result_format.result_format_status','section_subjects.ispractical','exam_marks.marks','exam_schedules.total_marks')
            ->get();
           

$uniques = array();
foreach ($rows as $row) {
    $uniques[] = $row['name'];
}
 
       $student=Student::find($student_id);
       $classes = Classes::all();
      
       if(sizeOf($rows) == 0)
       {
        
        return View::make('exams.listresult')
        ->with('classes', $classes)
        ->with('student', $student)
        ->with('result_status',$result_status)
        ->with('rows', $rows)
        ->with('exam_marks',$exam_marks)
        ->with('title','Create Exams')
        ->with('page','Manage Exams');



       }
       else{

       //$exam_id = Input::get('exam_id');
       //dd($exam_id);
       $final=array();
       $exam_name=Exam::find($exam_id)->name;
       $subject_name=array_unique($uniques);

     return View::make('exams.listresult')
       ->with('classes', $classes)
       ->with('student', $student)
       ->with('exam_all',$exam_all)
       ->with('exam_marks',$exam_marks)
       ->with('rows',$rows)
       ->with('result_status',$result_status)
       ->with('final_result',$final_result)
       ->with('exam_name', $exam_name)
       ->with('subject_names',$subject_name)
       ->with('title','Create Exams')
       ->with('page','Manage Exams');
       }*/
   // }

 public function getResultMarks(){
       $classes = Classes::all();
       $exam_id = Input::get('exam_id');
       $classes_id = Input::get('classes_id');
       $student_id = Input::get('student_id'); 
       $exam_marks=ExamMarks::where('exam_id','=',$exam_id)->where('student_id','=',$student_id)->get();
       $exam_details=Exam::find($exam_id);
       $student=Student::find($student_id);
       //$exam_name=Exam::find($exam_id)->name;
      //dd( $exam_marks);
       $rows=array();
       $rows =DB::table('exam_marks')
            ->join('result_format', 'exam_marks.section_subject_id', '=', 'result_format.section_subject_id')
            ->join('section_subjects', 'exam_marks.section_subject_id', '=', 'section_subjects.id')
            ->join('exam_schedules','exam_marks.exam_schedule_id','=','exam_schedules.id')
            ->join('subjects','exam_marks.subject_id','=','subjects.id')
            ->where('exam_marks.exam_id','=',$exam_id)
            ->where('exam_marks.student_id','=',$student_id)
            ->orderBy('result_format.result_format_status','asc')
            ->select('subjects.id','result_format.result_format_status','section_subjects.ispractical','exam_marks.marks','exam_schedules.total_marks','section_subjects.classes_id') 
            ->get();
       
        //$unique_subjects = array();
       foreach ($rows as $row) {
         $unique_subjects[] = $row['id'];
         $classes_id = $row['classes_id'];
         $subject_type[] = $row['ispractical'];
         $student_marks[] = $row['marks'];
         $total_marks[] = $row['total_marks'];
      }
       $final_subjects=array_unique($unique_subjects);

       $rows['subjects']=$final_subjects;
       $rows['type']=$subject_type;
       $rows['marks']=$student_marks;
       $rows['total']=$total_marks;

     if(sizeOf($rows) == 0)
       {
         return View::make('exams.listresult')
        ->with('classes', $classes)
        ->with('title','Create Exams')
        ->with('page','Manage Exams');


       }
   else{  

       return View::make('exams.listresult')
       ->with('rows', $rows)
       ->with('classes', $classes)
       ->with('student', $student)
       ->with('exam_details',$exam_details)
       ->with('exam_marks',$exam_marks)
       ->with('title','Create Exams')
       ->with('page','Manage Exams');
       }
   }













public function postResultFormat()
  {
    $classes_id = Input::get('classes_id'); 
    $classes=Classes::all();
    $section_subject_id =Input::get('section_subject_id') ;
    $counter=1;
    for($i=0;$i < sizeOf($section_subject_id);$i++){
    
        $result_format_details=ResultFormat::where('classes_id','=',$classes_id)->where('section_subject_id','=',$section_subject_id[$i])->get();
         
         if($result_format_details->count() > 0){
        
           foreach($result_format_details as $result_format_detail){
            $result_format_update=ResultFormat::find($result_format_detail->id);
            $result_format_update->result_format_status=$counter;
            $result_format_update->save();
            }
           Session::flash('success', 'Successfully updated Result Format!');
          }
           else{

            $result_format=new ResultFormat;
      $result_format->classes_id=$classes_id;
      $result_format->section_subject_id=$section_subject_id[$i];
      $result_format->result_format_status=$counter;
      $result_format->save();

           Session::flash('success', 'Successfully created Result Format!');
           }



           $counter++;
       }// first for loop
         
        //dd("<pre>".$result_format_details->count()."</pre>");
       
        
        

        
        
    
      return View::make('exams.resultformat')
    ->with('classes', $classes)
    ->with('title', 'Result Format')
    ->with('page','Manage Exams');
  }







  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
    //
  }


  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id)
  {
    //
  }


  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    //
  }


}
