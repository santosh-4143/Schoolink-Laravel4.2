<?php

class InfoController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$info=Info::all();
		//dd("<pre>".$grades->count()."</pre>");
		return View::make('info.createinfo')
		->with('title','Create Info')
		->with('page','Manage Info')
		->with('infos',$info);	
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		
		$rules = array(
			'school_name' => 'required',
			'email'  	  => 'required',
			'address'     => 'required',
			'phone'       => 'required'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('grades')
			->withErrors($validator)
			->with('title','Create Info')
			->with('page','Manage Info')
			->withInput();
				
		} 
		else 
		{
			// store
			$info = new Info;
			$info->school_name  = Input::get('school_name');
			$info->email   = Input::get('email');
			$info->address   = Input::get('address');	
			$info->phone   = Input::get('phone');
			if(Input::hasFile('logo'))
			  	{
				    $file = Input::file('logo');
					$destinationPath = 'uploads/img';
					$filename = $file->getClientOriginalName();
					Input::file('logo')->move($destinationPath, $filename);
					$info->logo      = $filename;

		        }			
			//dd($file);
			$info->save();

			// redirect
			Session::flash('success', 'Successfully Created Info!');
			return Redirect::to('info')
			->with('title','Create Info')
			->with('page','Manage Info');
		}
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function getEdit($id)
	{
		$info=Info::find($id);
		return View::make('info.editinfo')
		->with('title','Create Info')
		->with('page','Manage Info')
		->with('info',$info);	
	}

	public function postEdit()
	{
		$rules = array(
			'school_name' => 'required',
			'email'  	  => 'required',
			'address'     => 'required',
			'phone'       => 'required'
			
		);

        $info_id=Input::get('info_id');
		$info=Info::find($info_id);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('info_edit/'.$info->id)
			->withErrors($validator)
			->with('title','Create Info')
			->with('page','Manage Info')
			->withInput();
				
		} 
		else 
		{
			// store
			//dd($info);
		    $info->school_name  = Input::get('school_name');
			$info->email   = Input::get('email');
			$info->address   = Input::get('address');	
			$info->phone   = Input::get('phone');
			if(Input::hasFile('logo'))
			  	{
				    $file = Input::file('logo');
					$destinationPath = 'uploads/img';
					$filename = $file->getClientOriginalName();
					Input::file('logo')->move($destinationPath, $filename);
					$info->logo      = $filename;

		        }			
			//dd($file);
			$info->save();

			// redirect
			Session::flash('success', 'Successfully Updated Info!');
			return Redirect::to('info_edit/'.$info->id)
			->with('title','Create Info')
			->with('page','Manage Info');
		}
	}

	
           public function postDelete()
            	{

                    $info_id=Input::get('info_id');
		            $info=Info::find($info_id);
		            $info->delete();
		            return Redirect::to('info')
			        ->with('title','Create Info')
			        ->with('page','Manage Info');

             	}  

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
