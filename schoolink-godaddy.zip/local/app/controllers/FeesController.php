<?php

class FeesController extends BaseController
{


	public function getClassFees()
	{	
		$ClassField = ClassField::select('classes_id')->groupBy('classes_id')->get();
		//dd('<pre>'.$ClassField.'<pre>');
		$classes = Classes::all();
		 return View::make('fees.create_fees')
		->with('title', 'Create Fees')
		->with('page','Manage Fees')
		->with('classes', $classes)
		->with('ClassFields', $ClassField);
	}

	public function postClassFees()
	{
		$classes_id = Input::get('classes_id');

		$rules = array(
			'flabel'      	 => 'required',
			'fvalue'		 => 'required'
			
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			if(Request::ajax()){
						$data = array();
						$data['status']=false;
						return Response::json($data);
		  }
			return Redirect::to('get-class-fees')
			->withErrors($validator)
			->withInput();
				
		} 
		else 
		{
			// store
			$ClassField = new ClassField;
			$ClassField->classes_id       	= $classes_id;
			$ClassField->flabel       		= ucwords(strtolower(Input::get('flabel')));
			$ClassField->fvalue   			= Input::get('fvalue');		
			
			$ClassField->save();

			if(Request::ajax()){
						$data = array();
						$data['status']=true;
						$data['class']=$ClassField->Classes->name;
						return Response::json($data);
			
		  }

			// redirect
			Session::flash('success', 'Successfully Created Class Fees!');
			return Redirect::to('get-class-fees');
		}
	}
	public function editClassField($classes_id)
	{	
		$ClassField = ClassField::where('classes_id', $classes_id)->get();
		//dd('<pre>'.$ClassField.'<pre>');
		$classes = Classes::all();
		 return View::make('fees.edit_fees')
		->with('title', 'Edit Fees')
		->with('page','Manage Fees')
		->with('classes', $classes)
		->with('ClassFields', $ClassField);
	}
	public function editPostFees()
	{
		$classes_id = Input::get('classes_id');
		$field1 = Input::get('field1');
		$field2 = Input::get('field2');
		$id = Input::get('id');
		$size = Input::get('size');
		
			for($i=0;$i<$size;$i++)
			{
			$ClassField = ClassField::find($id[$i]);
			$ClassField->classes_id       	= $classes_id;
			$ClassField->flabel       		= ucwords(strtolower($field1[$i]));
			$ClassField->fvalue   			= $field2[$i];		
			$ClassField->save();
			}

			
			Session::flash('success', 'Successfully Upadtes Class Fees!');
			return Redirect::to('edit-classfield/'.$classes_id);
			
	}
	public function getAddFees()
	{
		$classes = Classes::all();
		 return View::make('fees.add_fees')
		->with('title', 'Add Fees')
		->with('page','Manage Fees')
		->with('classes', $classes);
	}
	public function getFeesFields()
	{
		$classes_id = Input::get('classes_id');
		$ClassField = ClassField::where('classes_id','=',$classes_id)->get()->toJson();
	  	dd($ClassField);
	}
	public function addClassFees($classes_id)
	{
		
		$Sections = Section::where('classes_id','=',$classes_id)->get();
		$ClassField = ClassField::where('classes_id','=',$classes_id)->get();
		return View::make('fees.xyz')
		->with('title', 'Add Fees')
		->with('page','Manage Fees')
		->with('ClassFields', $ClassField)
		->with(compact('classes_id'))
		->with('sections', $Sections);
	}
	public function postFees()
	{
		$classes_id = Input::get('classes_id');
		//dd($classes_id);

		$rules = array(
			'student_id'      	 => 'required',
			'date'  			 => 'required',
			
				
		);
		$validator = Validator::make(Input::all(), $rules);
		if ($validator->fails())
		 {
			return Redirect::to('add-class-fees/'.$classes_id)
			->withErrors($validator);
		 } 
		else 
		  {
			// store
			$Fees = new Fees;
			$Fees->student_id       = Input::get('student_id');
			$Fees->date       		= Input::get('date');
			$Fees->fine   			= Input::get('fine');
			$Fees->total   			= Input::get('total');		
			$Fees->save();

			if(isset($Fees->id) && $Fees->id!='' )
			 {
				Session::flash('success', 'Student Fees successfully Added');
				return Redirect::to('add-class-fees/'.$classes_id);
			 }			
			  else
			 {
			 	Session::flash('error', 'Oops ! something went wrong pls try again');
				return Redirect::to('add-class-fees/'.$classes_id);
			 }
		  }	
	}

	public function checkFees()
	{
		$classes_id = Input::get('classes_id');
		$ClassFields = ClassField::where('classes_id','=',$classes_id)->get()->toJson();
		//return $Fees;
		
	  return $ClassFields; 
	}
}