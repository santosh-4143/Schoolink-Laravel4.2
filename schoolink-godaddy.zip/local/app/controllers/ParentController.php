<?php

class ParentController extends \BaseController {

	
	public function index()
	{
		$data = Parents::all();
		return View::make('parent.profile.index')
		->with('parents', $data)
		->with('classes', Classes::all())
		->with('title','All Parents')
		->with('page','Manage Parents');
	}


	public function create()
	{
		return View::make('parent.profile.create')
		->with('title','Create Parent')
		->with('page','Manage Parents');
	}


	public function store()
	{
		//dd(Input::all());
		$rules = array(
			'code'       => 'required|unique:parents',
			'fname'  	 => 'required|alpha|min:3',
			'email'  	 => 'required|email|unique:users|unique:parents',
			'address'  	 => 'required|min:3',
			'password'   => 'required',
			'phone_1'  	 => 'required|min:10'
		);
		$validator = Validator::make(Input::all(), $rules);


		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();
				
		} 
		else 
		{
			// store in Users Table
			$User =new User;
			$User->fname   = ucwords(strtolower(Input::get('fname')))." ".ucwords(strtolower(Input::get('mname')));
			$User->user_type = 3;
			$User->email   = Input::get('email');	
			$User->password   = Hash::make(Input::get('password'));	

			$User->save();
			$user_id = $User->id;

			// store in Parents Table
			$parents = new Parents;
			$parents->code    = Input::get('code');
			$parents->fname   = ucwords(strtolower(Input::get('fname')));	
			$parents->mname   = ucwords(strtolower(Input::get('mname')));		
			$parents->lname   = ucwords(strtolower(Input::get('lname')));
			$parents->email   = Input::get('email');
			$parents->address = Input::get('address');
			$parents->phone_1   = Input::get('phone_1');
			$parents->phone_2   = Input::get('phone_2');
			$parents->occupation= ucwords(strtolower(Input::get('occupation')));
                        $parents->secondary_name = ucwords(strtolower(Input::get('secondary_name')));
			$parents->user_id = $user_id;

			 if(Input::hasFile('image'))
			  	{
				        $file = Input::file('image');
					$destinationPath = 'uploads/parent';
					$oldFilename = $file->getClientOriginalName();
					$extension = Input::file('image')->getClientOriginalExtension();
					$newFilename =Input::get('code').'_'.rand(11111,99999).'.'.$extension;
					$file->move($destinationPath, $newFilename);
					$parents->imagename_old      = $oldFilename;
					$parents->imagename_new      = $newFilename;

		            }	

						
			if($parents->save()){

			Session::flash('success', 'Successfully Parent Created!');
			return Redirect::to('parents');
		  }

            Session::flash('error', 'Something went wrong!Please try again');
			return Redirect::to('parents/create');
		}
	}
	public function getImportParent()
	{
		return View::make('parent.import')
		->with('title', 'Import Parents')
		->with('page', 'Manage Parents');

	}	
	public function ImportParent()
	{
		$validator = Validator::make(Input::all(),array(
		  'file'   => 'required'
		  ));
		if($validator->fails())
		{
			return Redirect::back()
			->withErrors($validator);
		}
		else
		{
			$file = Input::file('file');
			$ext= File::extension($file->getClientOriginalName());
			$file_name= Str::random(5).'.'.$ext;
			$file_name=Str::lower($file_name);
			$destinationPath = 'uploads/csv/';
			$upload_success = Input::file('file')->move($destinationPath, $file_name);
	        $file_path = $destinationPath.$file_name;
	        
			Excel::load($file_path,function($reader) use(&$import_fields,&$import_row_count){
			$row_count = $reader->getTotalRowsOfFile() - 1;
	        $import_row_count = $row_count;
	                
	        $existing_emails =array();
	        $existing_codes =array();
	        $readers = $reader->all()->toArray();
	       // dd($readers);
	        foreach($readers as $data)
	         {
	        	$existint_parent_check  = Parents::where('email',$data['email'])
        						->where('code',$data['code'] )->get()->toArray();
        		
        		$existint_user_check  = User::where('email',$data['email'])->get()->toArray();
        										
            	if(empty($existint_user_check) && empty($existint_parent_check))
            	{
            	// store in Users Table
				$User =new User;
				$User->fname   = ucwords(strtolower($data['fname']))." ".ucwords(strtolower($data['mname']));
				$User->user_type = 3;
				$User->email   = $data['email'];	
				$User->password = Hash::make($data['password']);
				$User->save();

				// store in Users Table
        		$parent = new Parents;
        		$parent->user_id = $User->id;
        		$parent->code =$data['code'];
                $parent->fname =$data['fname'];
                $parent->mname =$data['mname'];
                $parent->lname =$data['lname'];
                $parent->email =$data['email'];
                $parent->address =$data['address'];	
                $parent->phone_1 =$data['phone_1'];	
                $parent->phone_2 =$data['phone_2'];	
                $parent->religion =$data['religion'];	
                $parent->occupation =$data['occupation'];
                $parent->user_type =3;	
                $parent->save();

                }
                else
                {
               		return Redirect::Route('get-import-parent')
					->with('error','Oops ! Something Went Wrong PLease Try Again')
					->with('title', 'Import Parents')
					->with('page', 'Manage Parents');
			 	}
              }
 
           }); 
        return Redirect::Route('get-import-parent')
		->with('success','CSV file uploaded successfilly !')
		->with('title', 'Import Parents')
		->with('page', 'Manage Parents');    
        } 
    	
		
	}

	   public function addParent()
	    {
		$student = Student::find(Input::get('student'));
		$student->parent_id = Input::get('parent_id');
		$student->save();
		Session::flash('success', 'Successfully added child!');	
		return 'success';
		}
	
	public function getRequest()
	{
		$ParentRequest = ParentRequest::all();
		//dd($ParentRequest);
		return View::make('parent.view_request')
		->with('ParentRequests',$ParentRequest)
		->with('title','All Leave Request')
		->with('page','Manage Parents');
	}
	public function getSpecial()
	{
		$SpecialRequests = SpecialRequest::all();
		//dd($ParentRequest);
		return View::make('parent.view_special')
		->with('SpecialRequests',$SpecialRequests)
		->with('title','All Special Request')
		->with('page','Manage Parents');
	}
	
	public function getChildList()
	{
		$id = Input::get('parent_id');
		$parent=Parents::find($id);
		if($parent->Student->isEmpty()){

			 echo "<tr><td>No child added</td></tr>";
	
	}else
	    
	     	foreach($parent->Student as $student){
             echo "<tr><td>".$student->Classes->name."</td><td>".$student->Section->name."</td><td>".$student->fname."</td><td>".$student->lname."</td><td><a href='".URL::to('/')."/remove-child-parent/".$student->id."' class='btn btn-primary del_stu' data-student_id='".$student->id."'>Remove Child</a></td></tr>";
		}
		
	}	


	
	public function edit($id)
	{
		$Parents = Parents::find($id);
		if($Parents)
		{
			return View::make('parent..profile.edit')
			->with('Parents', $Parents)
			->with('title','Edit Parent')
			->with('page','Manage Parents');	
		}
		else
		{
			Session::flash('error', 'Oops No Such Record Existing !');
			return Redirect::to('parents')
			->with('title','All Parents')
			->with('page','Manage Parents');	
		}
	}
	public function update($id)
	{
		
		
			$rules = array(
			'code'       => 'required',
			'fname'  	 => 'required|alpha|min:3',
			'address'  	 => 'required|min:3',
			'phone_1'  	 => 'required|min:10'
			);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) 
		{
			return Redirect::back()
			->withErrors($validator)
			->withInput();
		} 
		else 
		{
			$parents  = Parents::find($id);
			$parents->code    = Input::get('code');
			$parents->fname   = ucwords(strtolower(Input::get('fname')));	
			$parents->mname   = ucwords(strtolower(Input::get('mname')));		
			$parents->lname   = ucwords(strtolower(Input::get('lname')));
			$parents->address = Input::get('address');
			$parents->phone_1   = Input::get('phone_1');
			$parents->phone_2   = Input::get('phone_2');
			$parents->occupation= ucwords(strtolower(Input::get('occupation')));	
			 if(Input::hasFile('image'))
			  	{
			  		File::delete('uploads/parent/'.$parents->imagename_new);

				    $file = Input::file('image');
				   
					$destinationPath = 'uploads/parent';
					
					$extension = Input::file('image')->getClientOriginalExtension();
					$oldFilename = $file->getClientOriginalName();
					$newFilename =$parents->code.'_'.rand(11111,99999).'.'.$extension;
					$file->move($destinationPath, $newFilename);
					$parents->imagename_old      = $oldFilename;
					$parents->imagename_new      = $newFilename;

		        }	
			
			if($parents->save()){

			  Session::flash('success', 'Successfully updated parent details!');
			  return Redirect::to('parents');
		   }

		    Session::flash('error', 'Something went wrong!Please try again');
			return Redirect::to('parents');
		}
	  
	}

	public function show($id)
	{
		$parents = Parents::find($id);
		return View::make('parent..profile.view')
		->with('parents', $parents)
		->with('title','View Parents')
		->with('page','Manage Parents');
	}

	public function getDeleteParent(){
		$id = Input::get('pid');
		$Parents = Parents::find($id);
		$User = $Parents->User;
		$Students = $Parents->Student;
		if($Parents)
		{
			
			if($Students)
			{
				foreach ($Students as $Student ) 
				{
					$update = Student::find($Student->id);
					$update->parent_id = 0;
					$update->save();
				}
			}
			$Parents->delete();
			$User->delete();
			Session::flash('success', 'Successfully deleted parent details!');
			return Redirect::to('parents');	
		}
	}


public function getRemoveChild($id){
		
		$update = Student::find($id);
		if($update)
		{
			$update->parent_id = 0;
			$update->save();
			Session::flash('success', 'Successfully removed child!');
			return Redirect::to('parents');		
		}
	}

	
	
} // main class close
