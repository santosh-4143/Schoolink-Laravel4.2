<?php

class TimetableController extends \BaseController {


	public function createTimetable()
	{
		$classes = Classes::all();

		return View::make('timetable.timetable')
		->with('title', 'Create Timetable')
		->with('page','Manage Timetable')
		->with('classes', $classes);

	}

	public function postTimetable(){

		$section_id=Input::get('section');
		$timetable_masters=Timetable::where('section_id','=',$section_id)->get();

		$rules = array(

			'class' => 'required',
			'section' => 'required',
			'lectures' => 'required'

			);
		$validator = Validator::make(Input::all(), $rules);
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();


		}

		elseif($timetable_masters->count() > 0){

			Session::flash('error', 'Timetable Already Exist!');
			return Redirect::to('class-timetable');
		}


		else{
			// store
			$timetable = new Timetable;

			$section=Section::find($section_id);
			$section_subjects = SectionSubject::where('section_id','=',$section_id)->get();
			$timetable ->section_id  =$section_id;
			$timetable ->max_lectures = Input::get('lectures');
			$timetable->save();

			$lecture_num = $timetable ->max_lectures;
			$inserted_id=$timetable ->id;
			
			return View::make('timetable.createtimetable')
			->with('title','Create Timetable')
			->with('page','Manage Classes')
			->with('inserted_id',$inserted_id)
			->with('lecture_num',$lecture_num)
			->with('section',$section)
			->with('section_subjects',$section_subjects);

		}





	}

	public function getCreate_timetable()
	{
		return View::make('class.createtimetable')
		->with('title','Create Timetable')
		->with('page','Manage Classes');
	}

	public function post_insert_timetable()
	{

		$rules = array(

			'subject_selection_mon' => 'required'

			);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();


		} else {
			// store


			$timetable_id=Input::get('timetable_id');
			$timetable_details=Timetable::where('id','=',$timetable_id)->get();
			foreach($timetable_details as $timetable_detail)
				$lecture_num=$timetable_detail->max_lectures;
			$section_id=$timetable_detail->section_id;
			$subject_selection_mon= Input::get('subject_selection_mon');
			$subject_selection_tue= Input::get('subject_selection_tue');
			$subject_selection_wed= Input::get('subject_selection_wed');
			$subject_selection_thu= Input::get('subject_selection_thu');
			$subject_selection_fri= Input::get('subject_selection_fri');
			$subject_selection_sat= Input::get('subject_selection_sat');
			$subject_selection_sun= Input::get('subject_selection_sun');
			$week_day_mon='mon';
			$week_day_tue='tue';
			$week_day_wed='wed';
			$week_day_thu='thu';
			$week_day_fri='fri';
			$week_day_sat='sat';
			$week_day_sun='sun';

			$start_mon= Input::get('start_time_mon');
			$start_tue= Input::get('start_time_tue');
			$start_wed= Input::get('start_time_wed');
			$start_thu= Input::get('start_time_thu');
			$start_fri= Input::get('start_time_fri');
			$start_sat= Input::get('start_time_sat');
			$start_sun= Input::get('start_time_sun');

			$end_mon= Input::get('end_time_mon');
			$end_tue= Input::get('end_time_tue');
			$end_wed= Input::get('end_time_wed');
			$end_thu= Input::get('end_time_thu');
			$end_fri= Input::get('end_time_fri');
			$end_sat= Input::get('end_time_sat');
			$end_sun= Input::get('end_time_sun');

			$facility_mon= Input::get('facility_mon');
			$facility_tue= Input::get('facility_tue');
			$facility_wed= Input::get('facility_wed');
			$facility_thu= Input::get('facility_thu');
			$facility_fri= Input::get('facility_fri');
			$facility_sat= Input::get('facility_sat');
			$facility_sun= Input::get('facility_sun');


           // dd( $week_day_mon);
			for($i=0;$i < $lecture_num;$i++){

				$lec_mon=$i+1;
				$timetable_details_mon = new TimetableDetails;
				$timetable_details_mon->section_subject_id=$subject_selection_mon[$i];
				$timetable_details_mon->week_day=$week_day_mon;
				$timetable_details_mon->lecture_num=$lec_mon;
				$timetable_details_mon->tt_master_id=$timetable_id;
				$timetable_details_mon->section_id=$section_id;
				$timetable_details_mon->start_time=$start_mon[$i];
				$timetable_details_mon->end_time=$end_mon[$i];
				$timetable_details_mon->facility=$facility_mon[$i];
				$timetable_details_mon->save();
			}

			for($i=0;$i < $lecture_num;$i++){

				$lec_tue=$i+1;
				$timetable_details_tue = new TimetableDetails;
				$timetable_details_tue->section_subject_id=$subject_selection_tue[$i];
				$timetable_details_tue->week_day=$week_day_tue;
				$timetable_details_tue->lecture_num=$lec_tue;
				$timetable_details_tue->tt_master_id=$timetable_id;
				$timetable_details_tue->section_id=$section_id;
				$timetable_details_tue->start_time=$start_tue[$i];
				$timetable_details_tue->end_time=$end_tue[$i];
				$timetable_details_tue->facility=$facility_tue[$i];
				$timetable_details_tue->save();

			}


			for($i=0;$i < $lecture_num;$i++){

				$lec_wed=$i+1;
				$timetable_details_wed = new TimetableDetails;
				$timetable_details_wed->section_subject_id=$subject_selection_wed[$i];
				$timetable_details_wed->week_day=$week_day_wed;
				$timetable_details_wed->lecture_num=$lec_wed;
				$timetable_details_wed->tt_master_id=$timetable_id;
				$timetable_details_wed->section_id=$section_id;
				$timetable_details_wed->start_time=$start_wed[$i];
				$timetable_details_wed->end_time=$end_wed[$i];
				$timetable_details_wed->facility=$facility_wed[$i];
				$timetable_details_wed->save();

			}
			for($i=0;$i < $lecture_num;$i++){

				$lec_thu=$i+1;
				$timetable_details_thu = new TimetableDetails;
				$timetable_details_thu->section_subject_id=$subject_selection_thu[$i];
				$timetable_details_thu->week_day=$week_day_thu;
				$timetable_details_thu->lecture_num=$lec_thu;
				$timetable_details_thu->tt_master_id=$timetable_id;
				$timetable_details_thu->section_id=$section_id;
				$timetable_details_thu->start_time=$start_thu[$i];
				$timetable_details_thu->end_time=$end_thu[$i];
				$timetable_details_thu->facility=$facility_thu[$i];
				$timetable_details_thu->save();

			}
			for($i=0;$i < $lecture_num;$i++){

				$lec_fri=$i+1;
				$timetable_details_fri = new TimetableDetails;
				$timetable_details_fri->section_subject_id=$subject_selection_fri[$i];
				$timetable_details_fri->week_day=$week_day_fri;
				$timetable_details_fri->lecture_num=$lec_fri;
				$timetable_details_fri->tt_master_id=$timetable_id;
				$timetable_details_fri->section_id=$section_id;
				$timetable_details_fri->start_time=$start_fri[$i];
				$timetable_details_fri->end_time=$end_fri[$i];
				$timetable_details_fri->facility=$facility_fri[$i];
				$timetable_details_fri->save();

			}

			for($i=0;$i < $lecture_num;$i++){

				$lec_sat=$i+1;
				$timetable_details_sat = new TimetableDetails;
				$timetable_details_sat->section_subject_id=$subject_selection_sat[$i];
				$timetable_details_sat->week_day=$week_day_sat;
				$timetable_details_sat->lecture_num=$lec_sat;
				$timetable_details_sat->tt_master_id=$timetable_id;
				$timetable_details_sat->section_id=$section_id;
				$timetable_details_sat->start_time=$start_sat[$i];
				$timetable_details_sat->end_time=$end_sat[$i];
				$timetable_details_sat->facility=$facility_sat[$i];
				$timetable_details_sat->save();
			}

			for($i=0;$i < $lecture_num;$i++){

				$lec_sun=$i+1;
				$timetable_details_sun = new TimetableDetails;
				$timetable_details_sun->section_subject_id=$subject_selection_sun[$i];
				$timetable_details_sun->week_day=$week_day_sun;
				$timetable_details_sun->lecture_num=$lec_sun;
				$timetable_details_sun->tt_master_id=$timetable_id;
				$timetable_details_sun->section_id=$section_id;
				$timetable_details_sun->start_time=$start_sun[$i];
				$timetable_details_sun->end_time=$end_sun[$i];
				$timetable_details_sun->facility=$facility_sun[$i];
				$timetable_details_sun->save();

			}


			// redirect
			Session::flash('success', 'Successfully Created Timetable!');
			return Redirect::to('class-timetable');



		}


	}



    public function listTimetable()
	{
		 $timetables = Timetable::all();
		 return View::make('timetable.listTimetable')
		->with('title', 'View Timetable')
		->with('page','Manage Timetable')
		->with('timetables', $timetables);
	}
	public function getEditTimetable($id)
	{
		$timetable_details = Timetable::find($id)->TimetableDetails;
		$timetables = Timetable::find($id);
		$section_subjects = SectionSubject::where('section_id','=',$timetables->section_id)->get();
		return View::make('timetable.timetableedit')
		->with('title', 'Edit Timetable')
		->with('page','Manage Timetable')
		->with('section_subjects',$section_subjects)
		->with('timetable_details',$timetable_details)
		->with('timetables',$timetables);

	}


	public function postEditTimetable()
	{
		$rules = array();
		$validator = Validator::make(Input::all(), $rules);

			 // process the login
		if ($validator->fails()) {
			return Redirect::back()
			->withErrors($validator)
			->withInput();


		} else {
				 // store
			$timetable_id=Input::get('timetable_id');
			$timetable_details=Timetable::where('id','=',$timetable_id)->get();

			$subject_selection= Input::get('subject_selection');
			$start= Input::get('start_time');
			$end= Input::get('end_time');
			$facility= Input::get('facility');
			$ids = Input::get('id');

			$data = $this->updateTimetable($ids,$subject_selection,$start,$end,$facility);
			if($data['status'] == 'success'){
				Session::flash('success', $data['msg']);
				return Redirect::back();
			}else{
				Session::flash('success', 'Timetable Updation Failed');
				return Redirect::back();
			}
			    } // update timetable else block

			}


			public function updateTimetable($ids,$subjects,$start_time,$end_time,$room)
			{

				foreach($ids as $key=>$value){

					$timetable_details = TimetableDetails::find($value);
					$timetable_details->section_subject_id=$subjects[$key];
					$timetable_details->start_time=$start_time[$key];
					$timetable_details->end_time=$end_time[$key];
					$timetable_details->facility=$room[$key];
					$timetable_details->save();

				}
				return $status = array('status' => 'success','msg'=>'Timetable details Updated Successfully');

			}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{

		$timetable_details = Timetable::find($id)->TimetableDetails;
		$timetables = Timetable::find($id);
     
		return View::make('timetable.timetableview')
		->with('title', 'View Timetable')
		->with('page','Manage Timetable')
		->with('timetable_details',$timetable_details)
		->with('timetables',$timetables);

	}

	public function postDeleteTimetable()
	{
		$timetable_id=Input::get('timetable_id');
		$timetable = Timetable::find($timetable_id);
		foreach($timetable->TimetableDetails as $data){
			$data->delete();
		}
		$timetable->delete();
		Session::flash('success', 'Successfully deleted Timetable!');
		return Redirect::back();

	}




}