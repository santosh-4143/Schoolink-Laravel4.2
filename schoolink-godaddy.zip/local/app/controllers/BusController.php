<?php

class BusController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('bus.index')
		->with('title', 'All Buses')
		->with('page','Manage Buses')
		->with('buses', Bus::all());
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('bus.create')
		->with('title','Create Bus')
		->with('page','Manage Buses');
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$rules = array(
			'code'       => 'required|unique:buses',
			'bus_no'  	 => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('bus/create')
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$bus = new Bus;
			$bus->code       = Input::get('code');
			$bus->bus_no     = Input::get('bus_no');
			$bus->save();

			// redirect
			Session::flash('success', 'Successfully created Bus!');
			return Redirect::to('bus');
		}
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$bus=Bus::find($id);
		return View::make('bus.edit')
		->with('bus',$bus)
		->with('title','Edit Bus')
		->with('page','Manage Buses');
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$rules = array('bus_no'  	 => 'required');
		$validator = Validator::make(Input::all(), $rules);
		if ($validator->fails()) {
			 return Redirect::back()
			->withErrors($validator)
			->withInput();
		 }
		else
		{
			
			$bus = Bus::find($id);
			$bus->bus_no   = Input::get('bus_no');
			$bus->save();

			
			Session::flash('success', 'Successfully Updated Bus!');
			return Redirect::to('bus');
		}
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function postDeleteBus()
	{
		$bus_id = Input::get('bus_id');
		$bus = Bus::find($bus_id);
		if(is_null($bus->Student)){
               

                  Session::flash('success', 'Successfully deleted Bus!');
                  $classes->delete();

               
 
             }else{
                  
                    Session::flash('error', 'This Bus have students linked!');
                 }
	}


}
