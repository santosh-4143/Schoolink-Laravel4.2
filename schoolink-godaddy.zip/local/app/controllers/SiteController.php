<?php

class SiteController extends BaseController {


	public function index()
	{

		return 'hello';
	}

	public function getDashboard()
	{

		return View::make('dashboard')
		->with('title','Dashboard')
		->with('page','Dashboard');
	}


	public function getRegister(){

		return View::make('user.register')
		->with('title','Online School Manager')
		->with('page','Register');
	}

	public function postRegister()
	{
			$rules = array(

			'user_type' => 'required',
			'email'     => 'required|email|unique:users',
			'password'  => 'required',
			'password_confirm' => 'required|same:password'
		);
		$validator = Validator::make(Input::all(), $rules);


		
		if ($validator->fails()) {
			return Redirect::to('register')
			->withErrors($validator)
			->withInput();


		} else {
			// store
			$User = new User;
			$User->user_type  = Input::get('user_type');
			$User->fname  = Input::get('fname');
			$User->email      = Input::get('email');
			$User->password   = Hash::make(Input::get('password'));

			$User->save();

			// redirect
			Session::flash('success', 'Successfully created Admin!');
			return Redirect::to('/');
		}
	}

	public function getLogin(){

		if (Auth::check())
			{
			    return Redirect::to('dashboard');
			}

		return View::make('user/login');
	}
	public function postLogin()
	{

		if (Auth::attempt(array('email'=>Input::get('email'), 'password'=>Input::get('password'),'active' => 1)))
		{  

			$user =Auth::user();
	    	return Redirect::to('dashboard')
	    	->with('success', 'You are now logged in!');
		}
		else
		{
    	return Redirect::to('/')
        ->with('error', 'Your username/password combination was incorrect Or Your account is inactive')
        ->withInput();
		}
	}

	public function getLogout()
	{

		Auth::logout();
		return Redirect::to('/')
		->with('success', 'Successfully Logged Out!');
	}

	public function getNotification()
	{
		$user = User::find(Auth::user()->id);
		$unreadNotifications = $user->notifications()->unread()->orderBy('sent_at', 'desc')->get();
		return View::make('page.notifications')
		->with('unreadNotifications', $unreadNotifications)
		->with('title', "All Notifications")
		->with('page', "Manage Notification");
	}
}
