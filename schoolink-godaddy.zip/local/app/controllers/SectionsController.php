<?php

class SectionsController extends \BaseController {


	public function index()
	{
		$data = Section::all();
		return View::make('section.index')
		->with('sections', $data)
		->with('title', 'All Sections')
		->with('page','Manage Sections');

	}


	public function create()
	{
		$data = Classes::all();

		return View::make('section.create')
		->with('classes', $data)
		->with('title', 'Create Section')
		->with('page','Manage Sections');


	}

	public function create_section_by_class($classes_id){

		$sections = Section::where('classes_id','=',$classes_id);
		$classes = Classes::all();
		


		return View::make('section.create')
		->with('classes', $classes)
		->with('classes_id',$classes_id)
		->with('title', 'Create Section')
		->with('page','Manage Sections');

	}


	public function store()
	{
		$rules = array(
			'code'       => 'required|unique:sections',
			'name'  	 => 'required',
			'classes' => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {

			return Redirect::back()
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$section = new Section;
			$section->code       = Input::get('code');
			$section->name   = Input::get('name');
			$section->classes_id   = Input::get('classes');
			$section->save();

			// redirect
			Session::flash('success', 'Successfully created Section!');
			return Redirect::back();
		}
	}


	public function show($id)
	{
		//
	}



	public function edit($section_id)
	{
		$section = Section::find($section_id);
		return View::make('section.edit')
		->with('section',$section)
		->with('title','Create Section')
		->with('page','Manage Sections');
	}


	public function update($id)
	{

                $section_id = $id;
		$rules = array(
		     'section_name' => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the login
		if ($validator->fails()) {

			return Redirect::to('edit-section/'.$section_id)
			->withErrors($validator)
			->withInput();

		}
		else
		{
			// store
			$section =Section::find($section_id);
			$section->name   = Input::get('section_name');
			$section->save();


			// redirect
			Session::flash('success', 'Successfully Updated Section!');
			return Redirect::to('sections');
		}


	}


	public function post_delete_section()
         {
            $section_id=Input::get('section_id');
            $sections=Section::find($section_id);
            $sections->delete();

            Session::flash('success', 'Successfully deleted Section!');
			return Redirect::to('sections')
			->with('title','Create Classes')
			->with('page','Manage Classes');

         }


   public function getStudentList($section_id)
	  {
	  	$students=Student::where('section_id','=',$section_id)->get();
	   	return View::make('section.studentlist')
		  ->with('students',$students)
		  ->with('title','Student List')
		  ->with('page','Manage Sections');
	  }


	


	public function destroy($id)
	{
		//
	}


}
