<?php

class TestController extends BaseController {


	public function index(){
		$students = Student::all();
		$student_subjects = SectionSubject::where('section_id', 1)->get();
		//echo "<pre>";
		//dd("<pre>".$student_subjects."<pre>");
		//die();
		$i=0;
		$Classwork = array();
		foreach($student_subjects as $student_subject)
		{
			$Classwork['time'.$i]=Classwork::where('sec_sub_id', $student_subject->id)->get();
			$i++;
		}
		// echo "<pre>";
		// print_r($Classwork);
		// die();
		return View::make('test')
		->with('Classworks',$Classwork);
	}

	public function test_mail(){


		Mail::send('emails.demo', array('key' => 'value'), function($message)
		{
		    $message->to('shamshi1988@gmail.coms', 'John Smith')->subject('Welcome!');
		});
	}
	public function getCategories(){

		return View::make('test');
	}
	public function postCategories(){

		if(Request::ajax()){
		return 'ajax get request and giving all categories';
	}
	}
}