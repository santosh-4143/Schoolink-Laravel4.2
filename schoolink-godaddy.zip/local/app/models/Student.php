<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class Student extends Eloquent implements UserInterface, RemindableInterface {
	
	use UserTrait, RemindableTrait;

	
	protected $table = 'students';

	
	protected $hidden = array('password', 'remember_token');

	public function Parents()
    {
        return $this->hasOne('Parent');
    }
    public function Subjects()
    {
        return $this->belongsToMany('Student', 'student_subject', 'student_id', 'subject_id');
    }

   public function Attendance(){

     return $this->hasMany('Attendance');

	}

	public function Classes()
    {
        return $this->belongsTo('Classes');
    }

    public function House()
    {
        return $this->belongsTo('House');
    }

    public function Section()
    {
        return $this->belongsTo('Section');
    }
    public function ParentRequest()
    {
        return $this->hasMany('ParentRequest');
    }
    public function AssignmentMarks()
    {
        return $this->hasMany('AssignmentMarks');
    }
    public function Fees()
    {
        return $this->hasMany('Fees');
    }

    public function Bus()
    {
        return $this->belongsTo('Bus');
    }

}
