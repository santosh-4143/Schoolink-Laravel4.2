<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;
use Zizaco\Entrust\HasRole;
class Teacher extends Eloquent implements UserInterface, RemindableInterface {
	 use HasRole;
	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'teachers';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');

	public function User()
    {
        return $this->belongsTo('User');
    }

    public function Classes(){

    	return $this->belongsTo('Classes');
    }

    public function Section(){

    	return $this->belongsTo('Section');
    }



    public function ClassTeacher(){

    	return $this->belongsToMany('Section', 'section_teacher', 'teacher_id', 'section_id');
    }

    public function Subjects()
    {
        return $this->belongsToMany('Subject', 'section_subjects', 'teacher_id', 'subject_id');
    }

    public function SectionSubject()
    {
        return $this->hasMany('SectionSubject','teacher_id','id');
    }

}
