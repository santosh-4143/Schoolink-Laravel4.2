
<?php

class Grade extends Eloquent {
	
	 protected $table = 'grades';

	

}