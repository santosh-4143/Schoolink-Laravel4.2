<?php


class Announcement extends Eloquent {
	
	 
	protected $table = 'announcements';

		
	
}