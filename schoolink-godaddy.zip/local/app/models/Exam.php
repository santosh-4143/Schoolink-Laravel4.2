
<?php

class Exam extends Eloquent {
	
	 protected $table = 'exams';

	public function Student(){

     return $this->belongsTo('Student');

	}
	public function Classes(){

     return $this->belongsTo('Classes');

	}
	public function ExamSchedule(){

     return $this->hasMany('ExamSchedule');

	}

	public function ExamMarks(){

     return $this->hasMany('ExamMarks');

	}

	 public function SectionSubject()
    {
        return $this->belongsTo('SectionSubject');
    } 
	
   

}