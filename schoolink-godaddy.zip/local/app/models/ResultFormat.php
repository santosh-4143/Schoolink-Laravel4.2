<?php


class ResultFormat extends Eloquent {
	
	 
	protected $table = 'result_format';

    public function SectionSubject()
      {
        return $this->belongsTo('SectionSubject');
      } 
   

}