
<?php

class ExamSchedule extends Eloquent {
	
	 protected $table = 'exam_schedules';

	public function Exam(){

     return $this->belongsTo('Exam');

	}
    public function ExamMarks(){

     return $this->hasMany('ExamMarks');

	}
	 public function SectionSubject()
    {
        return $this->belongsTo('SectionSubject');
    } 


}