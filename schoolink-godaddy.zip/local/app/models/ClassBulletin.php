<?php


class ClassBulletin extends Eloquent {
	
	 
	protected $table = 'classbulletins';

	public function Classes()
    {
        return $this->belongsTo('Classes');
    }
	
}