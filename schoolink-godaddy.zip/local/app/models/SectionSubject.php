<?php


class SectionSubject extends Eloquent {
	
	 
	protected $table = 'section_subjects';

		
	public function Student()
    {
        return $this->belongsToMany('Subject', 'student_subject', 'subject_id', 'student_id');
    }
    public function Classes()
    {
        return $this->belongsTo('Classes');
    }

    public function Section()
    {
        return $this->belongsTo('Section');
    }

   public function Teacher()
    {
        return $this->belongsTo('Teacher');
    }

  public function Subject()
    {
        return $this->belongsTo('Subject');
    }
    public function TimetableDetails()
    {
       
        return $this->belongsTo('TimetableDetails');
    }

 public function Assignment()
    {
        return $this->hasMany('Assignment');
    }

    public function Classwork()
    {
        return $this->hasMany('Classwork');
    }
    
}
