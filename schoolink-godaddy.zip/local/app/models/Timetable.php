<?php

 //use Illuminate\Database\Eloquent\SoftDeletingTrait;

 class Timetable extends Eloquent {

	//use SoftDeletingTrait;
	protected $dates = ['deleted_at'];

	protected $table = 'timetable_masters';

	  public function Section(){
      return $this->belongsTo('Section');
   	}
    public function Classes(){
			return $this->belongsTo('Classes');
    }
		public function TimetableDetails(){
      return $this->hasMany('TimetableDetails', 'tt_master_id', 'id');
    }

		 //public function Delete($id)
		  //{
		 	  // delete all associated photos
	  	 //  $this->TimetableDetails()->delete();
			// delete the user
		// 	return parent::delete();

	//	}
		//
		// public function forceDelete()
		// 	{
		// 		// use of withTrashed() to delete all records
		// 		$this->TimetableDetails()->forceDelete();
    //    // delete the user
		// 		 return parent::forceDelete();
		// 	}


		public function getDelete($id)
 		{
 		 $timetable = Timetable::find($id);
 		 foreach($timetable->TimetableDetails() as $data){
 				 $status = $data->delete();
 		 }
 		  //$status = $timetable->delete();
      //return $status;
 	}
}
