<?php


class Attendance extends Eloquent {
	
	 protected $table = 'attendances';

	public function Student(){

     return $this->belongsTo('Student');

	}
   

}