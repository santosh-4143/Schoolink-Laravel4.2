<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBulletinsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
	   Schema::create('bulletins', function(Blueprint $table)
		{
		    $table->integer('id', true);
			$table->string('code',100);
			$table->string('name',150);
			$table->string('description',200);
			$table->integer('classes_id');
			$table->integer('teacher_id');
			$table->integer('student_id');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('bulletins');
	}

}
