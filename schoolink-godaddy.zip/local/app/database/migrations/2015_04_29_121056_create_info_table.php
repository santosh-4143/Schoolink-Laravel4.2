<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInfoTable extends Migration {

	
	public function up()
	{
		 Schema::create('info', function(Blueprint $table)
		{
			$table->integer('id',true);
			$table->string('school_name');
			$table->string('email');
			$table->string('logo');
			$table->string('address');
			$table->string('phone');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('info');
	}

}
