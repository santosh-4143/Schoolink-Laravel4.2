<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAttendancesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('attendances', function(Blueprint $table)
		{
			$table->integer('id',true);
			$table->integer('section_subject_id');
			$table->integer('section_id');
			$table->integer('student_id');
            $table->string('status',150);
			$table->integer('user_id');
			$table->string('date');
			$table->integer('publish');
			$table->integer('lecture_num');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('attendances');
	}

}
