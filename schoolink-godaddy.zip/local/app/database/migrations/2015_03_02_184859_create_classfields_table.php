<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClassfieldsTable extends Migration {

	
	public function up()
	{
		Schema::create('classfields', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('classes_id');
			$table->string('flabel');
			$table->integer('fvalue');
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('classfields');
	}

}
