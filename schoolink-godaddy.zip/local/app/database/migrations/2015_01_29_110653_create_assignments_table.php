<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAssignmentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('assignments', function(Blueprint $table)
		{
		    $table->integer('id', true);
		    $table->integer('section_subject_id');
			$table->string('code',100);
			$table->string('name',150);
			$table->string('description',200);
			$table->string('date');
			$table->integer('type'); // type for assignment or tests
			$table->string('total_marks',100);
			$table->integer('section_id');
			$table->integer('classes_id');
			$table->integer('teacher_id');
			$table->integer('admin_id');
			$table->integer('publish_status');
			$table->integer('isChecked');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('assignments');
	}

}
