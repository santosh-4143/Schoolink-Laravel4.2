<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTimetableDetailsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('timetable_details', function(Blueprint $table)
		{
		    $table->integer('id', true);
			$table->string('code',100);
			$table->integer('tt_master_id');
			$table->integer('section_subject_id');
			$table->integer('section_id');
			$table->string('week_day');
			$table->integer('lecture_num');
			$table->string('start_time');
			$table->string('end_time');
			$table->string('facility');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('timetable_details');
	}

}
