<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSectionSubjectsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('section_subjects', function(Blueprint $table)
		{
			$table->integer('id',true);
			$table->integer('subject_id');
			$table->integer('ispractical')->nullable();
			$table->integer('classes_id');
			$table->integer('section_id');
			$table->integer('teacher_id');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('section_subjects');
	}

}
