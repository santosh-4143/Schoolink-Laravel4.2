<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('students', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('parent_id',150);
			$table->string('parent_code',150);
			$table->string('code',150);
			$table->string('fname',150);
			$table->string('mname',150)->nullable();
			$table->string('lname',150)->nullable();
			$table->string('classes_id',150);
			$table->string('section_id',150);
			$table->string('roll_no',150);
			$table->string('email',150);
			$table->string('address',150);
			$table->string('phone', 150);
			$table->integer('house_id');
			$table->string('religion', 150);
			$table->timestamps();
			$table->softDeletes();
		});	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('students');
	}

}
