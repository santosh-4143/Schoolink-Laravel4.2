<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubjectAnnouncementsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('subject_announcements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('section_id');
			$table->integer('sec_sub_id');
			$table->string('title',150);
			$table->text('description');
			$table->string('date',150);
			$table->integer('created_by');
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('subject_announcements');
	}

}
