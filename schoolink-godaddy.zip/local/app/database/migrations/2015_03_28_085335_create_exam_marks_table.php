<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateExamMarksTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
	  Schema::create('exam_marks', function(Blueprint $table)
		{
			$table->integer('id',true);
			$table->integer('exam_id');
			$table->integer('exam_schedule_id');
			$table->integer('subject_id');
			$table->integer('section_subject_id');
			$table->integer('section_id');
		    $table->integer('student_id');
		    $table->string('marks');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('exam_marks');
	}

}
