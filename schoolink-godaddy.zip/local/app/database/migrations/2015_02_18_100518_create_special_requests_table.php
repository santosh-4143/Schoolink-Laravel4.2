<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpecialRequestsTable extends Migration {

	
	public function up()
	{
		Schema::create('special_requests', function(Blueprint $table)
		{
			$table->integer('id',true);			
			$table->integer('student_id');
			$table->integer('parents_id');
			$table->string('title',150);
			$table->text('description');
			$table->integer('status');
			$table->string('comment',150)->nullable();
			$table->timestamps();
		});
	}

	
	public function down()
	{
		Schema::drop('special_requests');
	}

}
