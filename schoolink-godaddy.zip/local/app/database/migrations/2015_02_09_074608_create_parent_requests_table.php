<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateParentRequestsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('parent_requests', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('student_id');
			$table->integer('parents_id');
			$table->integer('teacher_id');
			$table->string('title',150);
			$table->string('description',1000);
			$table->string('date_range',150);
			$table->string('created_by',150);
			$table->string('status',150);
			$table->string('comment',150);
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('parent_requests');
	}

}
