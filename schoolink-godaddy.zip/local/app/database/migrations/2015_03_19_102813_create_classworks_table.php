<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClassworksTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('classworks', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('section_id');
			$table->integer('section_subject_id');
			$table->string('title',150);
			$table->text('description');
			$table->integer('type');
			$table->string('date',150);
			$table->string('created_by',150);
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('classworks');
	}

}
