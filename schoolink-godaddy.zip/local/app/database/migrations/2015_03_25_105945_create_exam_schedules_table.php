<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateExamSchedulesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
			Schema::create('exam_schedules', function(Blueprint $table)
		{
			$table->integer('id',true);
			$table->integer('exam_id');
			$table->string('section_subject_id');
			$table->string('total_marks');
			$table->string('date');
			$table->string('from');
		    $table->string('to');
		    $table->string('facility');
		    $table->string('status');
			$table->timestamps();
			$table->softDeletes();
		});
	    
	  }

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('exam_schedules');
	}

}
