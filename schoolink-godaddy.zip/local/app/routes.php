<?php

Route::get('/', array(
	'as' => 'get-login',
	'uses' => 'SiteController@getLogin'));

Route::post('/post-login', array(
	'as' => 'post-login',
	'uses' => 'SiteController@postLogin'));

Route::get('/register', array(
	'as' => 'register',
	'uses' => 'SiteController@getRegister'));

Route::post('/register', array(
	'as' => 'register',
	'uses' => 'SiteController@postRegister'));


Route::get('password/reset', array(
  'uses' => 'PasswordController@remind',
  'as' => 'password.remind'
));

Route::get('password/change-password', array(
  'uses' => 'PasswordController@getChangePassword',
  'as' => 'changePassword'
));

Route::post('password/change-password', array(
  'uses' => 'PasswordController@postChangePassword',
  'as' => 'changePassword'
));


Route::post('password/reset', array(
  'uses' => 'PasswordController@request',
  'as' => 'password.request'
));


Route::get('password/reset/{token}', array(
  'uses' => 'PasswordController@reset',
  'as' => 'password.reset'
));

Route::post('password/reset/{token}', array(
  'uses' => 'PasswordController@update',
  'as' => 'password.update'
));





Route::group(array('prefix' => 'api'), function()
{
    Route::group(array('prefix' => 'user'), function()
     {
 	Route::get('action={action}&email={email}&password={password}&gcm_id={gcm_id}&device_type={device_type}&user_type={user_type}&api=1',['uses' => 'ApiController@getUser']);

 	Route::get('action={action}&user_id={id}&api=2',['uses' => 'ApiController@getChild']);

 	Route::get('action={action}&subject_id={subject_id}&api=5',['uses' => 'ApiController@getClasswork']);

 	Route::get('action={action}&subject_id={subject_id}&api=6',['uses' => 'ApiController@getHomework']);

 	Route::get('action={action}&api=15',['uses' => 'ApiController@getEvent']);

 	Route::get('action={action}&api=7',['uses' => 'ApiController@getSchoolUpdate']);

 	Route::get('action={action}&child_id={child_id}&api=20',['uses' => 'ApiController@getChildUpdate']);

 	Route::get('action={action}&child_id={child_id}&api=19',['uses' => 'ApiController@getGallery']);

 	Route::get('action={action}&child_id={child_id}&api=8',['uses' => 'ApiController@getClassBulletin']);

 	Route::get('action={action}&child_id={child_id}&api=9',['uses' => 'ApiController@getStudentBulletin']);

 	Route::get('action={action}&child_id={child_id}&api=10',['uses' => 'ApiController@getAssignment']);

 	Route::get('action={action}&child_id={child_id}&api=11',['uses' => 'ApiController@getTimetable']);

 	Route::get('action={action}&month={month}&year={year}&child_id={child_id}&api=12',['uses' =>'ApiController@getAttendance']);

 	Route::get('action={action}&child_id={child_id}&api=13',['uses' => 'ApiController@getExam']);

 	Route::get('action={action}&child_id={child_id}&api=14',['uses' => 'ApiController@getInfo']);



 // Teacher Api Controller

 Route::get('action={action}&user_id={id}&api=26',['uses' => 'ApiController@getTeacherClasses']);

 Route::get('action={action}&classes_id={id}&api=16',['uses' => 'ApiController@getTeacherSection']);

 Route::get('action={action}&user_id={user_id}&section_id={section_id}&api=17',['uses' => 'ApiController@getTeacherSubject']);

 Route::get('action={action}&subject_id={subject_id}&api=18',['uses' => 'ApiController@getClassworkHomework']);

 Route::get('action={action}&section_id={id}&api=21',['uses' => 'ApiController@getTeacherStudent']);

 Route::get('action={action}&teacher_id={teacher_id}&student_id={student_id}&title={title}&description={description}&api=22',['uses' => 'ApiController@postStudentUpdate']);

 Route::get('action={action}&teacher_id={teacher_id}&subject_id={subject_id}&classworkTitle={classwork_title}&classworkDescription={classwork_description}&homeworkTitle={homework_title}&homeworkDescription={homework_description}&api=23',['uses' => 'ApiController@postClassworkHomework']);

 Route::get('action={action}&bus_id={bus_id}&latitude={latitude}&longitude={longitude}&api=24',['uses' => 'ApiController@postStudentLocation']);

  Route::get('action={action}&bus_id={bus_id}&offset={offset}&api=25',['uses' => 'ApiController@getStudentLocation']);
	

  }); // prefix user

}); // prefix api group




Route::group(array('before' => 'guest'),function(){

Route::get('/notifications', array(
	'as' => 'get-notification',
	'uses' => 'SiteController@getNotification'));
Route::get('/dashboard', array(
	'as' => 'get-dashboard',
	'uses' => 'SiteController@getDashboard'));
Route::get('/logout',array(
    'as' => 'get-logout',
    'uses' => 'SiteController@getLogout'));
});


//<<<<<<<<<<<<<<**********Start Of Admin Routes*********>>>>>>>>>>>>


Route::group(array('before' => 'is_admin'),function(){

	Route::resource('users', 'UserController');

	Route::post('user-delete', array(
	'as' => 'user-delete',
	'uses' => 'UserController@userDelete'));

	Route::post('user-status', array(
	'as' => 'user-status',
	'uses' => 'UserController@postUserStatus'));

	//  ************Student Routes***************

	Route::resource('students', 'StudentController');

	Route::post('/delete-student', array(
	'as' => 'delete-student',
	'uses' => 'StudentController@getDeleteStudent'));

	Route::get('/get-import', array(
	'as' => 'get-import',
	'uses' => 'StudentController@getImport'));
	Route::post('/import-student', array(
	'as' => 'import-student',
	'uses' => 'StudentController@importStudent'));
	Route::get('/export', array(
	'as' => 'export',
	'uses' => 'StudentController@export'));
  
	
	//  ************ End  Student Routes ***************

	//  ************Parent Routes***************

	Route::resource('parents', 'ParentController');

	Route::post('/delete-parent', array(
	'as' => 'delete-parent',
	'uses' => 'ParentController@getDeleteParent'));

	Route::post('get-child', array(
	'as' => 'get-child',
	'uses' => 'ParentController@getChildList'));

	Route::get('/remove-child-parent/{id}', array(
	'as' => 'remove-child-parent',
	'uses' => 'ParentController@getRemoveChild'));

	Route::get('/get-import-parent', array(
	'as' => 'get-import-parent',
	'uses' => 'ParentController@getImportParent'));
	Route::post('/import-parent', array(
	'as' => 'import-parent',
	'uses' => 'ParentController@ImportParent'));

	Route::post('/add-parent', array(
	'as' => 'add-parent',
	'uses' => 'ParentController@addParent'));

	Route::get('/view-request', array(
	'as' => 'view-request',
	'uses' => 'ParentController@getRequest'));
	Route::get('/view-special-request', array(
	'as' => 'view-special-request',
	'uses' => 'ParentController@getSpecial'));
	

	


	//  *************  End  Parent Routes **************

	//  ************ Resource Controller ***************

Route::resource('classes', 'ClassesController');
Route::post('get-section', array('as' => 'get-section','uses' => 'ClassesController@getSectionList'));
Route::post('delete-class', array('as' => 'delete-class','uses' => 'ClassesController@post_delete_class'));
Route::resource('sections', 'SectionsController');
Route::post('delete-section', array('as' => 'delete-section','uses' => 'SectionsController@post_delete_section'));
Route::get('section-student-list/{id}', array('as' => 'section-student-list','uses' => 'SectionsController@getStudentList'));

Route::resource('subjects', 'SubjectController');
Route::post('delete-subject', array('as' => 'delete-subject','uses' => 'SubjectController@postDeleteSubject'));
Route::resource('teachers', 'TeacherController');
Route::post('delete-teacher', array('as' => 'delete-teacher','uses' => 'TeacherController@postDeleteTeacher'));

Route::resource('assignments', 'AssignmentController');
Route::resource('classwork', 'ClassworkController');
Route::resource('bulletin', 'BulletinController');
Route::resource('listclasses', 'ListclassController');
Route::resource('event', 'EventController');
Route::post('event-delete', array('as' => 'event-delete','uses' => 'EventController@postDeleteEvent'));
Route::post('announcement-delete', array('as' => 'announcement-delete','uses' => 'AnnouncementController@postDeleteAnnouncement'));
Route::resource('announcements', 'AnnouncementController');




//House Routes//


Route::resource('house', 'HouseController');
Route::post('delete-house', array('as' => 'delete-house','uses' => 'HouseController@postDeletehouse'));
Route::resource('bus', 'BusController');
Route::post('delete-bus', array('as' => 'delete-bus','uses' => 'BusController@postDeleteBus'));
//*********End of house routes***********





	//  **************Announcement or Bulletin Routes*************

	Route::get('/get-student-bulletin', array(
	'as' => 'get-student-bulletin',
	'uses' => 'AnnouncementController@getStudentBulletin'));
	Route::post('/post-student-bulletin', array(
	'as' => 'post-student-bulletin',
	'uses' => 'AnnouncementController@postStudentBulletin'));
	Route::get('/student-bulletin', array(
	'as' => 'student-bulletin',
	'uses' => 'AnnouncementController@StudentBulletin'));

	Route::get('/get-class-bulletin', array(
	'as' => 'get-class-bulletin',
	'uses' => 'AnnouncementController@getClassBulletin'));
	Route::post('/post-class-bulletin', array(
	'as' => 'post-class-bulletin',
	'uses' => 'AnnouncementController@postClassBulletin'));
	Route::get('/class-bulletin', array(
	'as' => 'class-bulletin',
	'uses' => 'AnnouncementController@ClassBulletin'));

	//  *************End Announcement or Bulletin**************

	
	//  ************* Classwork and Announcement **************

	Route::get('/create-classwork', array(
	'as' => 'create-classwork',
	'uses' => 'ClassworkController@getCreateClasswork'));
	Route::get('/view-classwork/{subject_id}', array(
	'as' => 'view-classwork',
	'uses' => 'ClassworkController@getViewClasswork'));
	Route::post('/post-classwork', array(
	'as' => 'post-classwork',
	'uses' => 'ClassworkController@postViewClasswork'));

	Route::get('/view-announcement/{subject_id}', array(
	'as' => 'view-announcement',
	'uses' => 'ClassworkController@getViewAnnouncement'));
	Route::post('/post-announcement', array(
	'as' => 'post-announcement',
	'uses' => 'ClassworkController@postViewAnnouncement'));

	//  *************** End of classwork ************







Route::get('/assign-subject', array('as' => 'assign-subject','uses' => 'SubjectController@getAssign'));
Route::post('/assign-subject-post', array('as' => 'assign-subject-post','uses' => 'SubjectController@postAssignsubject'));
Route::get('/assigned-subject', array('as' => 'assigned-subject','uses' => 'SubjectController@getAssignedsubject'));
Route::get('edit-assigned-subject/{subject_id}', array('as' => 'edit-assigned-subject','uses' => 'SubjectController@getEditAssignedSubject'));
Route::post('edit-assigned-subject', array('as' => 'edit-assigned-subject','uses' => 'SubjectController@postEditAssignedSubject'));
Route::post('delete-assigned-subject', array('as' => 'delete-assigned-subject','uses' => 'SubjectController@postDeleteAssignedSubject'));





Route::get('/class-timetable', array('as' => 'class-timetable','uses' => 'TimetableController@createTimetable'));
Route::post('/timetable-post', array('as' => 'timetable-post','uses' => 'TimetableController@postTimetable'));
Route::post('create-timetable/{inserted_id}{lecture_num}', array('as' => 'create-timetable','uses' => 'TimetableController@getCreate_timetable'));
Route::post('insert-timetable-post', array('as' => 'insert-timetable-post','uses' => 'TimetableController@post_insert_timetable'));
Route::get('/timetable-list', array('as' => 'timetable-list','uses' => 'TimetableController@listTimetable'));
Route::get('timetable-sectionlist/{classes_id}', array('as' => 'timetable-sectionlist','uses' => 'TimetableController@listSections'));
Route::get('view-timetable/{id}', array('as' => 'view-timetable','uses' => 'TimetableController@show'));
Route::get('edit-timetable/{id}', array('as' => 'edit-timetable','uses' => 'TimetableController@getEditTimetable'));
Route::post('edit-timetable', array('as' => 'edit-timetable','uses' => 'TimetableController@postEditTimetable'));
Route::post('delete-timetable', array('as' => 'delete-timetable','uses' => 'TimetableController@postDeleteTimetable'));



/* For Info */

Route::get('info', array(
 'as' => 'info',
 'uses' => 'InfoController@index'));
Route::post('info_create', array(
 'as' => 'info_create',
 'uses' => 'InfoController@create'));
Route::get('info_edit/{id}', array(
 'as' => 'info_edit',
 'uses' => 'InfoController@getEdit'));
Route::post('info_edit', array(
 'as' => 'info_edit',
 'uses' => 'InfoController@postEdit'));
Route::post('info_delete', array(
 'as' => 'info_delete',
 'uses' => 'InfoController@postDelete'));





/* Start Gallery route */


Route::get('gallery-create', array('as' => 'gallery-create','uses' => 'GalleryController@getCreateGallery'));
Route::post('gallery-create', array('as' => 'gallery-create','uses' => 'GalleryController@postCreateGallery'));
Route::get('gallery-view', array('as' => 'gallery-view','uses' => 'GalleryController@getViewGallery'));
Route::get('gallery-edit/{id}', array('as' => 'gallery-edit','uses' => 'GalleryController@getEditGallery'));
Route::post('gallery-edit', array('as' => 'gallery-edit','uses' => 'GalleryController@postEditGallery'));
Route::get('gallery-full/{id}', array('as' => 'gallery-full','uses' => 'GalleryController@getFullGallery'));
Route::post('gallery-delete', array('as' => 'gallery-delete','uses' => 'GalleryController@postDeleteGallery'));

Route::get('gallery-add/{id}', array('as' => 'gallery-add','uses' => 'GalleryController@getAddGallery'));
Route::post('gallery-add', array('as' => 'gallery-add','uses' => 'GalleryController@postAddGallery'));
Route::post('image-delete', array('as' => 'image-delete','uses' => 'GalleryController@postDeleteImage'));

/* End Gallery route */



Route::get('gallery-create', array('as' => 'gallery-create','uses' => 'GalleryController@getCreateGallery'));
Route::post('gallery-create', array('as' => 'gallery-create','uses' => 'GalleryController@postCreateGallery'));
Route::get('gallery-view', array('as' => 'gallery-view','uses' => 'GalleryController@getViewGallery'));
Route::get('gallery-edit/{id}', array('as' => 'gallery-edit','uses' => 'GalleryController@getEditGallery'));
Route::post('gallery-edit', array('as' => 'gallery-edit','uses' => 'GalleryController@postEditGallery'));
Route::get('view-images/{id}', array('as' => 'view-images','uses' => 'GalleryController@getViewImages'));
Route::post('delete-image', array('as' => 'delete-image','uses' => 'GalleryController@postDeleteImage'));
Route::post('delete-photo', array('as' => 'delete-photo','uses' => 'GalleryController@postDeletePhoto'));
Route::get('admin-approve-request/{id}', array('as' => 'admin-approve-request','uses' =>'TeacherController@postAdminAproveRequest'));
Route::post('admin-reject', array('as' => 'admin-reject','uses' => 'TeacherController@postRejectRequest'));
});
// <<<<<<<<**********Ending of Admin Routes*****************>>>>>>>>>




// <<<<<<<<**********Starting of Teacher Routes*****************>>>>>>>>>

Route::group(array('before' => 'is_Teacher'),function(){

Route::get('/teacher-view', array(
    'as' => 'teacher-view',
    'uses' => 'TeacherController@viewTeacher'));

Route::get('/teacher-subjects', array(
    'as' => 'teacher-subjects',
    'uses' => 'TeacherController@viewTeacherSubjects'));

Route::get('/teacher-timetable', array(
    'as' => 'teacher-timetable',
    'uses' => 'TeacherController@viewTeacherTimetable'));





/* Classwork created by teacher Start **/

Route::post('get-teacher-periods', array('as' => 'get-teacher-periods','uses' => 'ForTeacherController@getTeacherPeriods'));


Route::get('teacher-classwork', array('as' => 'teacher-classwork','uses' => 'ForTeacherController@getClassWork'));

Route::get('teacher-create-classwork/{sec_sub_id}', array('as' => 'teacher-create-classwork','uses' => 'ForTeacherController@getCreateClassWork'));

Route::post('teacher-create-classwork', array('as' => 'teacher-create-classwork','uses' => 'ForTeacherController@postCreateClassWork'));

Route::get('teacher-list-classwork/', array('as' => 'teacher-list-classwork','uses' => 'ForTeacherController@getListClasswork'));

Route::get('teacher-view-classwork/{classwork_id}', array('as' => 'teacher-view-classwork','uses' => 'ForTeacherController@getViewClassWork'));

Route::get('teacher-edit-classwork/{id}', array('as' => 'teacher-edit-classwork','uses' => 'ForTeacherController@getEditClassWork'));

Route::post('teacher-edit-classwork/', array('as' => 'teacher-edit-classwork','uses' => 'ForTeacherController@postEditClassWork'));

Route::post('delete-classwork/', array('as' => 'delete-classwork','uses' => 'ForTeacherController@postDeleteClassWork'));

/* Classwork created by teacher End **/

/* Homework created by teacher Start **/

Route::get('teacher-homework', array('as' => 'teacher-homework','uses' => 'ForTeacherController@getHomeWork'));

Route::get('teacher-create-homework/{sec_sub_id}', array('as' => 'teacher-create-homework','uses' => 'ForTeacherController@getCreateHomework'));

Route::post('teacher-create-homework', array('as' => 'teacher-create-homework','uses' => 'ForTeacherController@postCreateHomework'));

Route::get('teacher-list-homework/', array('as' => 'teacher-list-homework','uses' => 'ForTeacherController@getListHomework'));

Route::get('teacher-view-homework/{classwork_id}', array('as' => 'teacher-view-homework','uses' => 'ForTeacherController@getViewHomework'));

Route::get('teacher-edit-homework/{id}', array('as' => 'teacher-edit-homework','uses' => 'ForTeacherController@getEditHomework'));

Route::post('teacher-edit-homework/', array('as' => 'teacher-edit-homework','uses' => 'ForTeacherController@postEditHomework'));

Route::post('delete-homework/', array('as' => 'delete-classwork','uses' => 'ForTeacherController@postDeleteHomework'));

/* Homework created by teacher End **/

/* Student Update created by teacher Start **/

Route::get('create-student-update', array('as' => 'create-student-update','uses' => 'ForTeacherController@getStudentUpdate'));

Route::post('create-student-update', array('as' => 'create-student-update','uses' => 'ForTeacherController@postStudentUpdate'));

Route::get('list-student-update/', array('as' => 'list-student-update','uses' => 'ForTeacherController@getListStudentUpdate'));

Route::get('view-student-update/{id}', array('as' => 'view-student-update','uses' => 'ForTeacherController@getViewStudentUpdate'));

Route::get('edit-student-update/{id}', array('as' => 'edit-student-update','uses' => 'ForTeacherController@getEditStudentUpdate'));

Route::post('edit-student-update/', array('as' => 'edit-student-update','uses' => 'ForTeacherController@postEditStudentUpdate'));

Route::post('delete-student-update/', array('as' => 'delete-student-update','uses' => 'ForTeacherController@postDeleteStudentUpdate'));

/* Student Update created by teacher End **/





Route::get('view-info', array('as' => 'view-info','uses' => 'ForTeacherController@getViewInfo'));

});
// <<<<<<<<**********Ending of Teacher Routes*****************>>>>>>>>>



//<<<<<<<<**********Starting of Parents Routes*****************>>>>>>>>>

Route::group(array('before' => 'is_Parent'),function(){

Route::get('/parent-profile', array(
	'as' => 'parent-profile',
	'uses' => 'ForParentController@getParentProfile'));

// start student classwork

Route::get('/view-classwork', array('as' => 'view-classwork','uses' =>'ForParentController@getStudentClassWork'));
Route::post('/classwork-student', array('as' => 'classwork-student','uses' => 'ForParentController@getClassworkStudent'));
Route::post('/classwork-details', array('as' => 'classwork-details','uses' => 'ForParentController@getClassworkDetails'));

// end student classwork

// start student homework

Route::get('/view-homework', array('as' => 'view-homework','uses' =>'ForParentController@getStudentHomework'));
Route::post('/homework-student', array('as' => 'homework-student','uses' => 'ForParentController@getHomeworkStudent'));
Route::post('/homework-details', array('as' => 'homework-details','uses' => 'ForParentController@getHomeworkDetails'));

// end student homework


// start student subject list

Route::get('/view-subject', array(
	'as' => 'view-subject',
	'uses' => 'ForParentController@getSubjectList'));



Route::post('/section-subject', array(
	'as' => 'section-subject',
	'uses' => 'SubjectController@getSectionSubject'));


// end student subject list

// start student timetable

Route::get('/view-timetable', array(
	'as' => 'view-timetable',
	'uses' => 'ForParentController@getTimetable'));

Route::post('/get-timetable', array(
	'as' => 'get-timetable',
	'uses' => 'ForParentController@getTimetableView'));

// end student timetable

// start student school and teacher updates

Route::get('/view-school-update', array(
	'as' => 'view-school-update',
	'uses' => 'ForParentController@getSchoolUpdate'));

Route::post('/school-update-details', array('as' => 'school-update-details','uses' => 'ForParentController@getSchoolUpdateDetails'));

Route::get('/view-teacher-update', array(
	'as' => 'view-teacher-update',
	'uses' => 'ForParentController@getTeacherUpdate'));

Route::post('/teacher-update', array('as' => 'teacher-update','uses' => 'ForParentController@postTeacherUpdate'));

Route::post('/teacher-update-details', array('as' => 'teacher-update-details','uses' => 'ForParentController@getTeacherUpdateDetails'));


// end school update


// start view events

Route::get('/view-events', array(
	'as' => 'view-events',
	'uses' => 'ForParentController@getEvents'));

Route::post('/event-details', array('as' => 'event-details','uses' => 'ForParentController@getEventDetails'));

// end view events

// start view gallery

Route::get('/list-gallery', array(
	'as' => 'list-gallery',
	'uses' => 'ForParentController@getGalleryList'));

Route::post('/list-gallery', array('as' => 'list-gallery','uses' => 'ForParentController@postGalleryList'));

Route::get('view-gallery/{id}', array('as' => 'view-gallery','uses' => 'ForParentController@getGalleryImages'));


// end view gallery

Route::get('view-info', array('as' => 'view-info','uses' => 'ForParentController@getViewInfo'));


Route::get('/view-attendance', array(
	'as' => 'view-attendance',
	'uses' => 'ForParentController@getAttendance'));

Route::post('/view-attendance', array(
	'as' => 'view-attendance',
	'uses' => 'ForParentController@postAttendance'));

// start student request

Route::get('/make-request', array(
	'as' => 'make-request',
	'uses' => 'ForParentController@getRequest'));

Route::post('/post-request', array(
	'as' => 'post-request',
	'uses' => 'ForParentController@postRequest'));

Route::get('/leave-list', array(
	'as' => 'leave-list',
	'uses' => 'ForParentController@index'));

Route::get('/special-request', array(
	'as' => 'special-request',
	'uses' => 'ForParentController@getSpecialRequest'));

Route::post('/post-special', array(
	'as' => 'post-special',
	'uses' => 'ForParentController@postSpecial'));

Route::get('/special-request-list', array(
	'as' => 'special-request-list',
	'uses' => 'ForParentController@getRequestStatus'));

Route::get('/request-status', array(
	'as' => 'request-status',
	'uses' => 'ForParentController@getRequestStatus'));


// end student request

// start student bulletin

Route::get('/parent-class-bulletin', array(
	'as' => 'parent-class-bulletin',
	'uses' => 'ForParentController@getParBulletin'));

Route::post('/get_class_bulletin_by_student', array(
	'as' => 'get_class_bulletin_by_student',
	'uses' => 'ForParentController@getBulletinByStudent'));

Route::get('/parent-student-bulletin', array(
	'as' => 'parent-student-bulletin',
	'uses' => 'ForParentController@getParStuBulletin'));

Route::post('/get_student_bulletin_by_student', array(
	'as' => 'get_student_bulletin_by_student',
	'uses' => 'ForParentController@getStuBulletinByStu'));

// end student bulletin




// start student exam

Route::get('/view-student-marks/{student}{exam}', array(
	'as' => 'view-student-marks',
	'uses' => 'ForParentController@getStudentMarks'));

// end student exam



Route::get('/student-announcement/{sec_sub_id}', array(
	'as' => 'student-announcement',
	'uses' => 'ForParentController@getParentsStudentAnnouncement'));




// start student image gallery

Route::get('parent-gallery', array(
	'as' => 'parent-gallery',
	'uses' => 'ForParentController@getParentGallery'));

Route::get('parent-image/{photo_id}', array(
	'as' => 'parent-image',
	'uses' => 'ForParentController@getParentImage'));

Route::post('parent-image', array(
	'as' => 'parent-image',
	'uses' => 'ForParentController@PostParentImage'));


// end student image gallery

});
//**********Ending of parents Route**********


Route::post('/get_ajax_section_subjects_result', array(
	'as' => 'get_ajax_section_subjects_result',
	'uses' => 'ExamController@get_section_subjects_result'));


Route::post('/get_ajax_exam', array(
 'as' => 'get_ajax_exam',
 'uses' => 'ExamController@get_ajax_exam'));

Route::post('/get_ajax_exam_by_student', array(
 'as' => 'get_ajax_exam_by_student',
 'uses' => 'ExamController@getExamByStudent'));

Route::post('/get_ajax_class_students', array(
 'as' => 'get_ajax_class_students',
 'uses' => 'ExamController@get_ajax_class_students'));

Route::post('/categories', array(
	'as' => 'post-categories',
	'uses' => 'TestController@postCategories'));

Route::post('/get_ajax_section', array(
	'as' => 'get_ajax_section',
	'uses' => 'StudentController@get_ajax_section'));

Route::post('/get_section_students', array(
	'as' => 'get_section_students',
	'uses' => 'StudentController@get_section_students'));



Route::post('/get_section_subjects_id', array(
	'as' => 'get_section_subjects_id',
	'uses' => 'AssignmentController@get_section_subjects_id'));

Route::post('/get_section_subjects_details', array(
	'as' => 'get_section_subjects_details',
	'uses' => 'SubjectController@get_section_subjects_details'));


Route::get('/test', array(
	'as' => 'test',
	'uses' => 'TestController@index'));
Route::get('/test/{id}', array('as' => 'test', 'uses' => 'TestController@abc'));

App::missing(function()
{
    return Response::view('error.404', array(), 404);
});
